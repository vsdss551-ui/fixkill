# KillEffect — Fabric 1.21.4

Projekt Java 21 / Fabric Loader / Fabric API. Otwórz folder w IntelliJ IDEA jako projekt Gradle.

## Budowanie
- Windows: `gradlew.bat build`
- Linux/macOS: `./gradlew build`
- JAR: `build/libs/killeffect-1.0.0.jar`

Pierwsze uruchomienie pobiera Gradle 8.10.2 oraz zależności Minecraft/Fabric.

## Sterowanie
- `Right Shift` — GUI
- `/killeffect` — GUI
- `/killeffect list`
- `/killeffect preview <nazwa>`
- `/killeffect select <nazwa>`
- `/killeffect toggle`

## Multiplayer
Zdarzenie śmierci jest wykrywane po stronie serwera przez mixin `LivingEntity#onDeath`.
Serwer rozsyła pakiet sceny do graczy w tym samym wymiarze. Wybrany efekt jest zgłaszany
serwerowi przez pakiet C2S. Animacja jest wyłącznie wizualna: nie zmienia obrażeń,
ekwipunku, dropów ani stanu świata. Klient bez moda nie renderuje sceny.

## Renderowanie
Sceny są renderowane w `WorldRenderEvents.AFTER_ENTITIES`, z użyciem buforów Fabric/Minecraft.
Modele są proceduralnymi siatkami 3D (elipsoidy, stożki, pierścienie, segmenty i bryły),
a nie encjami/blokami świata. Tekstury scen znajdują się w `assets/killeffect/textures/entity/`.
Czas życia scen jest ograniczony i obiekty są usuwane po zakończeniu.

## Uwaga o testach
W tym środowisku nie ma zainstalowanego Gradle ani dostępu sieciowego z procesu budowania.
Projekt zawiera skrypt pobierający Gradle przy pierwszym uruchomieniu; kompilację należy
uruchomić lokalnie poleceniem powyżej. Nie oznaczam kompilacji jako zweryfikowanej.
