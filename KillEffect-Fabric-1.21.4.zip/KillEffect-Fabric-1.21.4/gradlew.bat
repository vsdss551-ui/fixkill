@echo off
set VERSION=8.10.2
set BASE=%USERPROFILE%\.gradle\wrapper\dists\killeffect-gradle-%VERSION%
set DIST=%BASE%\gradle-%VERSION%
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%BASE%" mkdir "%BASE%"
  powershell -NoProfile -Command "Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%BASE%\gradle.zip'"
  powershell -NoProfile -Command "Expand-Archive -Force '%BASE%\gradle.zip' '%BASE%'"
)
call "%DIST%\bin\gradle.bat" %*
