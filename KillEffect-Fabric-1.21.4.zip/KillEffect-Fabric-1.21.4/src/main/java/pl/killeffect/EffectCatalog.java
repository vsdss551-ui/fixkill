package pl.killeffect;

import java.util.List;
import java.util.Locale;

public final class EffectCatalog {
    public record Effect(String id, String name, String category, String description, int color) {}
    public static final List<Effect> ALL = List.of(
        new Effect("pacman","PAC-MAN","Arcade","Ruchomy model z otwierającą się paszczą.",0xFFFFD43B),
        new Effect("police_car","POLICE CAR","Pojazdy","Radiowóz z pulsującymi światłami i policjantem.",0xFF4D9EFF),
        new Effect("ufo_abduction","UFO ABDUCTION","Sci-Fi","Spodek i promień unoszący postać.",0xFF69FF9B),
        new Effect("meteor","METEOR","Kosmos","Płonący obiekt z ognistym ogonem.",0xFFFF6B32),
        new Effect("shark","SHARK","Zwierzęta","Rekin z animowaną szczęką i płetwami.",0xFF54C9E8),
        new Effect("grim_reaper","GRIM REAPER","Fantasy","Żniwiarz z kosą i płaszczem.",0xFF9B8CFF),
        new Effect("giant_anvil","GIANT ANVIL","Komedia","Wielkie kowadło spadające z góry.",0xFFB7C1CE),
        new Effect("black_hole","BLACK HOLE","Kosmos","Wirujący horyzont i pierścienie akrecji.",0xFF9D72FF),
        new Effect("dragon","DRAGON","Fantasy","Smok ze skrzydłami i ogonem.",0xFFFF744E),
        new Effect("treasure_chest","TREASURE CHEST","Fantasy","Skrzynia otwierana zawiasem.",0xFFFFD66B),
        new Effect("mech_robot","MECH ROBOT","Sci-Fi","Robot z ramionami i mechanicznym krokiem.",0xFF7CC8FF),
        new Effect("thunder_god","THUNDER GOD","Fantasy","Władca burzy z piorunującą aurą.",0xFFB8D8FF)
    );
    public static boolean isValid(String id) { return ALL.stream().anyMatch(e -> e.id().equals(id)); }
    public static Effect get(String id) { return ALL.stream().filter(e -> e.id().equals(id)).findFirst().orElse(ALL.get(0)); }
    private EffectCatalog() {}
}
