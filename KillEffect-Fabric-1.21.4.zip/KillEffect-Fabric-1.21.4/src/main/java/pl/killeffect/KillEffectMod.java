package pl.killeffect;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.minecraft.util.Uuids;
import net.minecraft.server.network.ServerPlayerEntity;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class KillEffectMod implements ModInitializer {
    public static final String MOD_ID = "killeffect";
    private static final Map<UUID, String> PLAYER_EFFECTS = new ConcurrentHashMap<>();

    public record KillPayload(String effect, double x, double y, double z, UUID victim, UUID killer) implements CustomPayload {
        public static final Id<KillPayload> ID = new Id<>(Identifier.of(MOD_ID, "kill_scene"));
        public static final PacketCodec<RegistryByteBuf, KillPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, KillPayload::effect,
            PacketCodecs.DOUBLE, KillPayload::x,
            PacketCodecs.DOUBLE, KillPayload::y,
            PacketCodecs.DOUBLE, KillPayload::z,
            Uuids.PACKET_CODEC, KillPayload::victim,
            Uuids.PACKET_CODEC, KillPayload::killer,
            KillPayload::new
        );
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    public record SelectPayload(String effect) implements CustomPayload {
        public static final Id<SelectPayload> ID = new Id<>(Identifier.of(MOD_ID, "select_effect"));
        public static final PacketCodec<RegistryByteBuf, SelectPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.STRING, SelectPayload::effect, SelectPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    @Override public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(KillPayload.ID, KillPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SelectPayload.ID, SelectPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(SelectPayload.ID, (payload, context) ->
            context.server().execute(() -> {
                if (EffectCatalog.isValid(payload.effect())) {
                    PLAYER_EFFECTS.put(context.player().getUuid(), payload.effect());
                }
            })
        );
    }

    public static void broadcastKill(ServerPlayerEntity killer, ServerPlayerEntity victim) {
        String effect = PLAYER_EFFECTS.getOrDefault(killer.getUuid(), "pacman");
        KillPayload payload = new KillPayload(effect, victim.getX(), victim.getY(), victim.getZ(), victim.getUuid(), killer.getUuid());
        for (ServerPlayerEntity player : killer.getServerWorld().getPlayers()) {
            if (player.squaredDistanceTo(victim) <= 128.0 * 128.0
                && ServerPlayNetworking.canSend(player, KillPayload.ID)) {
                ServerPlayNetworking.send(player, payload);
            }
        }
    }
}
