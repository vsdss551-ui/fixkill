package pl.killeffect.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import pl.killeffect.EffectCatalog;
import pl.killeffect.KillEffectMod;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class KillEffectClient implements ClientModInitializer {
    public static String selected = "pacman";
    public static boolean enabled = true;
    public static boolean sounds = true;
    public static boolean particles = true;
    public static boolean showOthers = true;
    public static int durationSeconds = 7;
    public static double renderDistance = 64;
    private KeyBinding openKey;

    @Override public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.killeffect.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
            KeyBinding.MISC_CATEGORY
        ));
        ClientPlayNetworking.registerGlobalReceiver(KillEffectMod.KillPayload.ID, (payload, context) ->
            context.client().execute(() -> {
                if (enabled && (showOthers || (context.client().player != null && payload.killer().equals(context.client().player.getUuid())))) {
                    SceneManager.spawn(payload.effect(), payload.x(), payload.y(), payload.z(), durationSeconds);
                }
            })
        );
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) client.setScreen(new KillEffectScreen());
            SceneManager.tick();
        });
        WorldRenderEvents.AFTER_ENTITIES.register(SceneRenderer::render);
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(literal("killeffect")
                .executes(ctx -> { ctx.getSource().getClient().setScreen(new KillEffectScreen()); return 1; })
                .then(literal("list").executes(ctx -> {
                    ctx.getSource().sendFeedback(Text.literal("KillEffect: " +
                        String.join(", ", EffectCatalog.ALL.stream().map(EffectCatalog.Effect::id).toList())));
                    return 1;
                }))
                .then(literal("toggle").executes(ctx -> {
                    enabled = !enabled;
                    ctx.getSource().sendFeedback(Text.literal("KillEffect: " + (enabled ? "ON" : "OFF")));
                    return 1;
                }))
                .then(literal("select").then(argument("name", net.minecraft.command.argument.StringArgumentType.word())
                    .executes(ctx -> {
                        String id = net.minecraft.command.argument.StringArgumentType.getString(ctx, "name");
                        if (!EffectCatalog.isValid(id)) { ctx.getSource().sendError(Text.literal("Nieznany efekt: " + id)); return 0; }
                        selected = id;
                        ClientPlayNetworking.send(new KillEffectMod.SelectPayload(id));
                        ctx.getSource().sendFeedback(Text.literal("Wybrano: " + id));
                        return 1;
                    })))
                .then(literal("preview").then(argument("name", net.minecraft.command.argument.StringArgumentType.word())
                    .executes(ctx -> {
                        String id = net.minecraft.command.argument.StringArgumentType.getString(ctx, "name");
                        if (!EffectCatalog.isValid(id)) { ctx.getSource().sendError(Text.literal("Nieznany efekt: " + id)); return 0; }
                        var p = ctx.getSource().getPosition();
                        SceneManager.spawn(id, p.x, p.y, p.z, durationSeconds);
                        return 1;
                    })))
            );
        });
    }
}
