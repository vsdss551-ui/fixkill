
package pl.killeffect.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import pl.killeffect.EffectCatalog;
import pl.killeffect.KillEffectMod;

public final class KillEffectScreen extends Screen {
    private String category = "Wszystkie";
    private String tab = "effects";
    private int panelX, panelY, panelW=760, panelH=500;

    public KillEffectScreen() { super(Text.literal("KillEffect")); }

    @Override protected void init() {
        panelX=(width-panelW)/2;
        panelY=(height-panelH)/2;
    }

    @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta) {
        renderBackground(ctx,mouseX,mouseY,delta);
        int x=panelX,y=panelY;
        ctx.fill(x,y,x+panelW,y+panelH,0xF20D1018);
        border(ctx,x,y,panelW,panelH,0xFF344052);
        ctx.fill(x,y,x+panelW,y+64,0xFF151B26);
        ctx.drawText(textRenderer,"KILLEFFECT",x+22,y+15,0xFFF0F4FA,false);
        ctx.drawText(textRenderer,"FABRIC 1.21.4  •  3D SCENE CONTROL",x+22,y+36,0xFF8E9BAC,false);
        tabButton(ctx,x+panelW-210,y+18,88,28,"EFEKTY",tab.equals("effects"));
        tabButton(ctx,x+panelW-112,y+18,90,28,"USTAWIENIA",tab.equals("settings"));

        if(tab.equals("effects")) renderEffects(ctx,x,y);
        else renderSettings(ctx,x,y);

        ctx.fill(x,y+panelH-58,x+panelW,y+panelH,0xFF151B26);
        ctx.drawText(textRenderer,"Aktywny: "+EffectCatalog.get(KillEffectClient.selected).name(),x+20,y+panelH-42,0xFFB9C7D7,false);
        ctx.drawText(textRenderer,"Czas "+KillEffectClient.durationSeconds+" s   •   Zasięg "+(int)KillEffectClient.renderDistance+" m",x+20,y+panelH-24,0xFF8493A4,false);
        actionButton(ctx,x+panelW-300,y+panelH-43,126,28,KillEffectClient.enabled?"MOD WŁĄCZONY":"MOD WYŁĄCZONY",KillEffectClient.enabled);
        actionButton(ctx,x+panelW-162,y+panelH-43,140,28,"PODGLĄD ▶",true);
        super.render(ctx,mouseX,mouseY,delta);
    }

    private void renderEffects(DrawContext ctx,int x,int y) {
        String[] cats={"Wszystkie","Arcade","Pojazdy","Sci-Fi","Kosmos","Zwierzęta","Fantasy","Komedia"};
        ctx.fill(x+16,y+78,x+168,y+panelH-74,0x991B2230);
        int cy=y+94;
        for(String c:cats){
            boolean active=c.equals(category);
            ctx.fill(x+25,cy-6,x+159,cy+20,active?0xFF244766:0x00101010);
            ctx.drawText(textRenderer,c,x+38,cy+2,active?0xFF75C9FF:0xFFADB8C6,false);
            cy+=36;
        }
        int rx=x+184, ry=y+83;
        ctx.drawText(textRenderer,"Biblioteka animacji",rx,ry,0xFFF0F4FA,false);
        ctx.drawText(textRenderer,"Wybierz scenę, a potem użyj przycisku podglądu.",rx,ry+16,0xFF8995A5,false);
        int cardY=ry+42, col=0,row=0;
        for(EffectCatalog.Effect e:EffectCatalog.ALL){
            if(!category.equals("Wszystkie")&&!e.category().equals(category)) continue;
            int cx=rx+col*184, yy=cardY+row*72;
            boolean chosen=e.id().equals(KillEffectClient.selected);
            ctx.fill(cx,yy,cx+174,yy+62,chosen?0xFF20394E:0xFF171E29);
            border(ctx,cx,yy,174,62,chosen?0xFF5BB8F5:0xFF303B4A);
            ctx.fill(cx+9,yy+14,cx+39,yy+44,e.color());
            ctx.drawText(textRenderer,e.name(),cx+47,yy+13,0xFFF0F3F7,false);
            ctx.drawText(textRenderer,e.category(),cx+47,yy+31,0xFF8D9AAA,false);
            ctx.drawText(textRenderer,chosen?"WYBRANO":"KLIKNIJ, ABY WYBRAĆ",cx+47,yy+45,chosen?0xFF75C9FF:0xFF718093,false);
            col++; if(col==3){col=0;row++;}
        }
    }

    private void renderSettings(DrawContext ctx,int x,int y) {
        ctx.drawText(textRenderer,"Ustawienia efektów",x+28,y+91,0xFFF0F4FA,false);
        ctx.drawText(textRenderer,"Steruj widocznością, oprawą i długością scen.",x+28,y+110,0xFF8995A5,false);
        settingRow(ctx,x+28,y+151,"Efekty KillEffect",KillEffectClient.enabled?"WŁĄCZONE":"WYŁĄCZONE",KillEffectClient.enabled);
        settingRow(ctx,x+28,y+197,"Dźwięki scen",KillEffectClient.sounds?"WŁĄCZONE":"WYŁĄCZONE",KillEffectClient.sounds);
        settingRow(ctx,x+28,y+243,"Cząsteczki",KillEffectClient.particles?"WŁĄCZONE":"WYŁĄCZONE",KillEffectClient.particles);
        settingRow(ctx,x+28,y+289,"Pokazuj efekty innych graczy",KillEffectClient.showOthers?"WŁĄCZONE":"TYLKO MOJE",KillEffectClient.showOthers);
        ctx.drawText(textRenderer,"Czas trwania",x+28,y+355,0xFFEAF0F7,false);
        actionButton(ctx,x+220,y+345,42,28,"−",false);
        ctx.drawText(textRenderer,KillEffectClient.durationSeconds+" s",x+276,y+354,0xFF75C9FF,false);
        actionButton(ctx,x+330,y+345,42,28,"+",false);
        ctx.drawText(textRenderer,"Maksymalny dystans renderowania",x+430,y+355,0xFFEAF0F7,false);
        actionButton(ctx,x+650,y+345,42,28,"−",false);
        ctx.drawText(textRenderer,(int)KillEffectClient.renderDistance+" m",x+590,y+389,0xFF75C9FF,false);
        actionButton(ctx,x+700,y+345,42,28,"+",false);
        ctx.drawText(textRenderer,"Ustawienia zapisywane lokalnie; wybór efektu synchronizuje się z serwerem.",x+28,y+424,0xFF7E8B9A,false);
    }

    private void settingRow(DrawContext ctx,int x,int y,String label,String value,boolean active) {
        ctx.fill(x,y,x+690,y+34,0xFF171E29);
        ctx.drawText(textRenderer,label,x+12,y+12,0xFFE6ECF4,false);
        actionButton(ctx,x+560,y+4,118,26,value,active);
    }
    private void tabButton(DrawContext ctx,int x,int y,int w,int h,String label,boolean active) {
        ctx.fill(x,y,x+w,y+h,active?0xFF244766:0xFF202734);
        border(ctx,x,y,w,h,active?0xFF5BB8F5:0xFF303B4A);
        int tw=textRenderer.getWidth(label);
        ctx.drawText(textRenderer,label,x+(w-tw)/2,y+10,active?0xFF8ED4FF:0xFFADB8C6,false);
    }
    private void actionButton(DrawContext ctx,int x,int y,int w,int h,String label,boolean active) {
        ctx.fill(x,y,x+w,y+h,active?0xFF285777:0xFF29313D);
        border(ctx,x,y,w,h,active?0xFF5BB8F5:0xFF465365);
        int tw=textRenderer.getWidth(label);
        ctx.drawText(textRenderer,label,x+(w-tw)/2,y+(h-8)/2,0xFFF0F4F8,false);
    }
    private void border(DrawContext c,int x,int y,int w,int h,int color) {
        c.fill(x,y,x+w,y+1,color); c.fill(x,y+h-1,x+w,y+h,color);
        c.fill(x,y,x+1,y+h,color); c.fill(x+w-1,y,x+w,y+h,color);
    }

    @Override public boolean mouseClicked(double mx,double my,int button) {
        if(button!=0) return super.mouseClicked(mx,my,button);
        int x=panelX,y=panelY;
        if(mx>=x+panelW-210&&mx<=x+panelW-122&&my>=y+18&&my<=y+46){tab="effects";return true;}
        if(mx>=x+panelW-112&&mx<=x+panelW-22&&my>=y+18&&my<=y+46){tab="settings";return true;}
        if(mx>=x+panelW-300&&mx<=x+panelW-174&&my>=y+panelH-43&&my<=y+panelH-15){KillEffectClient.enabled=!KillEffectClient.enabled;return true;}
        if(mx>=x+panelW-162&&mx<=x+panelW-22&&my>=y+panelH-43&&my<=y+panelH-15){preview();return true;}

        if(tab.equals("effects")) {
            String[] cats={"Wszystkie","Arcade","Pojazdy","Sci-Fi","Kosmos","Zwierzęta","Fantasy","Komedia"};
            int cy=y+94;
            for(String c:cats){if(mx>=x+25&&mx<=x+159&&my>=cy-6&&my<=cy+20){category=c;return true;}cy+=36;}
            int rx=x+184, cardY=y+83+42, col=0,row=0;
            for(EffectCatalog.Effect e:EffectCatalog.ALL){
                if(!category.equals("Wszystkie")&&!e.category().equals(category))continue;
                int cx=rx+col*184, yy=cardY+row*72;
                if(mx>=cx&&mx<=cx+174&&my>=yy&&my<=yy+62){
                    KillEffectClient.selected=e.id();
                    if(client.getNetworkHandler()!=null) net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(new KillEffectMod.SelectPayload(e.id()));
                    return true;
                }
                col++;if(col==3){col=0;row++;}
            }
        } else {
            if(mx>=x+28&&mx<=x+718) {
                if(my>=y+151&&my<=y+185) KillEffectClient.enabled=!KillEffectClient.enabled;
                else if(my>=y+197&&my<=y+231) KillEffectClient.sounds=!KillEffectClient.sounds;
                else if(my>=y+243&&my<=y+277) KillEffectClient.particles=!KillEffectClient.particles;
                else if(my>=y+289&&my<=y+323) KillEffectClient.showOthers=!KillEffectClient.showOthers;
                else if(my>=y+345&&my<=y+373){
                    if(mx>=x+220&&mx<=x+262) KillEffectClient.durationSeconds=Math.max(2,KillEffectClient.durationSeconds-1);
                    if(mx>=x+330&&mx<=x+372) KillEffectClient.durationSeconds=Math.min(20,KillEffectClient.durationSeconds+1);
                    if(mx>=x+650&&mx<=x+692) KillEffectClient.renderDistance=Math.max(16,KillEffectClient.renderDistance-8);
                    if(mx>=x+700&&mx<=x+742) KillEffectClient.renderDistance=Math.min(192,KillEffectClient.renderDistance+8);
                }
                return true;
            }
        }
        return super.mouseClicked(mx,my,button);
    }

    private void preview() {
        if(client.player!=null) {
            var p=client.player.getPos();
            SceneManager.spawn(KillEffectClient.selected,p.x,p.y,p.z,KillEffectClient.durationSeconds);
        }
    }
    @Override public boolean shouldPause(){return false;}
    @Override public void close(){client.setScreen(null);}
}
