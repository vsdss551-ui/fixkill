package pl.killeffect.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;

public final class SceneManager {
    public static final class Scene {
        public final String effect;
        public final double x,y,z;
        public final long started;
        public final long duration;
        public final UUID id = UUID.randomUUID();
        Scene(String effect,double x,double y,double z,int seconds) {
            this.effect=effect; this.x=x; this.y=y; this.z=z;
            this.started=System.nanoTime(); this.duration=Math.max(2,Math.min(20,seconds))*1_000_000_000L;
        }
        public float progress() { return Math.min(1f,(System.nanoTime()-started)/(float)duration); }
        public float ageSeconds() { return (System.nanoTime()-started)/1_000_000_000f; }
    }
    private static final List<Scene> ACTIVE = new ArrayList<>();
    public static void spawn(String id,double x,double y,double z,int seconds) {
        if (!pl.killeffect.EffectCatalog.isValid(id)) return;
        synchronized (ACTIVE) {
            if (ACTIVE.size() >= 24) ACTIVE.remove(0);
            ACTIVE.add(new Scene(id,x,y,z,seconds));
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null && mc.player != null) {
            if (KillEffectClient.sounds) {
                switch (id) {
                    case "meteor", "giant_anvil" -> mc.player.playSound(SoundEvents.ENTITY_GENERIC_EXPLODE, 0.9f, 0.8f);
                    case "dragon" -> mc.player.playSound(SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 0.8f, 1.15f);
                    case "thunder_god" -> mc.player.playSound(SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 0.8f, 1.0f);
                    case "treasure_chest" -> mc.player.playSound(SoundEvents.ENTITY_PLAYER_LEVELUP, 0.7f, 1.4f);
                    case "police_car" -> mc.player.playSound(SoundEvents.ENTITY_MINECART_RIDING, 0.8f, 1.1f);
                    default -> mc.player.playSound(SoundEvents.ENTITY_ENDERMAN_TELEPORT, 0.8f, 1.0f);
                }
            }
            if (KillEffectClient.particles) {
                ParticleEffect type = switch (id) {
                    case "meteor", "giant_anvil" -> ParticleTypes.FLAME;
                    case "ufo_abduction", "mech_robot" -> ParticleTypes.ELECTRIC_SPARK;
                    case "grim_reaper" -> ParticleTypes.SOUL;
                    case "black_hole" -> ParticleTypes.PORTAL;
                    case "dragon" -> ParticleTypes.DRAGON_BREATH;
                    case "treasure_chest" -> ParticleTypes.TOTEM_OF_UNDYING;
                    case "thunder_god" -> ParticleTypes.END_ROD;
                    case "shark" -> ParticleTypes.BUBBLE;
                    default -> ParticleTypes.CRIT;
                };
                for (int i=0;i<28;i++) {
                    double angle=(Math.PI*2*i)/28.0;
                    double radius=0.5+(i%4)*0.18;
                    mc.world.addParticle(type,x+Math.cos(angle)*radius,y+0.2+(i%5)*0.22,z+Math.sin(angle)*radius,
                        Math.cos(angle)*0.025,0.025+(i%3)*0.015,Math.sin(angle)*0.025);
                }
            }
        }
    }
    public static void tick() {
        synchronized (ACTIVE) { ACTIVE.removeIf(s -> s.progress() >= 1f); }
    }
    public static List<Scene> snapshot() {
        synchronized (ACTIVE) { return List.copyOf(ACTIVE); }
    }
    private SceneManager() {}
}
