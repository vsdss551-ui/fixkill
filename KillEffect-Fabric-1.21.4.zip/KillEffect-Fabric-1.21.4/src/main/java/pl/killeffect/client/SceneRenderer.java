package pl.killeffect.client;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.Identifier;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import java.util.List;

/**
 * Lekki renderer siatek proceduralnych. Każda scena składa się z niezależnych
 * prymitywów 3D (elipsoidy, stożki, pierścienie, segmenty). Wszystkie pozycje
 * są liczone względem kamery i przekazywane do bufora renderującego Minecrafta.
 */
public final class SceneRenderer {
    private static final int FULL_BRIGHT = 0x00F000F0;
    public static void render(WorldRenderContext ctx) {
        if (ctx.matrixStack() == null || ctx.consumers() == null || ctx.world() == null) return;
        var camera = ctx.camera().getPos();
        MatrixStack matrices = ctx.matrixStack();
        for (SceneManager.Scene s : SceneManager.snapshot()) {
            double distSq = camera.squaredDistanceTo(s.x,s.y,s.z);
            if (distSq > KillEffectClient.renderDistance * KillEffectClient.renderDistance) continue;
            float t = s.ageSeconds(), p = s.progress();
            float fade = Math.min(1f, Math.min(p*7f, (1f-p)*6f));
            VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getEntityTranslucent(Identifier.of("killeffect", "textures/entity/" + s.effect + ".png")));
            matrices.push();
            matrices.translate(s.x-camera.x, s.y-camera.y, s.z-camera.z);
            matrices.scale(1.0f,1.0f,1.0f);
            drawScene(matrices, vc, s.effect, t, fade);
            matrices.pop();
        }
    }

    private static void drawScene(MatrixStack m, VertexConsumer v, String id, float t, float a) {
        float bob = (float)Math.sin(t*3.2f)*.12f;
        switch(id) {
            case "pacman" -> {
                sphere(m,v,0,1.0f+bob,0,0.95f,0.95f,0.95f,0xFFFFD52E,a);
                // animowana szczęka: dwa kliny odchylają się rytmicznie
                float jaw=(float)Math.sin(t*9)*.42f;
                cone(m,v,0.55f,1.02f,0,0.62f,0.38f,0xFF171717,a,0,jaw,0);
                ring(m,v,0,1.0f,0,1.05f,0xFFFFEE80,a,16);
                break;
            }
            case "police_car" -> {
                box(m,v,0,.42f,0,2.0f,.58f,1.05f,0xFF202B3B,a);
                box(m,v,0,.83f,0,1.08f,.42f,.88f,0xFFB8D9E8,a);
                box(m,v,0,1.13f,0,.62f,.12f,.28f,0xFF202B3B,a);
                sphere(m,v,-.45f,1.24f,0,.16f,.12f,.16f,0xFFFF394D,a);
                sphere(m,v,.45f,1.24f,0,.16f,.12f,.16f,0xFF3D8BFF,a);
                wheels(m,v,t,a);
                break;
            }
            case "ufo_abduction" -> {
                ellipsoid(m,v,0,2.5f,0,1.25f,.34f,1.0f,0xFF7C8C9F,a);
                ellipsoid(m,v,0,2.75f,0,.62f,.42f,.55f,0xFFB7F3D5,a);
                ring(m,v,0,2.42f,0,1.38f,0xFF62FF9C,a,32);
                beam(m,v,0,.95f,0,.72f,1.5f,0xFF55FF9B,a*.55f);
                break;
            }
            case "meteor" -> {
                float fall=2.8f*(1-Math.min(1,t/2.3f));
                ellipsoid(m,v,0,fall,0,.68f,.72f,.62f,0xFFB7A49A,a);
                cone(m,v,0,fall+1.05f,0,.72f,1.8f,0xFFFF642B,a,0,0,0);
                ring(m,v,0,.18f,0,1.35f,0xFFFFA13B,a,28);
                break;
            }
            case "shark" -> {
                ellipsoid(m,v,0,1.0f+bob,0,1.6f,.62f,.65f,0xFF64899A,a);
                cone(m,v,.2f,1.08f,-.45f,.56f,.65f,0xFF263E4B,a,0,0,0);
                cone(m,v,.2f,.65f,.55f,.48f,.62f,0xFF263E4B,a,0,0,0);
                ellipsoid(m,v,.82f,.88f,0,.52f,.25f,.42f,0xFF172B38,a);
                break;
            }
            case "grim_reaper" -> {
                ellipsoid(m,v,0,1.05f,0,.66f,1.12f,.5f,0xFF252432,a);
                ellipsoid(m,v,0,2.1f,0,.42f,.48f,.42f,0xFF16151F,a);
                cone(m,v,0,1.7f,-.38f,.24f,.9f,0xFF111018,a,0,0,0);
                rod(m,v,.75f,1.5f,0,.10f,1.8f,0xFFB9C3D6,a);
                ring(m,v,.75f,2.42f,0,.42f,0xFFE5ECF5,a,16);
                break;
            }
            case "giant_anvil" -> {
                float drop=3.0f*(1-Math.min(1,t/1.7f));
                box(m,v,0,drop+1.0f,0,1.7f,.62f,1.15f,0xFF596675,a);
                box(m,v,0,drop+1.48f,0,1.0f,.36f,.72f,0xFF8C9AA8,a);
                box(m,v,0,drop+.53f,0,2.15f,.25f,1.42f,0xFF3B4652,a);
                break;
            }
            case "black_hole" -> {
                sphere(m,v,0,1.3f,0,.72f,.72f,.72f,0xFF05040A,a);
                ring(m,v,0,1.3f,0,1.15f,0xFF8B57FF,a,40);
                ring(m,v,0,1.3f,0,.94f,0xFF42D9FF,a,32);
                for(int i=0;i<3;i++) ring(m,v,0,1.3f,0,1.4f+i*.18f,0xFF6E44D9,a*(.5f+i*.12f),36);
                break;
            }
            case "dragon" -> {
                ellipsoid(m,v,0,1.25f,0,.72f,.62f,1.0f,0xFF9B3F32,a);
                ellipsoid(m,v,0,1.75f,-.72f,.48f,.42f,.5f,0xFFB84E39,a);
                cone(m,v,.28f,2.1f,-.98f,.18f,.5f,0xFFFFC15D,a,0,0,0);
                wing(m,v,-1.0f,1.55f,0,t,a); wing(m,v,1.0f,1.55f,0,-t,a);
                tail(m,v,t,a);
                break;
            }
            case "treasure_chest" -> {
                box(m,v,0,.55f,0,1.55f,.8f,1.05f,0xFF8A4B24,a);
                ellipsoid(m,v,0,1.02f,0,.78f,.36f,.54f,0xFFB9782F,a);
                box(m,v,0,.56f,-.55f,.24f,.84f,.12f,0xFFFFD15A,a);
                sphere(m,v,0,.78f,-.66f,.18f,.18f,.12f,0xFFFFE58A,a);
                break;
            }
            case "mech_robot" -> {
                box(m,v,0,1.35f,0,1.0f,1.15f,.72f,0xFF566F86,a);
                box(m,v,0,2.22f,0,.78f,.58f,.62f,0xFF25394C,a);
                box(m,v,-.83f,1.65f,0,.38f,1.0f,.42f,0xFF7895AB,a);
                box(m,v,.83f,1.65f,0,.38f,1.0f,.42f,0xFF7895AB,a);
                box(m,v,-.32f,.38f,0,.34f,.82f,.42f,0xFF344B60,a);
                box(m,v,.32f,.38f,0,.34f,.82f,.42f,0xFF344B60,a);
                sphere(m,v,0,2.25f,-.34f,.22f,.12f,.08f,0xFF64E8FF,a);
                break;
            }
            case "thunder_god" -> {
                ellipsoid(m,v,0,1.35f,0,.68f,1.05f,.48f,0xFF4E5E7B,a);
                ellipsoid(m,v,0,2.45f,0,.42f,.48f,.4f,0xFFE0E9F4,a);
                rod(m,v,.9f,1.4f,0,.12f,1.65f,0xFFB9C9D9,a);
                lightning(m,v,.9f,2.2f,0,t,a);
                ring(m,v,0,2.9f,0,1.25f,0xFF9BD7FF,a,32);
                break;
            }
        }
    }

    private static void vertex(MatrixStack.Entry e, VertexConsumer v,float x,float y,float z,int c,float alpha,float nx,float ny,float nz,float u,float vv) {
        int r=(c>>16)&255,g=(c>>8)&255,b=c&255;
        v.vertex(e.getPositionMatrix(),x,y,z).color(r,g,b,Math.max(0,Math.min(255,(int)(alpha*255))))
            .texture(u,vv).overlay(0).light(FULL_BRIGHT).normal(e.getNormalMatrix(),nx,ny,nz);
    }
    private static void quad(MatrixStack m,VertexConsumer v,float[][] p,int c,float a) {
        var e=m.peek(); float[] u=p[0],w=p[1],q=p[2],r=p[3];
        float nx=(w[1]-u[1])*(q[2]-u[2])-(w[2]-u[2])*(q[1]-u[1]);
        float ny=(w[2]-u[2])*(q[0]-u[0])-(w[0]-u[0])*(q[2]-u[2]);
        float nz=(w[0]-u[0])*(q[1]-u[1])-(w[1]-u[1])*(q[0]-u[0]);
        float l=(float)Math.sqrt(nx*nx+ny*ny+nz*nz); if(l<1e-5)l=1;
        nx/=l;ny/=l;nz/=l;
        vertex(e,v,u[0],u[1],u[2],c,a,nx,ny,nz,0,0); vertex(e,v,w[0],w[1],w[2],c,a,nx,ny,nz,0,1);
        vertex(e,v,q[0],q[1],q[2],c,a,nx,ny,nz,1,1); vertex(e,v,r[0],r[1],r[2],c,a,nx,ny,nz,1,0);
    }
    private static void box(MatrixStack m,VertexConsumer v,float x,float y,float z,float sx,float sy,float sz,int c,float a) {
        float x0=x-sx/2,x1=x+sx/2,y0=y-sy/2,y1=y+sy/2,z0=z-sz/2,z1=z+sz/2;
        quad(m,v,new float[][]{{x0,y0,z0},{x0,y1,z0},{x1,y1,z0},{x1,y0,z0}},c,a);
        quad(m,v,new float[][]{{x1,y0,z1},{x1,y1,z1},{x0,y1,z1},{x0,y0,z1}},c,a);
        quad(m,v,new float[][]{{x0,y0,z1},{x0,y1,z1},{x0,y1,z0},{x0,y0,z0}},c,a);
        quad(m,v,new float[][]{{x1,y0,z0},{x1,y1,z0},{x1,y1,z1},{x1,y0,z1}},c,a);
        quad(m,v,new float[][]{{x0,y1,z0},{x0,y1,z1},{x1,y1,z1},{x1,y1,z0}},c,a);
        quad(m,v,new float[][]{{x0,y0,z1},{x0,y0,z0},{x1,y0,z0},{x1,y0,z1}},c,a);
    }
    private static void ellipsoid(MatrixStack m,VertexConsumer v,float x,float y,float z,float rx,float ry,float rz,int c,float a) {
        int rings=8, seg=16;
        for(int j=0;j<rings;j++) {
            float p0=(float)(-Math.PI/2+Math.PI*j/rings),p1=(float)(-Math.PI/2+Math.PI*(j+1)/rings);
            for(int i=0;i<seg;i++) {
                float q0=(float)(Math.PI*2*i/seg),q1=(float)(Math.PI*2*(i+1)/seg);
                float[][] f={{x+rx*(float)Math.cos(p0)*(float)Math.cos(q0),y+ry*(float)Math.sin(p0),z+rz*(float)Math.cos(p0)*(float)Math.sin(q0)},
                    {x+rx*(float)Math.cos(p1)*(float)Math.cos(q0),y+ry*(float)Math.sin(p1),z+rz*(float)Math.cos(p1)*(float)Math.sin(q0)},
                    {x+rx*(float)Math.cos(p1)*(float)Math.cos(q1),y+ry*(float)Math.sin(p1),z+rz*(float)Math.cos(p1)*(float)Math.sin(q1)},
                    {x+rx*(float)Math.cos(p0)*(float)Math.cos(q1),y+ry*(float)Math.sin(p0),z+rz*(float)Math.cos(p0)*(float)Math.sin(q1)}};
                quad(m,v,f,c,a);
            }
        }
    }
    private static void sphere(MatrixStack m,VertexConsumer v,float x,float y,float z,float r1,float r2,float r3,int c,float a){ellipsoid(m,v,x,y,z,r1,r2,r3,c,a);}
    private static void cone(MatrixStack m,VertexConsumer v,float x,float y,float z,float r,float h,int c,float a,float rx,float ry,float rz) {
        m.push();m.translate(x,y,z);m.multiply(new org.joml.Quaternionf().rotateXYZ(rx,ry,rz));
        int n=20; for(int i=0;i<n;i++){float a0=(float)(Math.PI*2*i/n),a1=(float)(Math.PI*2*(i+1)/n);
            quad(m,v,new float[][]{{r*(float)Math.cos(a0),-h/2,r*(float)Math.sin(a0)},{0,h/2,0},{r*(float)Math.cos(a1),-h/2,r*(float)Math.sin(a1)},{r*(float)Math.cos(a0),-h/2,r*(float)Math.sin(a0)}},c,a);}
        m.pop();
    }
    private static void ring(MatrixStack m,VertexConsumer v,float x,float y,float z,float r,int c,float a,int n) {
        for(int i=0;i<n;i++){float p=(float)(2*Math.PI*i/n),q=(float)(2*Math.PI*(i+1)/n);
            float[][] f={{x+r*(float)Math.cos(p),y,z+r*(float)Math.sin(p)},{x+r*(float)Math.cos(q),y,z+r*(float)Math.sin(q)},
                {x+(r-.06f)*(float)Math.cos(q),y+.02f,z+(r-.06f)*(float)Math.sin(q)},{x+(r-.06f)*(float)Math.cos(p),y+.02f,z+(r-.06f)*(float)Math.sin(p)}};
            quad(m,v,f,c,a);}
    }
    private static void beam(MatrixStack m,VertexConsumer v,float x,float y,float z,float r,float h,int c,float a) {
        for(int i=0;i<16;i++){float p=(float)(2*Math.PI*i/16),q=(float)(2*Math.PI*(i+1)/16);
            quad(m,v,new float[][]{{x+r*(float)Math.cos(p),y,z+r*(float)Math.sin(p)},{x+r*(float)Math.cos(q),y,z+r*(float)Math.sin(q)},
                {x+.18f*(float)Math.cos(q),y+h,z+.18f*(float)Math.sin(q)},{x+.18f*(float)Math.cos(p),y+h,z+.18f*(float)Math.sin(p)}},c,a);}
    }
    private static void rod(MatrixStack m,VertexConsumer v,float x,float y,float z,float r,float h,int c,float a){cylinder(m,v,x,y,z,r,h,c,a,12);}
    private static void cylinder(MatrixStack m,VertexConsumer v,float x,float y,float z,float r,float h,int c,float a,int n) {
        for(int i=0;i<n;i++){float p=(float)(2*Math.PI*i/n),q=(float)(2*Math.PI*(i+1)/n);
            quad(m,v,new float[][]{{x+r*(float)Math.cos(p),y-h/2,z+r*(float)Math.sin(p)},{x+r*(float)Math.cos(q),y-h/2,z+r*(float)Math.sin(q)},
                {x+r*(float)Math.cos(q),y+h/2,z+r*(float)Math.sin(q)},{x+r*(float)Math.cos(p),y+h/2,z+r*(float)Math.sin(p)}},c,a);}
    }
    private static void wheels(MatrixStack m,VertexConsumer v,float t,float a) {
        for(float x:new float[]{-.68f,.68f}) for(float z:new float[]{-.5f,.5f}) ellipsoid(m,v,x,.28f,z,.24f,.24f,.13f,0xFF11151B,a);
    }
    private static void wing(MatrixStack m,VertexConsumer v,float x,float y,float z,float t,float a) {
        m.push();m.translate(x,y,z);m.multiply(new org.joml.Quaternionf().rotateZ((float)Math.sin(t*5)*.22f));
        quad(m,v,new float[][]{{0,0,0},{x*.9f,.6f,.15f},{x*1.8f,.2f,.1f},{x*1.4f,-.55f,0}},0xFF6D2F2C,a);m.pop();
    }
    private static void tail(MatrixStack m,VertexConsumer v,float t,float a) {
        for(int i=0;i<4;i++) ellipsoid(m,v,-.25f-i*.28f,1.15f-i*.08f,.78f+i*.12f,.3f,.16f,.18f,0xFF85372E,a);
    }
    private static void lightning(MatrixStack m,VertexConsumer v,float x,float y,float z,float t,float a) {
        float k=(float)Math.sin(t*18)*.18f;
        quad(m,v,new float[][]{{x-.12f,y,z},{x+.12f,y,z},{x-.08f,y-.65f,z+k},{x-.28f,y-.65f,z+k}},0xFFEAFBFF,a);
        quad(m,v,new float[][]{{x-.28f,y-.65f,z+k},{x-.08f,y-.65f,z+k},{x+.15f,y-1.35f,z-k},{x-.05f,y-1.35f,z-k}},0xFF82DFFF,a);
    }
    private SceneRenderer() {}
}
