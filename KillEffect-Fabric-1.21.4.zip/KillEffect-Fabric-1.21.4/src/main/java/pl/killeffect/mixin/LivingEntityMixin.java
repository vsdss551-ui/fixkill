package pl.killeffect.mixin;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import pl.killeffect.KillEffectMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "onDeath", at = @At("TAIL"))
    private void killeffect$onPlayerKilled(DamageSource source, CallbackInfo ci) {
        LivingEntity victim = (LivingEntity)(Object)this;
        if (!(victim instanceof ServerPlayerEntity dead)) return;
        if (!(source.getAttacker() instanceof ServerPlayerEntity killer)) return;
        if (killer == dead || killer.getServerWorld() != dead.getServerWorld()) return;
        KillEffectMod.broadcastKill(killer, dead);
    }
}
