# KillEffect (Fabric 1.21.4)

12 animowanych scenek po zabiciu gracza: Pac-Man, Police Car, UFO Abduction, Meteor, Shark, Grim Reaper,
Giant Anvil, Black Hole, Dragon, Treasure Chest, Mech Robot, Thunder God.

## Uruchomienie w IntelliJ IDEA
1. File > Open > wskaż folder projektu (plik build.gradle), Gradle JVM = Java 21.
2. Gradle: użyj wersji 8.12+ (Settings > Build Tools > Gradle > Use Gradle from: 'gradle-wrapper.properties'
   lub wskaż własną instalację). Jeśli brak wrappera: w terminalu `gradle wrapper --gradle-version 8.12`.
3. `./gradlew genSources` a potem uruchom konfigurację `Minecraft Client`.
4. Wersję Fabric API w gradle.properties dopasuj do dostępnej dla 1.21.4 (https://modrinth.com/mod/fabric-api).
5. Budowa jara: `./gradlew build` -> build/libs/killeffect-1.0.0.jar (mod musi być też na serwerze).

## Komendy (klient)
/killeffect  |  list  |  preview <nazwa>  |  select <nazwa>  |  toggle

## Architektura
- Serwer: wykrywa zabójstwo gracza, wysyła PlayEffectPayload do graczy w promieniu 128 bloków.
- Klient: FxManager (max 6 równoczesnych, sprzątanie po zakończeniu), Scene (silnik 3D: bryły, powierzchnie
  parametryczne, humanoidy ze skórką ofiary), Tex (proceduralne tekstury 64x64 generowane raz, zwalniane przy rozłączeniu).
- Renderowanie przez standardowe VertexConsumer (WorldRenderEvents.AFTER_ENTITIES) – bez mixinów, zgodne z Sodium.
- Config: config/killeffect.json
