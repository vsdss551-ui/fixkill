package pl.killeffect;

/** Lista efektów współdzielona przez serwer i klienta. */
public enum EffectType {
    PACMAN("pacman", "Pac-Man", Category.RETRO, 130, "Gigantyczny Pac-Man pochłania cel i znika w fajerwerkach."),
    ANVIL("anvil", "Giant Anvil", Category.RETRO, 140, "Ogromne kowadło spada z nieba, a potem rozpada się na kawałki."),
    CHEST("chest", "Treasure Chest", Category.RETRO, 180, "Złota skrzynia otwiera się, wciąga cel i znika w złocie."),
    POLICE("police", "Police Car", Category.MACHINES, 220, "Radiowóz na sygnale, policjant zakuwa i zabiera pokonanego."),
    UFO("ufo", "UFO Abduction", Category.MACHINES, 200, "Zielona wiązka unosi postać prosto do statku kosmicznego."),
    MECH("mech", "Mech Robot", Category.MACHINES, 240, "Bojowy mech chwyta cel w szpony i odlatuje na silnikach."),
    METEOR("meteor", "Meteor", Category.ELEMENTS, 150, "Płonący meteor uderza obok, a fala ognia zmiata cel."),
    THUNDER("thunder", "Thunder God", Category.ELEMENTS, 220, "Burza, pioruny i bóg gromów z młotem."),
    BLACKHOLE("blackhole", "Black Hole", Category.ELEMENTS, 170, "Wirująca czarna dziura wciąga postać i zapada się."),
    SHARK("shark", "Shark", Category.CREATURES, 190, "Ziemia zamienia się w wodę, a rekin połyka ofiarę."),
    REAPER("reaper", "Grim Reaper", Category.CREATURES, 190, "Żniwiarz z kosą zabiera duszę pokonanego."),
    DRAGON("dragon", "Dragon", Category.CREATURES, 220, "Smok zieje ogniem, chwyta cel i odlatuje w niebo.");

    public enum Category {
        RETRO("Retro & Fun"), MACHINES("Maszyny"), ELEMENTS("Żywioły"), CREATURES("Stworzenia");
        public final String title;
        Category(String t) { title = t; }
    }

    public final String id, title, desc;
    public final Category cat;
    public final int ticks;

    EffectType(String id, String title, Category cat, int ticks, String desc) {
        this.id = id; this.title = title; this.cat = cat; this.ticks = ticks; this.desc = desc;
    }

    public static EffectType byId(String s) {
        for (EffectType t : values()) if (t.id.equalsIgnoreCase(s)) return t;
        return null;
    }
}
