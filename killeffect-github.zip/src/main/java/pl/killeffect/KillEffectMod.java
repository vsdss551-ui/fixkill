package pl.killeffect;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class KillEffectMod implements ModInitializer {
    public static final String ID = "killeffect";
    /** Wybory graczy (pamięć; klient wysyła je przy wejściu i po każdej zmianie). */
    private static final Map<UUID, SelectPayload> SELECTION = new ConcurrentHashMap<>();

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(PlayEffectPayload.ID, PlayEffectPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SelectPayload.ID, SelectPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(SelectPayload.ID, (payload, ctx) -> {
            int pct = MathHelper.clamp(payload.percent(), 50, 200);
            SELECTION.put(ctx.player().getUuid(), new SelectPayload(payload.effect(), payload.enabled(), pct));
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> SELECTION.remove(handler.player.getUuid()));

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(entity instanceof ServerPlayerEntity victim)) return;
            if (!(source.getAttacker() instanceof ServerPlayerEntity killer) || killer == victim) return;
            SelectPayload sel = SELECTION.get(killer.getUuid());
            EffectType[] all = EffectType.values();
            if (sel == null || !sel.enabled() || sel.effect() < 0 || sel.effect() >= all.length) return;

            ServerWorld world = (ServerWorld) victim.getWorld();
            BlockPos.Mutable m = victim.getBlockPos().mutableCopy();
            for (int i = 0; i < 24 && world.getBlockState(m.down()).isAir(); i++) m.move(0, -1, 0);
            double y = Math.max(m.getY(), victim.getY() - 24);
            double dx = killer.getX() - victim.getX(), dz = killer.getZ() - victim.getZ();
            float ang = (dx * dx + dz * dz < 0.25) ? -victim.getYaw()
                    : (float) Math.toDegrees(Math.atan2(dx, dz));
            int dur = Math.max(20, all[sel.effect()].ticks * sel.percent() / 100);
            PlayEffectPayload out = new PlayEffectPayload(sel.effect(), victim.getX(), y, victim.getZ(), ang,
                    victim.getUuid(), killer.getUuid(), dur);
            for (ServerPlayerEntity p : PlayerLookup.around(world, victim.getPos(), 128)) {
                ServerPlayNetworking.send(p, out);
            }
        });
    }
}
