package pl.killeffect;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.UUID;

/** S2C: odtwórz KillEffect w danym miejscu. */
public record PlayEffectPayload(int effect, double x, double y, double z, float ang, UUID victim, UUID killer, int duration)
        implements CustomPayload {
    public static final Id<PlayEffectPayload> ID = new Id<>(Identifier.of("killeffect", "play"));
    public static final PacketCodec<RegistryByteBuf, PlayEffectPayload> CODEC =
            PacketCodec.of(PlayEffectPayload::write, PlayEffectPayload::new);

    public PlayEffectPayload(RegistryByteBuf b) {
        this(b.readVarInt(), b.readDouble(), b.readDouble(), b.readDouble(), b.readFloat(), b.readUuid(), b.readUuid(), b.readVarInt());
    }

    public void write(RegistryByteBuf b) {
        b.writeVarInt(effect); b.writeDouble(x); b.writeDouble(y); b.writeDouble(z); b.writeFloat(ang);
        b.writeUuid(victim); b.writeUuid(killer); b.writeVarInt(duration);
    }

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}
