package pl.killeffect;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** C2S: wybrany efekt gracza (serwer musi wiedzieć, jaki efekt odpalić po zabójstwie). */
public record SelectPayload(int effect, boolean enabled, int percent) implements CustomPayload {
    public static final Id<SelectPayload> ID = new Id<>(Identifier.of("killeffect", "select"));
    public static final PacketCodec<RegistryByteBuf, SelectPayload> CODEC =
            PacketCodec.of(SelectPayload::write, SelectPayload::new);

    public SelectPayload(RegistryByteBuf b) { this(b.readVarInt(), b.readBoolean(), b.readVarInt()); }

    public void write(RegistryByteBuf b) { b.writeVarInt(effect); b.writeBoolean(enabled); b.writeVarInt(percent); }

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}
