package pl.killeffect.client;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import pl.killeffect.EffectType;
import pl.killeffect.client.fx.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/** Zarządza aktywnymi scenkami: limit równoczesnych efektów, tick, render, sprzątanie. */
public final class FxManager {
    public static final int MAX_ACTIVE = 6;
    private static final FxEffect[] CACHE = new FxEffect[EffectType.values().length];
    private static final List<Instance> LIST = new ArrayList<>();

    static final class Instance {
        final EffectType type; final FxEffect fx; final Vec3d o; final float ang; final Identifier skin;
        final int dur; final long seed; int age;
        Instance(EffectType type, FxEffect fx, Vec3d o, float ang, Identifier skin, int dur) {
            this.type = type; this.fx = fx; this.o = o; this.ang = ang; this.skin = skin; this.dur = dur;
            this.seed = Double.doubleToLongBits(o.x * 31 + o.z);
        }
    }

    public static FxEffect effect(EffectType t) {
        FxEffect e = CACHE[t.ordinal()];
        if (e == null) {
            e = switch (t) {
                case PACMAN -> new PacmanFx();
                case POLICE -> new PoliceFx();
                case UFO -> new UfoFx();
                case METEOR -> new MeteorFx();
                case SHARK -> new SharkFx();
                case REAPER -> new ReaperFx();
                case ANVIL -> new AnvilFx();
                case BLACKHOLE -> new BlackHoleFx();
                case DRAGON -> new DragonFx();
                case CHEST -> new ChestFx();
                case MECH -> new MechFx();
                case THUNDER -> new ThunderFx();
            };
            CACHE[t.ordinal()] = e;
        }
        return e;
    }

    public static Identifier skinOf(UUID id) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(id);
            if (e != null) return e.getSkinTextures().texture();
        }
        return DefaultSkinHelper.getSkinTextures(id).texture();
    }

    public static void spawn(EffectType t, Vec3d o, float ang, UUID victim, int dur) {
        while (LIST.size() >= MAX_ACTIVE) LIST.remove(0); // najstarszy znika, brak narastania obciążenia
        LIST.add(new Instance(t, effect(t), o, ang, skinOf(victim), Math.max(20, dur)));
    }

    public static void tick(MinecraftClient mc) {
        if (mc.world == null) { LIST.clear(); return; }
        if (mc.isPaused()) return;
        KConfig cfg = KConfig.I;
        int budget = Math.max(12, 70 / Math.max(1, LIST.size()));
        for (Iterator<Instance> it = LIST.iterator(); it.hasNext(); ) {
            Instance i = it.next();
            i.age++;
            if (i.age >= i.dur) { it.remove(); continue; }
            if (mc.gameRenderer.getCamera().getPos().distanceTo(i.o) > cfg.maxDist + 16) continue;
            i.fx.tick(new FxCtx(mc.world, i.o, i.ang, i.age, i.dur, cfg.sound, cfg.particles, budget, i.seed));
        }
    }

    public static void render(WorldRenderContext wc) {
        if (LIST.isEmpty()) return;
        MatrixStack ms = wc.matrixStack();
        VertexConsumerProvider vcp = wc.consumers();
        if (ms == null || vcp == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        Vec3d cam = wc.camera().getPos();
        float pt = mc.getRenderTickCounter().getTickDelta(false);
        int maxD = KConfig.I.maxDist;
        for (Instance i : LIST) {
            if (cam.distanceTo(i.o) > maxD) continue;
            float t = i.age + pt;
            float p = Math.min(1f, t / i.dur);
            ms.push();
            ms.translate(i.o.x - cam.x, i.o.y - cam.y, i.o.z - cam.z);
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i.ang));
            i.fx.render(new Scene(ms, vcp, i.fx.texture(), i.skin, p, t, i.dur));
            ms.pop();
        }
    }

    /** Siła białego błysku dla gracza (0..1), zależna od odległości. */
    public static float flash(MinecraftClient mc) {
        if (LIST.isEmpty() || mc.player == null) return 0;
        float f = 0;
        float pt = mc.getRenderTickCounter().getTickDelta(false);
        for (Instance i : LIST) {
            double d = mc.player.getPos().distanceTo(i.o);
            if (d > 40) continue;
            float p = Math.min(1f, (i.age + pt) / i.dur);
            f = Math.max(f, i.fx.flash(p) * (float) (1 - d / 40));
        }
        return Math.min(.85f, f);
    }

    public static void clear() {
        LIST.clear();
        java.util.Arrays.fill(CACHE, null);
        Tex.clear();
    }
}
