package pl.killeffect.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Konfiguracja klienta: config/killeffect.json. */
public final class KConfig {
    public int selected = 0;
    public boolean enabled = true, sound = true, particles = true, showOthers = true;
    public int durationPct = 100, maxDist = 96;

    public static KConfig I = new KConfig();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("killeffect.json"); }

    public static void load() {
        try {
            if (Files.exists(path())) {
                KConfig c = GSON.fromJson(Files.readString(path()), KConfig.class);
                if (c != null) I = c;
            }
        } catch (Exception ignored) { }
        I.durationPct = Math.max(50, Math.min(200, I.durationPct));
        I.maxDist = Math.max(16, Math.min(128, I.maxDist));
        if (I.selected < 0 || I.selected >= pl.killeffect.EffectType.values().length) I.selected = 0;
    }

    public static void save() {
        try { Files.writeString(path(), GSON.toJson(I)); } catch (Exception ignored) { }
    }
}
