package pl.killeffect.client;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import pl.killeffect.EffectType;
import pl.killeffect.PlayEffectPayload;
import pl.killeffect.SelectPayload;

import java.util.Arrays;

public class KillEffectClient implements ClientModInitializer {
    private static boolean openGui;

    @Override
    public void onInitializeClient() {
        KConfig.load();

        ClientPlayNetworking.registerGlobalReceiver(PlayEffectPayload.ID, (payload, ctx) -> {
            KConfig c = KConfig.I;
            MinecraftClient mc = ctx.client();
            if (!c.enabled || mc.player == null) return;
            boolean own = payload.killer().equals(mc.player.getUuid());
            if (!own && !c.showOthers) return;
            EffectType[] all = EffectType.values();
            if (payload.effect() < 0 || payload.effect() >= all.length) return;
            Vec3d o = new Vec3d(payload.x(), payload.y(), payload.z());
            if (mc.player.getPos().distanceTo(o) > c.maxDist) return;
            FxManager.spawn(all[payload.effect()], o, payload.ang(), payload.victim(), payload.duration());
        });

        ClientPlayConnectionEvents.JOIN.register((h, s, mc) -> sync());
        ClientPlayConnectionEvents.DISCONNECT.register((h, mc) -> FxManager.clear());
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            FxManager.tick(mc);
            if (openGui) { openGui = false; mc.setScreen(new KillEffectScreen()); }
        });
        WorldRenderEvents.AFTER_ENTITIES.register(FxManager::render);
        HudRenderCallback.EVENT.register((ctx, tc) -> {
            float f = FxManager.flash(MinecraftClient.getInstance());
            if (f > .01f && KConfig.I.particles) {
                int a = (int) (f * 255);
                ctx.fill(0, 0, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight(), (a << 24) | 0xFFFFFF);
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> {
            var names = Arrays.stream(EffectType.values()).map(t -> t.id).toList();
            dispatcher.register(ClientCommandManager.literal("killeffect")
                    .executes(c -> { openGui = true; return 1; })
                    .then(ClientCommandManager.literal("list").executes(c -> {
                        c.getSource().sendFeedback(Text.literal("KillEffecty:").formatted(Formatting.AQUA));
                        for (EffectType t : EffectType.values()) {
                            boolean sel = t.ordinal() == KConfig.I.selected;
                            c.getSource().sendFeedback(Text.literal((sel ? " ▶ " : "   ") + t.id + " – " + t.title + " (" + t.cat.title + ")")
                                    .formatted(sel ? Formatting.GREEN : Formatting.GRAY));
                        }
                        return 1;
                    }))
                    .then(ClientCommandManager.literal("preview").then(ClientCommandManager.argument("nazwa", StringArgumentType.word())
                            .suggests((c, b) -> CommandSource.suggestMatching(names, b))
                            .executes(c -> {
                                EffectType t = EffectType.byId(StringArgumentType.getString(c, "nazwa"));
                                if (t == null) { c.getSource().sendError(Text.literal("Nie ma takiego efektu. Użyj /killeffect list")); return 0; }
                                previewWorld(t);
                                return 1;
                            })))
                    .then(ClientCommandManager.literal("select").then(ClientCommandManager.argument("nazwa", StringArgumentType.word())
                            .suggests((c, b) -> CommandSource.suggestMatching(names, b))
                            .executes(c -> {
                                EffectType t = EffectType.byId(StringArgumentType.getString(c, "nazwa"));
                                if (t == null) { c.getSource().sendError(Text.literal("Nie ma takiego efektu. Użyj /killeffect list")); return 0; }
                                KConfig.I.selected = t.ordinal(); KConfig.save(); sync();
                                c.getSource().sendFeedback(Text.literal("Wybrano KillEffect: " + t.title).formatted(Formatting.GREEN));
                                return 1;
                            })))
                    .then(ClientCommandManager.literal("toggle").executes(c -> {
                        KConfig.I.enabled = !KConfig.I.enabled; KConfig.save(); sync();
                        c.getSource().sendFeedback(Text.literal("KillEffecty: " + (KConfig.I.enabled ? "WŁĄCZONE" : "WYŁĄCZONE"))
                                .formatted(KConfig.I.enabled ? Formatting.GREEN : Formatting.RED));
                        return 1;
                    })));
        });
    }

    /** Wysyła wybór do serwera (to serwer odpala efekt po zabójstwie). */
    public static void sync() {
        if (!ClientPlayNetworking.canSend(SelectPayload.ID)) return;
        KConfig c = KConfig.I;
        ClientPlayNetworking.send(new SelectPayload(c.selected, c.enabled, c.durationPct));
    }

    /** Podgląd w świecie: scena kilka bloków przed graczem, akcja nadchodzi od strony gracza. */
    public static void previewWorld(EffectType t) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        Vec3d look = mc.player.getRotationVec(1f);
        double hx = look.x, hz = look.z, l = Math.sqrt(hx * hx + hz * hz);
        if (l < 1e-4) { hx = 0; hz = 1; l = 1; }
        hx /= l; hz /= l;
        Vec3d o = mc.player.getPos().add(hx * 9, 0, hz * 9);
        float ang = (float) Math.toDegrees(Math.atan2(-hx, -hz));
        int dur = Math.max(20, t.ticks * KConfig.I.durationPct / 100);
        FxManager.spawn(t, o, ang, mc.player.getUuid(), dur);
    }
}
