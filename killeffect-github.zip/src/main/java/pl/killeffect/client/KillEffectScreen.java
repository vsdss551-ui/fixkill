package pl.killeffect.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import pl.killeffect.EffectType;
import pl.killeffect.client.fx.FxEffect;
import pl.killeffect.client.fx.Scene;


import java.util.ArrayList;
import java.util.List;

/** Natywne GUI KillEffect, odwzorowanie stylu z index.html (ciemny szklany panel, akcent niebieski, karty, przełączniki). */
public class KillEffectScreen extends Screen {
    private static final int PW = 780, PH = 520;
    private static final int ACCENT = 0xFF5BB8F5, TEXT = 0xFFF2F5FA, MUTED = 0xFF8C96A6, PANEL = 0xF20D0F14, CARD = 0xFF151922, CARD2 = 0xFF1B2030, GREEN = 0xFF3FD69A;
    private static final String[] CATS = {"Wszystkie", "Retro & Fun", "Maszyny", "Żywioły", "Stworzenia"};

    private float open, dragK, scroll, scrollT, prevT, rotY = 28;
    private long last = System.nanoTime();
    private int cat = -1, view;
    private float ox, oy, k = 1;
    private final float[] hov = new float[12], catHov = new float[5], tog = new float[4];
    private float btnA, btnB, closeH;
    private int drag = -1;
    private final List<EffectType> shown = new ArrayList<>();

    public KillEffectScreen() {
        super(Text.literal("KillEffect"));
        view = KConfig.I.selected;
        for (int i = 0; i < 4; i++) tog[i] = get(i) ? 1 : 0;
        rebuild();
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext c, int mx, int my, float d) { c.fillGradient(0, 0, width, height, 0xB0090B10, 0xD0090B10); }

    private boolean get(int i) { KConfig c = KConfig.I; return switch (i) { case 0 -> c.enabled; case 1 -> c.sound; case 2 -> c.particles; default -> c.showOthers; }; }
    private void flip(int i) {
        KConfig c = KConfig.I;
        switch (i) { case 0 -> c.enabled = !c.enabled; case 1 -> c.sound = !c.sound; case 2 -> c.particles = !c.particles; default -> c.showOthers = !c.showOthers; }
        KConfig.save(); KillEffectClient.sync();
    }

    private void rebuild() {
        shown.clear();
        for (EffectType t : EffectType.values()) if (cat < 0 || t.cat.ordinal() == cat) shown.add(t);
        scroll = scrollT = 0;
    }

    // ---------- rysowanie pomocnicze ----------
    private static int al(int c, float a) { int al = (int) (((c >>> 24) & 255) * Math.max(0, Math.min(1, a))); return (al << 24) | (c & 0xFFFFFF); }
    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t), bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
    private static void rr(DrawContext c, int x, int y, int w, int h, int r, int col) {
        c.fill(x, y + r, x + w, y + h - r, col);
        for (int i = 0; i < r; i++) {
            int in = r - (int) Math.round(Math.sqrt(r * r - (r - i - .5) * (r - i - .5)));
            c.fill(x + in, y + i, x + w - in, y + i + 1, col);
            c.fill(x + in, y + h - i - 1, x + w - in, y + h - i, col);
        }
    }
    private static void card(DrawContext c, int x, int y, int w, int h, int r, int fill, int border) { rr(c, x, y, w, h, r, border); rr(c, x + 1, y + 1, w - 2, h - 2, Math.max(1, r - 1), fill); }
    private void txt(DrawContext c, String s, int x, int y, int col) { c.drawText(textRenderer, s, x, y, col, false); }
    private void txtS(DrawContext c, String s, int x, int y, int col, float sc) {
        MatrixStack m = c.getMatrices(); m.push(); m.translate(x, y, 0); m.scale(sc, sc, 1);
        c.drawText(textRenderer, s, 0, 0, col, false); m.pop();
    }
    private void ctr(DrawContext c, String s, int cx, int y, int col) { c.drawText(textRenderer, s, cx - textRenderer.getWidth(s) / 2, y, col, false); }
    private static float lp(float v, float t, float dt, float sp) { return v + (t - v) * (1 - (float) Math.exp(-dt * sp)); }
    private boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    private static final String[][] ICON = {
            {"   YYYYYY   ", " YYYYYYYYYY ", "YYYYYYKYYY  ", "YYYYYYYYY   ", "YYYYYYYY    ", "YYYYYY      ", "YYYYYYYY    ", "YYYYYYYYY   ", "YYYYYYYYYY  ", " YYYYYYYYYY ", "   YYYYYY   "},
            {"            ", "     R B    ", "   WWWWWW   ", "  WCCWWCCW  ", " WWWWWWWWWW ", " BBBBBBBBBB ", " WWWWWWWWWW ", "  KK    KK  ", "  KK    KK  "},
            {"    GGGG    ", "   GCCCCG   ", "  GGGGGGGG  ", " GGGGGGGGGG ", "  LGLGLGLG  ", "     LL     ", "    LLLL    ", "   LLLLLL   ", "  LLLLLLLL  "},
            {"          RR", "        RROO", "      RROOY ", "    KKOOYY  ", "   KKKKROY  ", "  KKKKKKR   ", "  KKKKKK    ", "   KKKK     "},
            {"       G    ", "      GG    ", "     GGG    ", "BBBBBGGGGBBB", "BBBGGGGGGGGB", "BBGGGKGGWWWB", "BBBBBGGWWWBB", "BBBBBBBBBBBB"},
            {"    KKKK    ", "   KKKKKK   ", "   KWKKWK   ", "   KKKKKK  N", "  KKKKKKKKN ", "  KKKKKKKN  ", " KKKKKKKNKK ", " KKKKKKNKKK ", "KKKKKKKNKKKK"},
            {"  GGGGGGGG  ", "  GGGGGGGG  ", "  GGGGGGGG  ", "    GGGG    ", "   GGGGGG   ", "  GGGGGGGG  ", " GGGGGGGGGG ", " KKKKKKKKKK "},
            {"     PPPP   ", "   PPOOOPP  ", "  POOYYOOP  ", " POYYWWYYOP ", " POYYWWYYOP ", "  POOYYOOP  ", "   PPOOOPP  ", "     PPPP   "},
            {"    YYYYYY  ", "   YKKKKKKY ", "  YKGGGGGKY ", "  YKGDDDGKY ", "  YKGGGGGKY ", "  YKKKKKKKY ", "  YYYYYYYYY "},
            {"   K    K   ", "   KK  KK   ", " KKKKKKKKKK ", " KKGKKKKGKK ", "  KKKKKKKK  ", "  KKKKKKKK  ", "   OOOOOO   "},
            {"    O      O", "   ROO   OR ", "  RRROOOORRR", "   RRRRRRRR ", "    GGGGGG  ", "   GGGGGGGG ", "  RRGGGGGGRR", "   RRRRRRRR "},
            {"        YY  ", "       YYY  ", "      YY    ", "     YYY    ", "   YYYYY    ", "    YYYYY   ", "      YY    ", "     YY     ", "    Y       "},
    };
    private static final int[] ICON_MAP = {0, 9, 8, 1, 2, 6, 3, 11, 7, 4, 5, 10};

    private static int pal(char ch) {
        return switch (ch) {
            case 'Y' -> 0xFFFFD21A; case 'K' -> 0xFF15171C; case 'W' -> 0xFFF2F4F7; case 'G' -> 0xFF8E97A4; case 'R' -> 0xFFE03030;
            case 'B' -> 0xFF2F6BFF; case 'O' -> 0xFFFF8A20; case 'C' -> 0xFF5CE0FF; case 'L' -> 0xFF7CFF8C; case 'P' -> 0xFF9A40FF;
            case 'N' -> 0xFF8A5A2A; case 'D' -> 0xFFF2C230; default -> 0;
        };
    }

    private void icon(DrawContext c, int idx, int x, int y, int px, float a) {
        String[] rows = ICON[ICON_MAP[idx]];
        for (int j = 0; j < rows.length; j++)
            for (int i = 0; i < rows[j].length(); i++) {
                int col = pal(rows[j].charAt(i));
                if (col != 0) c.fill(x + i * px, y + j * px, x + (i + 1) * px, y + (j + 1) * px, al(col, a));
            }
    }

    // ---------- render ----------
    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(.1f, (now - last) / 1e9f); last = now;
        open = lp(open, 1, dt, 9);
        prevT += dt * 20;
        rotY += dt * 14;
        scroll = lp(scroll, scrollT, dt, 14);
        k = Math.min(1f, Math.min((width - 8f) / PW, (height - 8f) / PH));
        ox = (width - PW * k) / 2f; oy = (height - PH * k) / 2f + (1 - open) * 18 * k;
        renderBackground(c, mouseX, mouseY, delta);
        double mx = (mouseX - ox) / k, my = (mouseY - oy) / k;
        float a = open;

        MatrixStack ms = c.getMatrices();
        ms.push(); ms.translate(ox, oy, 0); ms.scale(k, k, 1);

        card(c, 0, 0, PW, PH, 14, al(PANEL, a), al(0xFF2A3140, a));
        // nagłówek
        rr(c, 18, 16, 6, 26, 3, al(ACCENT, a));
        txtS(c, "KillEffect", 34, 14, al(TEXT, a), 1.7f);
        txt(c, "Animacje po zabójstwie  •  /killeffect", 36, 33, al(MUTED, a));
        EffectType sel = EffectType.values()[KConfig.I.selected];
        String act = "Aktywny: " + sel.title;
        int pw = textRenderer.getWidth(act) + 26;
        rr(c, PW - 70 - pw, 19, pw, 22, 11, al(0x305BB8F5, a)); rr(c, PW - 70 - pw + 9, 28, 5, 5, 2, al(GREEN, a));
        txt(c, act, PW - 70 - pw + 19, 26, al(ACCENT, a));
        closeH = lp(closeH, in(mx, my, PW - 52, 14, 34, 34) ? 1 : 0, dt, 16);
        rr(c, PW - 52, 14, 34, 34, 10, al(mix(CARD2, 0xFF3A2030, closeH), a));
        ctr(c, "✕", PW - 35, 26, al(mix(MUTED, 0xFFFF6A7A, closeH), a));
        c.fill(18, 56, PW - 18, 57, al(0xFF232A38, a));

        // kategorie
        txt(c, "KATEGORIE", 20, 68, al(MUTED, a));
        for (int i = 0; i < CATS.length; i++) {
            int y = 84 + i * 40; boolean s = cat == i - 1;
            catHov[i] = lp(catHov[i], in(mx, my, 16, y, 150, 34) ? 1 : 0, dt, 16);
            int bg = s ? 0x335BB8F5 : mix(0x00151922, 0xFF1B2030, catHov[i]);
            rr(c, 16, y, 150, 34, 10, al(bg, a * (s ? 1 : .25f + .75f * catHov[i])));
            if (s) rr(c, 16, y + 8, 3, 18, 1, al(ACCENT, a));
            txt(c, CATS[i], 30 + (int) (catHov[i] * 3), y + 13, al(s ? ACCENT : mix(MUTED, TEXT, catHov[i]), a));
        }

        // lista efektów (z przewijaniem)
        txt(c, "EFEKTY  " + shown.size(), 184, 68, al(MUTED, a));
        int listX = 176, listY = 84, listW = 232, listH = PH - 84 - 14;
        float maxScroll = Math.max(0, shown.size() * 56 - listH);
        scrollT = Math.max(0, Math.min(maxScroll, scrollT));
        c.enableScissor((int) (ox + listX * k), (int) (oy + listY * k), (int) (ox + (listX + listW) * k), (int) (oy + (listY + listH) * k));
        for (int i = 0; i < shown.size(); i++) {
            EffectType t = shown.get(i);
            int y = listY + i * 56 - (int) scroll;
            if (y + 50 < listY || y > listY + listH) continue;
            boolean hv = in(mx, my, listX, y, listW - 8, 50) && in(mx, my, listX, listY, listW, listH);
            hov[t.ordinal()] = lp(hov[t.ordinal()], hv ? 1 : 0, dt, 16);
            boolean vs = view == t.ordinal(), act2 = KConfig.I.selected == t.ordinal();
            int off = (int) (hov[t.ordinal()] * 4);
            card(c, listX + off, y, listW - 8, 50, 12, al(mix(CARD, CARD2, hov[t.ordinal()]), a), al(vs ? ACCENT : 0xFF262D3C, a));
            rr(c, listX + off + 8, y + 7, 36, 36, 9, al(0xFF0E1118, a));
            icon(c, t.ordinal(), listX + off + 12, y + 12, 2, a);
            txt(c, t.title, listX + off + 54, y + 12, al(TEXT, a));
            txt(c, t.cat.title, listX + off + 54, y + 27, al(MUTED, a));
            if (act2) { rr(c, listX + listW - 40 + off, y + 17, 22, 16, 8, al(0x403FD69A, a)); ctr(c, "✔", listX + listW - 29 + off, y + 21, al(GREEN, a)); }
        }
        c.disableScissor();

        // prawa kolumna
        int rx = 424, rw = 338;
        EffectType vt = EffectType.values()[view];
        drawPreview(c, rx, 68, rw, 200, vt, a, mx, my);
        txtS(c, vt.title, rx, 278, al(TEXT, a), 1.5f);
        txt(c, vt.cat.title + "  •  " + (vt.ticks * KConfig.I.durationPct / 100 / 20f) + " s", rx, 296, al(ACCENT, a));
        int ly = 310;
        for (var line : textRenderer.wrapLines(Text.literal(vt.desc), rw)) { c.drawText(textRenderer, line, rx, ly, al(MUTED, a), false); ly += 10; }
        // przyciski
        boolean isAct = KConfig.I.selected == view;
        btnA = lp(btnA, in(mx, my, rx, 336, 168, 32) ? 1 : 0, dt, 16);
        btnB = lp(btnB, in(mx, my, rx + 178, 336, 160, 32) ? 1 : 0, dt, 16);
        rr(c, rx, 336, 168, 32, 10, al(isAct ? mix(0xFF1F6B4D, 0xFF2A8A64, btnA) : mix(0xFF3B8FD0, ACCENT, btnA), a));
        ctr(c, isAct ? "✔ Wybrany" : "Aktywuj", rx + 84, 348, al(0xFF081018, a));
        card(c, rx + 178, 336, 160, 32, 10, al(mix(CARD, CARD2, btnB), a), al(mix(0xFF2A3140, ACCENT, btnB), a));
        ctr(c, "▶ Podgląd w świecie", rx + 258, 348, al(TEXT, a));

        // ustawienia
        card(c, rx, 378, rw, 130, 12, al(CARD, a), al(0xFF262D3C, a));
        String[] tn = {"Efekty włączone", "Dźwięki", "Cząsteczki", "Widoczne dla innych"};
        for (int i = 0; i < 4; i++) {
            int tx = rx + 12 + (i % 2) * 164, ty = 388 + (i / 2) * 24;
            tog[i] = lp(tog[i], get(i) ? 1 : 0, dt, 18);
            rr(c, tx, ty, 30, 16, 8, al(mix(0xFF2A3140, ACCENT, tog[i]), a));
            rr(c, tx + 2 + (int) (tog[i] * 14), ty + 2, 12, 12, 6, al(0xFFFFFFFF, a));
            txt(c, tn[i], tx + 38, ty + 4, al(get(i) ? TEXT : MUTED, a));
        }
        slider(c, rx + 12, 440, rw - 24, "Czas trwania", KConfig.I.durationPct + "%", (KConfig.I.durationPct - 50) / 150f, a);
        slider(c, rx + 12, 474, rw - 24, "Zasięg renderowania", KConfig.I.maxDist + " bl.", (KConfig.I.maxDist - 16) / 112f, a);
        ms.pop();
        scrollT = Math.max(0, Math.min(maxScroll, scrollT));
    }

    private void slider(DrawContext c, int x, int y, int w, String name, String val, float f, float a) {
        txt(c, name, x, y, al(MUTED, a));
        int vw = textRenderer.getWidth(val);
        txt(c, val, x + w - vw, y, al(TEXT, a));
        rr(c, x, y + 14, w, 6, 3, al(0xFF2A3140, a));
        rr(c, x, y + 14, Math.max(6, (int) (w * f)), 6, 3, al(ACCENT, a));
        rr(c, x + (int) ((w - 12) * f), y + 11, 12, 12, 6, al(0xFFFFFFFF, a));
    }

    private void drawPreview(DrawContext c, int x, int y, int w, int h, EffectType t, float a, double mx, double my) {
        card(c, x, y, w, h, 12, al(0xFF0B0E14, a), al(0xFF262D3C, a));
        c.fillGradient(x + 1, y + 1, x + w - 1, y + h - 1, al(0xFF171E2C, a), al(0xFF0A0D13, a));
        // scena
        int clipX1 = (int) (ox + (x + 2) * k), clipY1 = (int) (oy + (y + 2) * k), clipX2 = (int) (ox + (x + w - 2) * k), clipY2 = (int) (oy + (y + h - 2) * k);
        c.enableScissor(clipX1, clipY1, clipX2, clipY2);
        FxEffect fx = FxManager.effect(t);
        float dur = t.ticks;
        float loop = dur + 30;
        float tt = prevT % loop, p = Math.min(1f, tt / dur);
        MatrixStack ms = c.getMatrices();
        ms.push();
        ms.translate(x + w / 2f, y + h * .80f, 150f);
        float sc = 6.2f;
        ms.scale(sc, -sc, sc);
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(17));
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(25 + 12 * (float) Math.sin(rotY * .05)));
        DiffuseLighting.enableGuiDepthLighting();
        RenderSystem.enableDepthTest();
        Identifier skin = FxManager.skinOf(MinecraftClient.getInstance().player != null ? MinecraftClient.getInstance().player.getUuid() : java.util.UUID.randomUUID());
        fx.render(new Scene(ms, c.getVertexConsumers(), fx.texture(), skin, p, tt, dur));
        c.draw();
        ms.pop();
        c.disableScissor();
        // pasek postępu
        c.fill(x + 12, y + h - 12, x + w - 12, y + h - 10, al(0xFF2A3140, a));
        c.fill(x + 12, y + h - 12, x + 12 + (int) ((w - 24) * p), y + h - 10, al(ACCENT, a));
        ms.push(); ms.translate(0, 0, 400);
        txt(c, "PODGLĄD 3D", x + 12, y + 10, al(0xFF6C7686, a));
        ms.pop();
    }

    // ---------- wejście ----------
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        double mx = (mouseX - ox) / k, my = (mouseY - oy) / k;
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        if (in(mx, my, PW - 52, 14, 34, 34)) { close(); return true; }
        for (int i = 0; i < CATS.length; i++) if (in(mx, my, 16, 84 + i * 40, 150, 34)) { cat = i - 1; rebuild(); return true; }
        int listX = 176, listY = 84, listW = 232, listH = PH - 98;
        if (in(mx, my, listX, listY, listW, listH)) {
            for (int i = 0; i < shown.size(); i++) {
                int y = listY + i * 56 - (int) scroll;
                if (in(mx, my, listX, y, listW - 8, 50)) { view = shown.get(i).ordinal(); prevT = 0; return true; }
            }
        }
        int rx = 424, rw = 338;
        if (in(mx, my, rx, 336, 168, 32)) { KConfig.I.selected = view; KConfig.save(); KillEffectClient.sync(); return true; }
        if (in(mx, my, rx + 178, 336, 160, 32)) { KillEffectClient.previewWorld(EffectType.values()[view]); close(); return true; }
        for (int i = 0; i < 4; i++) if (in(mx, my, rx + 12 + (i % 2) * 164, 388 + (i / 2) * 24, 160, 18)) { flip(i); return true; }
        if (in(mx, my, rx + 12, 450, rw - 24, 16)) { drag = 0; setSlider(mx); return true; }
        if (in(mx, my, rx + 12, 484, rw - 24, 16)) { drag = 1; setSlider(mx); return true; }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void setSlider(double mx) {
        int rx = 424, w = 338 - 24;
        float f = (float) Math.max(0, Math.min(1, (mx - (rx + 12)) / w));
        if (drag == 0) KConfig.I.durationPct = 50 + Math.round(f * 30) * 5;
        else if (drag == 1) KConfig.I.maxDist = 16 + Math.round(f * 14) * 8;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (drag >= 0) { setSlider((mouseX - ox) / k); return true; }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (drag >= 0) { drag = -1; KConfig.save(); KillEffectClient.sync(); return true; }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double h, double v) {
        scrollT -= (float) v * 40;
        float max = Math.max(0, shown.size() * 56 - (PH - 98));
        scrollT = Math.max(0, Math.min(max, scrollT));
        return true;
    }
}
