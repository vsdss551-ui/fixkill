package pl.killeffect.client.fx;

import net.minecraft.block.Blocks;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import pl.killeffect.EffectType;

public final class AnvilFx extends FxEffect {
    static final float K = 3.4f;
    public AnvilFx() { super(EffectType.ANVIL); }

    @Override protected String[] tiles() {
        return new String[]{"m:3C3C42", "p:2A2A30", "m:6C6C76", "r:6A3A28", "s:000000:8C", "g:C0B8A0:100", "g:FFD070:230", "g:FFFFFF:140"};
    }

    static float y(float p) {
        if (p < .42f) return 34 * (1 - easeIn(p / .42f));
        if (p < .56f) { float q = seg(p, .42f, .56f); return .9f * sin(q * PI) * (1 - q); }
        return 0;
    }

    private void anvil(Scene s) {
        s.box(1, 0, .12f, 0, 1f, .25f, .75f);
        s.box(0, 0, .37f, 0, .62f, .25f, .5f);
        s.box(0, 0, .65f, 0, .4f, .32f, .4f);
        s.box(0, 0, .98f, 0, 1f, .38f, .62f);
        s.box(2, 0, 1.18f, 0, 1.0f, .02f, .62f);
        s.box(3, -.2f, .36f, .26f, .2f, .15f, .02f);
        s.push(); s.tr(.5f, 1.0f, 0); s.rz(-90); s.cyl(Scene.SOLID, 0, .3f, .08f, .75f, 12); s.pop();
        s.push(); s.tr(-.5f, .98f, 0); s.box(1, 0, 0, 0, .05f, .36f, .6f); s.pop();
    }

    @Override public void render(Scene s) {
        final float p = s.p, t = s.t, ay = y(p);
        float fall = p < .42f ? p / .42f : 1;
        // cień
        if (p < .8f) {
            float r = lerp(.4f, K * .75f, easeIn(fall));
            s.push(); s.tr(0, .03f, 0); s.alpha(.35f + .3f * fall); s.cyl(Scene.TRANS, 4, r, r, .01f, 22); s.white(); s.pop();
        }
        // ofiara: spłaszczona
        float sq = p < .42f ? 0 : sm(seg(p, .42f, .46f));
        float vk = p < .62f ? 1 : 1 - sm(seg(p, .62f, .66f));
        if (p < .66f) {
            float pan = p < .42f ? sin(t * 1.2f) * 20 : 0;
            victim(s, 0, 0, 0, 0, 0, lerp(1, 1.4f, sq) * vk, lerp(1, .06f, sq) * vk, lerp(1, 1.4f, sq) * vk, -150 + pan, -150 - pan, pan * .5f, -pan * .5f);
        }
        // smuga spadania
        if (p < .42f) {
            s.push(); s.tr(0, ay + 2.5f, 0); s.alpha(.35f); s.cyl(Scene.GLOW, 5, 0, K * .55f, 30, 12); s.white(); s.pop();
        }
        // kowadło / kawałki
        if (p < .8f) {
            s.push(); s.tr(0, ay + (p >= .42f ? 0.12f * K * 0 : 0), 0);
            s.ry(p < .42f ? 12 * sin(t * .3f) : 12);
            float sh = p >= .42f && p < .8f ? 1 + .012f * sin(t * 2f) * (p > .7f ? 6 : 0) : 1;
            s.sc(K * sh);
            anvil(s);
            s.pop();
        } else {
            float q = seg(p, .8f, 1);
            for (int i = 0; i < 9; i++) {
                float a = i * 0.698f + .3f, sp = 4 + (i % 3) * 2.2f;
                float fx = cos(a) * sp * q, fz = sin(a) * sp * q;
                float fy = 1.6f + (3.5f + (i % 4)) * q - 9f * q * q;
                float sc = (1 - q) * (.7f + (i % 3) * .25f) * K * .5f;
                if (fy < .1f) fy = .1f;
                s.push(); s.tr(fx, fy, fz); s.rx(q * 500 * (i % 2 == 0 ? 1 : -1)); s.ry(q * 300); s.sc(sc);
                s.box(i % 2 == 0 ? 0 : 1, 0, 0, 0, 1.0f, .7f, .8f);
                s.pop();
            }
        }
        // fala uderzeniowa i pęknięcia
        if (p >= .42f) {
            float w = seg(p, .42f, .58f);
            if (w < 1) {
                s.push(); s.tr(0, .12f, 0); s.alpha(.8f * (1 - w)); float r = lerp(1, 9, easeOut(w)); s.cyl(Scene.GLOW, 7, r, r, .25f, 28); s.white(); s.pop();
            }
            float cr = 1 - sm(seg(p, .85f, 1));
            for (int i = 0; i < 8; i++) {
                float a = i * .785f + .2f, len = (3 + (i % 3)) * sm(seg(p, .42f, .5f)) * cr;
                s.push(); s.tr(0, .035f, 0); s.ry(deg(a)); s.box(1, len / 2 + .5f, 0, 0, len, .04f, .12f); s.pop();
            }
        }
    }

    @Override public void tick(FxCtx c) {
        float p = c.p;
        if (c.at(.02f)) c.snd(SoundEvents.ENTITY_PHANTOM_SWOOP, 0, 15, 0, 2f, .6f);
        if (p < .4f && c.every(4)) c.snd(SoundEvents.BLOCK_ANVIL_FALL, 0, y(p), 0, 1.5f, .6f);
        if (p < .42f && c.every(2)) c.par(ParticleTypes.CLOUD, (c.r.nextFloat() - .5f) * 2, y(p) + 2, (c.r.nextFloat() - .5f) * 2, 0, .2, 0);
        if (c.at(.42f)) {
            c.snd(SoundEvents.BLOCK_ANVIL_LAND, 0, 0, 0, 3f, .5f);
            c.snd(SoundEvents.ENTITY_GENERIC_EXPLODE, 0, 0, 0, 2f, .8f);
            c.burst(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.ANVIL.getDefaultState()), 50, 0, .3, 0, .5);
            c.burst(ParticleTypes.CLOUD, 40, 0, .3, 0, .5);
            c.burst(ParticleTypes.CRIT, 30, 0, .5, 0, .7);
        }
        if (c.at(.5f)) c.snd(SoundEvents.BLOCK_ANVIL_LAND, 0, 0, 0, 2f, .9f);
        if (c.at(.62f)) { c.burst(ParticleTypes.POOF, 25, 0, .3, 0, .25); c.burst(ParticleTypes.ENCHANTED_HIT, 20, 0, .6, 0, .5); }
        if (c.at(.8f)) {
            c.snd(SoundEvents.BLOCK_ANVIL_DESTROY, 0, 1, 0, 2.5f, .8f);
            c.burst(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.ANVIL.getDefaultState()), 60, 0, 1, 0, .6);
            c.burst(ParticleTypes.LARGE_SMOKE, 15, 0, 1, 0, .2);
        }
    }
}
