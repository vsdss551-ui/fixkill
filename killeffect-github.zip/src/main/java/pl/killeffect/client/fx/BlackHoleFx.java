package pl.killeffect.client.fx;

import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import pl.killeffect.EffectType;

public final class BlackHoleFx extends FxEffect {
    static final float CX = 0, CY = 2.3f, CZ = 2.6f;
    public BlackHoleFx() { super(EffectType.BLACKHOLE); }

    @Override protected String[] tiles() {
        return new String[]{"s:030206", "g:FF8A2A:BE", "g:9A40FF:AA", "g:FFF2D8:DC", "g:50A0FF:96", "g:FFFFFF:FF"};
    }

    static float size(float p) {
        return sm(seg(p, 0, .18f)) * (1 + .08f * (float) Math.sin(p * 40)) * (1 - sm(seg(p, .78f, .95f)));
    }

    @Override public void render(Scene s) {
        final float p = s.p, t = s.t, S = size(p);
        // ofiara wciągana spiralą
        float q = seg(p, .22f, .64f), e = easeIn(q);
        if (q < 1) {
            float ang = 2 * PI * 2.4f * e;
            float rr = (1 - e) * 1.4f;
            float vx = lerp(0, CX, e) + cos(ang) * rr * .5f, vy = lerp(0, CY - .9f, e) + sin(ang) * rr * .25f, vz = lerp(0, CZ, e) + sin(ang) * rr * .5f;
            float k = (float) Math.pow(1 - e, .55f);
            float fl = sin(t * .8f) * 30;
            victim(s, vx, vy, vz, e * 720, -70 * e, (1 - e * .5f) * k, (1 + e * 1.4f) * k, (1 - e * .5f) * k, -150 + fl, -150 - fl, fl * .5f, -fl * .5f);
        }
        if (S < .02f) return;
        s.push();
        s.tr(CX, CY, CZ);
        s.sc(S);
        // horyzont zdarzeń
        s.sph(Scene.SOLID, 0, 1.5f, 18);
        // dysk akrecyjny: rotujące łuki
        s.push(); s.rx(72); s.rz(14);
        for (int i = 0; i < 6; i++) {
            float r0 = 1.9f + i * .55f, r1 = r0 + .5f;
            float spd = (2.6f - i * .3f) * t * .05f;
            for (int sgm = 0; sgm < 4; sgm++) {
                float a0 = spd + sgm * 1.5708f + i * .5f;
                s.alpha(.85f - i * .08f);
                s.ring(Scene.GLOW, i == 0 ? 3 : (i % 2 == 0 ? 2 : 1), r0, r1, a0, a0 + 1.0f, 8);
            }
        }
        s.white(); s.pop();
        // soczewkowanie: pionowy halo
        s.push(); s.rx(0); s.rz(0);
        s.alpha(.7f); s.rx(90); s.ring(Scene.GLOW, 4, 1.65f, 2.15f, 0, 6.2831855f, 28);
        s.alpha(.4f); s.ring(Scene.GLOW, 3, 1.55f, 1.7f, 0, 6.2831855f, 28);
        s.white(); s.pop();
        // błysk przy zapadaniu
        float col = seg(p, .8f, .95f);
        if (col > 0) { s.alpha(.9f * (1 - col)); s.sph(Scene.GLOW, 5, 1.5f + col * 5, 14); s.white(); }
        s.pop();
    }

    @Override public float flash(float p) { return p > .88f && p < .96f ? .5f * (1 - seg(p, .88f, .96f)) : 0; }

    @Override public void tick(FxCtx c) {
        float p = c.p, S = size(p);
        if (S > .3f) {
            for (int i = 0; i < 6; i++) {
                float a = c.r.nextFloat() * 6.2831855f, r = 2 + c.r.nextFloat() * 5;
                float x = CX + r * cos(a), z = CZ + r * sin(a), y = CY + (c.r.nextFloat() - .5f) * 2.2f;
                float tx = -sin(a) * .18f - cos(a) * .12f, tz = cos(a) * .18f - sin(a) * .12f;
                c.par(c.r.nextBoolean() ? ParticleTypes.END_ROD : ParticleTypes.PORTAL, x, y, z, tx, -(y - CY) * .06f, tz);
            }
            if (c.every(3)) c.par(ParticleTypes.SMOKE, CX + (c.r.nextFloat() - .5f) * 3, CY, CZ + (c.r.nextFloat() - .5f) * 3, 0, 0, 0);
        }
        if (c.at(.02f)) c.snd(SoundEvents.BLOCK_END_PORTAL_SPAWN, CX, CY, CZ, 2f, .6f);
        if (p > .05f && p < .78f && c.every(18)) c.snd(SoundEvents.BLOCK_PORTAL_AMBIENT, CX, CY, CZ, 1.5f, .5f);
        if (c.at(.62f)) { c.snd(SoundEvents.BLOCK_PORTAL_TRAVEL, CX, CY, CZ, 1.2f, .6f); c.burst(ParticleTypes.REVERSE_PORTAL, 30, CX, CY, CZ, .3); }
        if (c.at(.9f)) {
            c.snd(SoundEvents.ENTITY_WARDEN_SONIC_BOOM, CX, CY, CZ, 2.2f, .6f);
            c.burst(ParticleTypes.END_ROD, 50, CX, CY, CZ, .8);
            c.burst(ParticleTypes.FIREWORK, 30, CX, CY, CZ, .5);
        }
    }
}
