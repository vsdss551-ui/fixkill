package pl.killeffect.client.fx;

import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import pl.killeffect.EffectType;

public final class ChestFx extends FxEffect {
    static final float K = 2.4f, CZ = 2.4f;
    public ChestFx() { super(EffectType.CHEST); }

    @Override protected String[] tiles() {
        return new String[]{"w:7A4A22", "w:4A2A12", "m:F2C230", "m:B8861A", "g:FFD860:E6", "s:E02030", "s:2060F0", "m:FFD24A", "g:FFE890:5A", "m:D8A820", "s:7A1020"};
    }

    static float lid(float p) {
        if (p < .18f) return 0;
        if (p < .34f) return 115 * back(seg(p, .18f, .34f));
        if (p < .64f) return 115;
        if (p < .76f) return 115 * (1 - easeIn(seg(p, .64f, .76f)));
        return 0;
    }

    static float scale(float p) {
        float a = p < .2f ? back(p / .2f) : 1;
        float b = p > .84f ? 1 - easeIn(seg(p, .84f, .96f)) : 1;
        return a * b;
    }

    private void lidPart(Scene s, final float x0, final float x1, final float r, int tile) {
        s.surf(Scene.SOLID, tile, 1, 12, (u, v, o) -> {
            float a = PI * v;
            o[0] = lerp(x0, x1, u); o[1] = .45f * sin(a) * r; o[2] = .55f * cos(a) * r;
        }, 3, 0, 0, 0);
    }

    @Override public void render(Scene s) {
        final float p = s.p, t = s.t, sc = scale(p), la = lid(p);
        // ofiara wciągana
        float q = seg(p, .34f, .64f), e = sm(q);
        if (q < 1f) {
            float ang = 2 * PI * 1.5f * e, rr = (1 - e) * .8f;
            float vx = cos(ang) * rr, vz = lerp(0, CZ, e) + sin(ang) * rr, vy = lerp(0, 1.1f * K, e) + sin(e * PI) * 1.4f;
            float k = 1 - e * e * .92f;
            victim(s, vx, vy, vz, e * 540, -40 * e, k, k * (1 + e * .5f), k, -150, -150, 20 * sin(t * .6f), -20 * sin(t * .6f));
        }
        if (sc < .01f) return;
        s.push();
        s.tr(0, p < .2f ? (1 - sm(p / .2f)) * 6 : 0, CZ);
        s.ry(p > .76f && p < .86f ? sin(t * 3) * 6 : 0);
        s.sc(K * sc);
        // korpus
        s.box(0, 0, .35f, 0, 1.6f, .7f, 1.1f);
        s.box(2, 0, .73f, 0, 1.66f, .06f, 1.16f);
        s.box(2, 0, .04f, 0, 1.66f, .08f, 1.16f);
        for (int ix = -1; ix <= 1; ix += 2) for (int iz = -1; iz <= 1; iz += 2) s.box(2, ix * .8f, .38f, iz * .54f, .12f, .78f, .12f);
        s.box(3, 0, .2f, 0, 1.64f, .08f, 1.14f);
        s.box(3, 0, .55f, 0, 1.64f, .08f, 1.14f);
        s.box(9, 0, .52f, .57f, .22f, .3f, .06f);
        // wnętrze
        if (la > 3) {
            s.box(10, 0, .66f, 0, 1.4f, .04f, .9f);
            s.alpha(Math.min(1f, la / 60f)); s.gbox(4, 0, .72f, 0, 1.3f, .02f, .8f); s.white();
            for (int i = 0; i < 9; i++) s.box(7, -.5f + (i % 5) * .25f, .72f + (i / 5) * .06f, -.2f + (i % 3) * .2f, .18f, .04f, .18f);
        }
        // wieko na zawiasie
        s.push(); s.tr(0, .73f, -.55f); s.rx(-la); s.tr(0, 0, .55f);
        lidPart(s, -.8f, .8f, 1f, 0);
        for (int i = -1; i <= 1; i++) lidPart(s, i * .55f - .06f, i * .55f + .06f, 1.03f, 2);
        for (int sd = -1; sd <= 1; sd += 2) {
            final float xx = sd * .8f;
            s.surf(Scene.SOLID, 0, 1, 12, (u, v, o) -> { float a = PI * v; o[0] = xx; o[1] = u * .45f * sin(a); o[2] = .55f * cos(a); }, 1, sd * 2f, 0, 0);
        }
        s.push(); s.tr(0, .5f, 0); s.rx(0); s.box(5, 0, 0, 0, .16f, .16f, .16f); s.alpha(.5f + .5f * sin(t * .4f)); s.gbox(5, 0, 0, 0, .26f, .26f, .26f); s.white(); s.pop();
        s.push(); s.tr(.55f, .46f, .22f); s.box(6, 0, 0, 0, .12f, .12f, .12f); s.pop();
        s.pop();
        // promienie
        if (la > 10) {
            for (int i = 0; i < 7; i++) {
                s.push(); s.tr(0, .75f, 0); s.rx(-35 + i * 12 + sin(t * .1f + i) * 4); s.ry((i - 3) * 14);
                s.alpha(.35f * Math.min(1f, la / 80f)); s.cyl(Scene.GLOW, 8, .02f, .35f, 3.6f, 6); s.white(); s.pop();
            }
        }
        // błysk zamka
        if (p > .76f && p < .84f) { s.alpha(.9f * sin(seg(p, .76f, .84f) * PI)); s.tr(0, .52f, .6f); s.sph(Scene.GLOW, 4, .5f, 8); s.white(); }
        s.pop();
    }

    @Override public void tick(FxCtx c) {
        float p = c.p;
        DustParticleEffect gold = new DustParticleEffect(0xFFC832, 1.3f);
        if (c.at(.02f)) c.snd(SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 0, 1, CZ, 2f, 1f);
        if (p < .2f && c.every(2)) c.par(gold, (c.r.nextFloat() - .5f) * 3, 1 + c.r.nextFloat() * 2, CZ + (c.r.nextFloat() - .5f) * 3, 0, -.02, 0);
        if (c.at(.2f)) { c.snd(SoundEvents.BLOCK_CHEST_OPEN, 0, 1, CZ, 2f, .8f); c.burst(ParticleTypes.TOTEM_OF_UNDYING, 30, 0, 2.5, CZ, .5); }
        if (p > .22f && p < .64f && c.every(2)) c.par(gold, (c.r.nextFloat() - .5f) * 1.5f, 2.4, CZ + (c.r.nextFloat() - .5f), 0, .2, 0);
        if (p > .3f && p < .64f && c.every(5)) c.snd(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0, 2, CZ, .8f, 1.2f + c.r.nextFloat() * .5f);
        if (c.at(.64f)) { c.snd(SoundEvents.BLOCK_CHEST_CLOSE, 0, 1, CZ, 2f, .8f); c.burst(gold, 25, 0, 2, CZ, .4); }
        if (c.at(.78f)) c.snd(SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 0, 1, CZ, 2f, 1.5f);
        if (c.at(.9f)) {
            c.burst(ParticleTypes.TOTEM_OF_UNDYING, 60, 0, 1.3, CZ, .8);
            c.burst(gold, 40, 0, 1.3, CZ, .8);
            c.snd(SoundEvents.ENTITY_PLAYER_LEVELUP, 0, 1.3, CZ, 2f, 1f);
            c.snd(SoundEvents.ENTITY_FIREWORK_ROCKET_TWINKLE, 0, 1.3, CZ, 2f, 1f);
        }
    }
}
