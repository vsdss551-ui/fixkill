package pl.killeffect.client.fx;

import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import pl.killeffect.EffectType;

public final class DragonFx extends FxEffect {
    static final float SC = 1.3f;
    public DragonFx() { super(EffectType.DRAGON); }

    @Override protected String[] tiles() {
        return new String[]{"f:7A1418", "f:D8A868", "s:EADFC0", "s:5A0C10", "g:FFD000:240", "s:221A16", "g:FF8A20:180", "g:FFE080:200",
                "s:3A2A22", "s:F4F0E0", "s:7A1020", "f:5A1015"};
    }

    static float[] bez(float[] a, float[] b, float[] c, float q) {
        float k = 1 - q;
        return new float[]{k * k * a[0] + 2 * k * q * b[0] + q * q * c[0], k * k * a[1] + 2 * k * q * b[1] + q * q * c[1], k * k * a[2] + 2 * k * q * b[2] + q * q * c[2]};
    }

    static final float[] A = {-18, 28, 46}, B = {0, 14, 22}, G = {0, 3.9f, -.5f}, D = {2, 9, -10}, E = {26, 44, -64};

    static float[] pos(float p) {
        if (p < .5f) return bez(A, B, G, easeOut(p / .5f));
        return bez(G, D, E, easeIn((p - .5f) / .5f));
    }

    static float[] dir(float p) {
        float[] a = pos(Math.max(0, p - .01f)), b = pos(Math.min(1, p + .01f));
        return new float[]{b[0] - a[0], b[1] - a[1], b[2] - a[2]};
    }

    static float fire(float p) { return sm(seg(p, .2f, .26f)) * (1 - sm(seg(p, .4f, .46f))); }

    private void wing(Scene s, float side, float flap, float bend) {
        s.push(); s.tr(side * .7f, .8f, .3f); s.rz(side * flap); s.sc(side, 1, 1);
        float[] W = {4.6f, .2f, -1f};
        s.limb(Scene.SOLID, 11, 0, 0, 0, 2.2f, .5f, -.4f, .22f);
        s.limb(Scene.SOLID, 11, 2.2f, .5f, -.4f, W[0], W[1], W[2], .18f);
        s.push(); s.tr(W[0], W[1], W[2]); s.rz(bend);
        float[][] T = {{1.5f, -.4f, 2.2f}, {2.2f, -.9f, -1.0f}, {.8f, -1.0f, -2.6f}, {-1.6f, -.7f, -3.0f}};
        for (float[] t : T) s.limb(Scene.SOLID, 11, 0, 0, 0, t[0], t[1], t[2], .09f);
        for (int i = 0; i < 3; i++) s.tri(Scene.SOLID, 3, 0, 0, 0, T[i][0], T[i][1], T[i][2], T[i + 1][0], T[i + 1][1], T[i + 1][2]);
        s.pop();
        s.tri(Scene.SOLID, 3, 2.2f, .5f, -.4f, W[0], W[1], W[2], 0, 0, 0);
        s.tri(Scene.SOLID, 3, 0, 0, 0, W[0] - 1.6f, -.7f, -3.0f, 0.2f, -.4f, -2.6f);
        s.tri(Scene.SOLID, 3, 2.2f, .5f, -.4f, W[0] - 1.6f, -.7f, -3.0f, W[0], W[1], W[2]);
        s.pop();
    }

    private void dragon(Scene s, float t, float flapSpeed, float jaw, float fireK, boolean grab) {
        float flap = sin(t * flapSpeed) * 50, bend = sin(t * flapSpeed - 1.1f) * 22;
        // tułów
        s.push(); s.sc(1, .85f, 1.5f); s.sph(Scene.SOLID, 0, 1.0f, 14); s.pop();
        s.push(); s.tr(0, -.25f, .1f); s.sc(.8f, .55f, 1.4f); s.sph(Scene.SOLID, 1, 1.0f, 12); s.pop();
        for (int i = 0; i < 6; i++) s.box(2, 0, .95f + (i % 2) * .05f, -1.1f + i * .45f, .16f, .38f, .2f);
        // szyja
        float px = 0, py = .3f, pz = 1.3f;
        for (int i = 1; i <= 5; i++) {
            float f = i / 5f;
            float nx = sin(t * .12f - i * .5f) * .3f, ny = .3f + f * 1.1f + (f > .5f ? 0 : 0), nz = 1.3f + f * 1.6f;
            s.limb(Scene.SOLID, 0, px, py, pz, nx, ny, nz, .75f - f * .25f);
            s.push(); s.tr(nx, ny, nz); s.sph(Scene.SOLID, 0, .42f - f * .08f, 8); s.pop();
            s.box(2, nx, ny + .35f - f * .05f, nz, .1f, .24f, .22f);
            px = nx; py = ny; pz = nz;
        }
        // głowa
        s.push(); s.tr(px, py + .05f, pz + .1f); s.rx(10);
        s.box(0, 0, 0, .1f, .75f, .6f, .9f);
        s.box(0, 0, -.02f, .85f, .5f, .38f, .9f);
        s.box(8, .28f, .45f, -.25f, .12f, .12f, .7f); s.box(8, -.28f, .45f, -.25f, .12f, .12f, .7f);
        s.gbox(4, .3f, .18f, .2f, .12f, .12f, .12f); s.gbox(4, -.3f, .18f, .2f, .12f, .12f, .12f);
        for (int i = 0; i < 5; i++) { float z = .35f + i * .17f; s.box(9, .22f, -.12f, z, .05f, .16f, .05f); s.box(9, -.22f, -.12f, z, .05f, .16f, .05f); }
        s.push(); s.tr(0, -.2f, -.3f); s.rx(jaw);
        s.box(0, 0, -.1f, .75f, .5f, .2f, 1.2f);
        s.box(10, 0, .02f, .75f, .44f, .05f, 1.0f);
        s.pop();
        if (fireK > .01f) {
            s.push(); s.tr(0, -.12f, 1.0f);
            for (int i = 0; i < 3; i++) {
                s.push(); s.rx(90); s.alpha(.55f * fireK - i * .1f);
                s.sc(1 + i * .15f, 1 + .2f * sin(t * 2 + i), 1 + i * .15f);
                s.cyl(Scene.GLOW, i == 2 ? 7 : 6, .1f, 1.6f - i * .3f, 9f, 10); s.pop();
            }
            s.white(); s.pop();
        }
        s.pop();
        // ogon
        float tx = 0, ty = 0, tz = -1.4f;
        for (int i = 1; i <= 11; i++) {
            float f = i / 11f;
            float nx = sin(t * .14f + i * .45f) * (.3f + f * 1.1f), ny = -.1f - f * .5f + sin(t * .1f + i * .3f) * .15f, nz = -1.4f - i * .72f;
            s.limb(Scene.SOLID, 0, tx, ty, tz, nx, ny, nz, .85f * (1 - f) + .1f);
            s.box(2, nx, ny + .45f * (1 - f) + .1f, nz, .1f, .3f * (1 - f) + .1f, .2f);
            tx = nx; ty = ny; tz = nz;
        }
        s.tri(Scene.SOLID, 3, tx, ty, tz, tx + .9f, ty, tz - .3f, tx, ty, tz - 1.5f);
        s.tri(Scene.SOLID, 3, tx, ty, tz, tx - .9f, ty, tz - .3f, tx, ty, tz - 1.5f);
        // skrzydła
        wing(s, 1, flap, bend); wing(s, -1, flap, bend);
        // nogi
        for (int sd = -1; sd <= 1; sd += 2) {
            float x = sd * .6f;
            if (grab) {
                s.limb(Scene.SOLID, 0, x, -.5f, .3f, x * .8f, -1.9f, .5f, .35f);
                s.limb(Scene.SOLID, 0, x * .8f, -1.9f, .5f, x * .5f, -2.6f, .85f, .22f);
                for (int c = -1; c <= 1; c++) s.limb(Scene.SOLID, 5, x * .5f, -2.6f, .85f, x * .5f + c * .22f, -3.1f, 1.1f, .08f);
            } else {
                s.limb(Scene.SOLID, 0, x, -.5f, -.3f, x, -1.2f, -.7f, .35f);
                s.limb(Scene.SOLID, 0, x, -1.2f, -.7f, x, -1.5f, .1f, .22f);
                for (int c = -1; c <= 1; c++) s.limb(Scene.SOLID, 5, x, -1.5f, .1f, x + c * .2f, -1.7f, .5f, .07f);
            }
        }
    }

    @Override public void render(Scene s) {
        final float p = s.p, t = s.t;
        float[] ps = pos(p), d = dir(p);
        boolean grab = p > .4f;
        // ofiara
        float yaw = (float) Math.atan2(d[0], d[2]);
        float hz = (float) Math.sqrt(d[0] * d[0] + d[2] * d[2]);
        float elev = (float) Math.atan2(d[1], hz);
        float gv = sm(seg(p, .44f, .52f));
        float vx = lerp(0, ps[0] + sin(yaw) * .8f * SC, gv), vy = lerp(0, ps[1] - 3.0f * SC, gv), vz = lerp(0, ps[2] + cos(yaw) * .8f * SC, gv);
        float far = p > .85f ? 1 - sm(seg(p, .85f, .97f)) : 1;
        float lim = gv * 30 + sin(t * .4f) * 12 * gv;
        victim(s, vx, vy, vz, deg(yaw) * gv, 0, far, far, far, -150 + (p < .44f ? sin(t * .9f) * 25 : -lim), -150 + (p < .44f ? -sin(t * .9f) * 25 : lim), p < .44f ? 0 : 18, p < .44f ? 0 : -18);
        // smok
        s.push();
        s.tr(ps[0], ps[1], ps[2]);
        s.look(d[0], d[1], d[2]);
        float fk = fire(p);
        float jaw = 8 + 38 * fk + (p > .9f ? 0 : 0);
        s.sc(SC * (p > .8f ? 1 - .4f * seg(p, .8f, 1) : 1));
        dragon(s, t, p > .5f ? .55f : .42f, jaw, fk, grab);
        s.pop();
    }

    @Override public void tick(FxCtx c) {
        float p = c.p, t = c.age;
        float[] ps = pos(p), d = dir(p);
        float l = (float) Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
        if (l > 1e-5f) { d[0] /= l; d[1] /= l; d[2] /= l; }
        if (fire(p) > .2f) {
            for (int i = 0; i < 4; i++) {
                float k = 4f * SC + i * .6f;
                c.par(ParticleTypes.FLAME, ps[0] + d[0] * k, ps[1] + d[1] * k + .9f, ps[2] + d[2] * k, d[0] * .6 + (c.r.nextFloat() - .5f) * .15, d[1] * .6 - .05, d[2] * .6 + (c.r.nextFloat() - .5f) * .15);
            }
            c.par(ParticleTypes.LARGE_SMOKE, ps[0] + d[0] * 5, ps[1] + d[1] * 5, ps[2] + d[2] * 5, d[0] * .3, 0, d[2] * .3);
        }
        if (c.at(.04f)) c.snd(SoundEvents.ENTITY_ENDER_DRAGON_GROWL, ps[0], ps[1], ps[2], 6f, .9f);
        if (c.every(9) && p < .95f) c.snd(SoundEvents.ENTITY_ENDER_DRAGON_FLAP, ps[0], ps[1], ps[2], 4f, .9f);
        if (c.at(.22f)) c.snd(SoundEvents.ENTITY_ENDER_DRAGON_SHOOT, ps[0], ps[1], ps[2], 5f, .9f);
        if (c.at(.5f)) { c.snd(SoundEvents.ENTITY_ENDER_DRAGON_GROWL, ps[0], ps[1], ps[2], 6f, .7f); c.burst(ParticleTypes.CLOUD, 30, 0, 1, 0, .5); }
        if (p > .35f && p < .6f && ps[1] < 8 && c.every(2)) c.par(ParticleTypes.CLOUD, ps[0] + (c.r.nextFloat() - .5f) * 6, .2, ps[2] + (c.r.nextFloat() - .5f) * 6, 0, .05, 0);
        if (c.at(.9f)) c.burst(ParticleTypes.END_ROD, 20, ps[0], ps[1], ps[2], .4);
    }
}
