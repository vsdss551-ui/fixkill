package pl.killeffect.client.fx;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/** Kontekst jednego ticku efektu: cząsteczki i dźwięki we współrzędnych lokalnych sceny. */
public final class FxCtx {
    public final ClientWorld w;
    public final Vec3d o;
    public final int age, dur;
    public final float p;
    public final boolean sound, particles;
    public final Random r;
    public int budget;
    private final double c, s;

    public FxCtx(ClientWorld w, Vec3d o, float ang, int age, int dur, boolean sound, boolean particles, int budget, long seed) {
        this.w = w; this.o = o; this.age = age; this.dur = dur; this.p = Math.min(1f, age / (float) dur);
        this.sound = sound; this.particles = particles; this.budget = budget;
        this.r = new Random(seed + age * 7919L);
        double a = Math.toRadians(ang);
        this.c = Math.cos(a); this.s = Math.sin(a);
    }

    public Vec3d world(double x, double y, double z) {
        return new Vec3d(o.x + x * c + z * s, o.y + y, o.z - x * s + z * c);
    }

    public void par(ParticleEffect e, double x, double y, double z, double vx, double vy, double vz) {
        if (!particles || budget <= 0) return;
        budget--;
        w.addParticle(e, o.x + x * c + z * s, o.y + y, o.z - x * s + z * c, vx * c + vz * s, vy, -vx * s + vz * c);
    }

    public void burst(ParticleEffect e, int n, double x, double y, double z, double speed) {
        for (int i = 0; i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2, b = r.nextDouble() * 2 - 1, k = Math.sqrt(1 - b * b);
            par(e, x, y, z, Math.cos(a) * k * speed, b * speed, Math.sin(a) * k * speed);
        }
    }

    public void snd(SoundEvent e, double x, double y, double z, float vol, float pitch) {
        if (!sound) return;
        Vec3d v = world(x, y, z);
        w.playSound(v.x, v.y, v.z, e, SoundCategory.PLAYERS, vol, pitch, false);
    }

    public void snd(RegistryEntry<SoundEvent> e, double x, double y, double z, float vol, float pitch) { snd(e.value(), x, y, z, vol, pitch); }

    public boolean at(float frac) { return age == (int) (dur * frac); }
    public boolean every(int n) { return age % n == 0; }
}
