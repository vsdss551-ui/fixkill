package pl.killeffect.client.fx;

import net.minecraft.util.Identifier;
import pl.killeffect.EffectType;

/** Bazowa klasa animowanej scenki. render() jest funkcją czystą od (p, t) – ten sam kod w świecie i w GUI. */
public abstract class FxEffect {
    public static final float PI = (float) Math.PI;
    public final EffectType type;
    private Identifier tex;

    protected FxEffect(EffectType t) { type = t; }

    /** Do 16 kafelków tekstury (patrz Tex). */
    protected abstract String[] tiles();
    public abstract void render(Scene s);
    public void tick(FxCtx c) { }
    /** Biały błysk na całym ekranie (0..1). */
    public float flash(float p) { return 0; }

    public Identifier texture() {
        if (tex == null) tex = Tex.get(type.id, tiles());
        return tex;
    }

    // ---------- matematyka animacji ----------
    protected static float c01(float x) { return x < 0 ? 0 : Math.min(x, 1); }
    protected static float seg(float p, float a, float b) { return c01((p - a) / (b - a)); }
    protected static float sm(float x) { x = c01(x); return x * x * (3 - 2 * x); }
    protected static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    protected static float easeIn(float x) { x = c01(x); return x * x; }
    protected static float easeOut(float x) { x = c01(x); return 1 - (1 - x) * (1 - x); }
    protected static float back(float x) { x = c01(x) - 1; return x * x * (2.7f * x + 1.7f) + 1; }
    protected static float sin(float x) { return (float) Math.sin(x); }
    protected static float cos(float x) { return (float) Math.cos(x); }
    protected static float abs(float x) { return Math.abs(x); }
    protected static float deg(float rad) { return (float) Math.toDegrees(rad); }

    /** Ofiara w świecie sceny (stopy w punkcie x,y,z). Skala <= 0 = niewidoczna. */
    protected void victim(Scene s, float x, float y, float z, float ry, float rx, float sx, float sy, float sz,
                          float aR, float aL, float lR, float lL) {
        if (sx <= .002f || sy <= .002f || sz <= .002f) return;
        s.push(); s.tr(x, y, z); s.ry(ry); s.rx(rx); s.sc(sx, sy, sz);
        s.skinHuman(Scene.SOLID, aR, aL, lR, lL, 0, 0);
        s.pop();
    }
}
