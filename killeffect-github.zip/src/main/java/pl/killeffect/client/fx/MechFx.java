package pl.killeffect.client.fx;

import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import pl.killeffect.EffectType;

public final class MechFx extends FxEffect {
    static final float MX = 2.4f, MZ = 1.55f;
    public MechFx() { super(EffectType.MECH); }

    @Override protected String[] tiles() {
        return new String[]{"p:B8BEC8", "m:3A404A", "k:FF7A1A", "g:FF2A2A:F0", "s:60C8FF:A0", "m:2A2E35", "g:FFB040:C8", "g:FFF2C0:DC", "g:FF3030:78", "m:D8DCE2", "s:E8C020", "g:40C8FF:C8"};
    }

    /** {x,y,z,yaw,pitch} mecha. */
    static float[] pos(float p) {
        float x = MX, y = 0, z, yaw, pitch = 0;
        if (p < .34f) { z = lerp(26, MZ, easeOut(p / .34f)); yaw = 180; }
        else if (p < .64f) { z = MZ; yaw = 180; }
        else if (p < .74f) { z = MZ; yaw = 180 - 180 * sm(seg(p, .64f, .74f)); }
        else {
            float q = seg(p, .74f, 1);
            z = MZ + easeIn(q) * 44; y = easeIn(q) * 55; yaw = 0; pitch = 25 * sm(seg(q, 0, .4f));
        }
        return new float[]{x, y, z, yaw, pitch};
    }

    static float armAngle(float p) {
        if (p < .46f) return 0;
        if (p < .58f) return lerp(0, -15, sm(seg(p, .46f, .58f)));
        return lerp(-15, -75, sm(seg(p, .58f, .68f)));
    }

    private void leg(Scene s, float x, float ph, float walk) {
        float th = sin(ph) * 28 * walk, kn = Math.max(0, -sin(ph + .8f)) * 38 * walk;
        s.push(); s.tr(x, 5f, 0); s.rx(th);
        s.sph(Scene.SOLID, 5, .6f, 8);
        s.box(0, 0, -1.25f, 0, 1.1f, 2.4f, 1.2f);
        s.push(); s.tr(0, -2.5f, 0); s.rx(kn);
        s.sph(Scene.SOLID, 5, .52f, 8);
        s.box(0, 0, -1.2f, .15f, .95f, 2.2f, 1.0f);
        s.box(9, 0, -.8f, .6f, .3f, 1.3f, .2f);
        s.push(); s.tr(0, -2.4f, .2f); s.rx(-th - kn);
        s.box(1, 0, -.1f, .5f, 1.5f, .6f, 2.4f);
        s.box(2, 0, .25f, .6f, 1.54f, .12f, 2.0f);
        s.pop(); s.pop(); s.pop();
    }

    @Override public void render(Scene s) {
        final float p = s.p, t = s.t;
        float[] m = pos(p);
        boolean walking = p < .34f;
        float ph = t * .22f;
        float scan = p > .34f && p < .46f ? sin((p - .34f) * 60) * 25 : 0;
        float aAng = armAngle(p);
        float open = p < .46f ? 10 : p < .55f ? lerp(10, 60, sm(seg(p, .46f, .52f))) : p < .6f ? lerp(60, 8, sm(seg(p, .55f, .6f))) : 8;
        float thr = sm(seg(p, .7f, .76f));
        boolean carried = p > .55f;
        // ofiara (przed złapaniem)
        if (!carried) {
            float lock = seg(p, .34f, .5f);
            victim(s, 0, 0, 0, 0, 0, 1, 1, 1, -140 + sin(t * 1.1f) * 25, -140 - sin(t * 1.1f) * 25, 0, 0);
            if (lock > 0 && p < .55f) {
                float k = .6f + .1f * sin(t * .8f);
                s.push(); s.tr(0, 1, 0);
                for (int i = 0; i < 2; i++) { s.push(); s.rx(i * 60); s.ry(t * (i == 0 ? 6 : -6)); s.alpha(.6f * lock); s.ring(Scene.GLOW, 3, 1.1f, 1.2f, 0, 6.2831855f, 20); s.pop(); }
                s.white(); s.pop();
            }
        }
        // laser celujący
        if (p > .34f && p < .55f) {
            s.push(); s.tr(m[0], 8.0f, m[2]);
            s.alpha(.8f); s.limb(Scene.GLOW, 8, 0, 0, 0, -MX, -6.6f, -MZ - .2f, .06f); s.white();
            s.pop();
        }
        // mech
        s.push();
        s.tr(m[0], m[1] + (walking ? abs(sin(ph)) * .25f : 0), m[2]);
        s.ry(m[3]); s.rx(m[4]);
        float walk = walking ? 1 : p > .74f ? 0 : 0;
        leg(s, -1.1f, ph, walk); leg(s, 1.1f, ph + PI, walk);
        s.box(1, 0, 5.1f, 0, 2.6f, .9f, 1.7f);
        s.push(); s.tr(0, 0, 0); s.rx(walking ? sin(ph) * 1.5f : 0);
        s.box(0, 0, 6.6f, 0, 3.0f, 2.2f, 2.0f);
        s.box(2, 0, 6.3f, 1.02f, 3.04f, .3f, .04f);
        s.box(1, 0, 6.2f, -1.0f, 2.4f, 1.6f, .3f);
        s.box(Scene.TRANS, 4, 0, 7.0f, .95f, 1.5f, 1.0f, 1.0f);
        s.box(1, 0, 6.75f, .85f, .5f, .6f, .4f);
        // głowa
        s.push(); s.tr(0, 8.15f, .2f); s.ry(scan);
        s.box(1, 0, 0, 0, 1.1f, .8f, 1.1f);
        s.alpha(.6f + .4f * sin(t * .5f)); s.gbox(3, 0, .02f, .58f, .9f, .22f, .05f); s.white();
        s.limb(Scene.SOLID, 9, .4f, .4f, 0, .6f, 1.5f, -.2f, .05f);
        s.pop();
        // ramiona
        for (int sd = -1; sd <= 1; sd += 2) {
            float x = sd * 2.4f;
            s.box(0, sd * 2.1f, 7.1f, 0, 1.4f, 1.0f, 1.6f);
            s.box(2, sd * 2.1f, 7.65f, 0, 1.42f, .14f, 1.62f);
            boolean grabArm = sd > 0;
            s.push(); s.tr(x, 7.0f, 0);
            s.rx(grabArm ? aAng : sin(ph + (sd > 0 ? 0 : PI)) * 18 * walk);
            s.sph(Scene.SOLID, 5, .55f, 8);
            s.box(0, 0, -1.5f, 0, .95f, 3.0f, .95f);
            s.box(9, sd * .35f, -1.5f, .5f, .12f, 2.2f, .12f);
            s.push(); s.tr(0, -3.0f, 0);
            s.sph(Scene.SOLID, 5, .48f, 8);
            s.box(1, 0, -1.5f, 0, .85f, 3.0f, .85f);
            s.push(); s.tr(0, -3.05f, 0);
            for (int c = -1; c <= 1; c += 2) {
                s.push(); s.rx(c * (grabArm ? open : 10)); s.box(9, 0, -.55f, c * .25f, .3f, 1.1f, .24f); s.box(2, 0, -.1f, c * .25f, .32f, .2f, .26f); s.pop();
            }
            if (grabArm && carried && p < .98f) {
                float far = p > .9f ? 1 - sm(seg(p, .9f, .98f)) : 1;
                s.push(); s.tr(0, -1.0f, 0); s.sc(1.0f / 1.0f);
                float lim = sin(t * .5f) * 10;
                s.push(); s.rx(0); s.tr(0, 0, 0);
                victim(s, 0, 0, 0, 0, 180, far, far, far, 20 + lim, 20 - lim, 10, -10);
                s.pop(); s.pop();
            }
            s.pop(); s.pop(); s.pop();
        }
        s.pop();
        // silniki
        for (int sd = -1; sd <= 1; sd += 2) {
            s.push(); s.tr(sd * .9f, 6.9f, -1.35f);
            s.cyl(Scene.SOLID, 1, .45f, .5f, 1.4f, 10);
            if (thr > .01f) {
                s.push(); s.tr(0, 0, 0); s.rx(180);
                float fl = 1 + .25f * sin(t * 2.2f + sd);
                s.alpha(.8f * thr); s.sc(1, fl * thr, 1); s.cyl(Scene.GLOW, 6, .5f, 0, 5.5f, 10);
                s.alpha(.9f * thr); s.cyl(Scene.GLOW, 7, .3f, 0, 3.5f, 8); s.white(); s.pop();
            }
            s.pop();
        }
        s.pop();
    }

    @Override public void tick(FxCtx c) {
        float p = c.p;
        float[] m = pos(p);
        if (p < .34f && c.every(7)) {
            c.snd(SoundEvents.ENTITY_IRON_GOLEM_STEP, m[0], 0, m[2], 3f, .55f);
            c.burst(ParticleTypes.CLOUD, 5, m[0] + ((c.age / 7) % 2 == 0 ? 1.1 : -1.1), .2, m[2], .15);
        }
        if (c.at(.36f)) c.snd(SoundEvents.BLOCK_BEACON_POWER_SELECT, 0, 1, 0, 2f, .8f);
        if (c.at(.48f)) c.snd(SoundEvents.BLOCK_PISTON_EXTEND, MX, 4, MZ, 2f, .6f);
        if (c.at(.58f)) {
            c.snd(SoundEvents.BLOCK_ANVIL_USE, 0, 1.2, 0, 2.5f, .7f);
            c.burst(ParticleTypes.ELECTRIC_SPARK, 25, 0, 1.2, 0, .5);
        }
        if (c.at(.7f)) c.snd(SoundEvents.ENTITY_IRON_GOLEM_ATTACK, MX, 5, MZ, 2f, .6f);
        if (c.at(.74f)) c.snd(SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, m[0], 2, m[2], 4f, .5f);
        if (p > .74f) {
            c.par(ParticleTypes.FLAME, m[0] + .9, m[1] + 6.5, m[2] - (m[3] > 90 ? -1 : 1.4), 0, -.3, 0);
            c.par(ParticleTypes.FLAME, m[0] - .9, m[1] + 6.5, m[2] - (m[3] > 90 ? -1 : 1.4), 0, -.3, 0);
            c.par(ParticleTypes.LARGE_SMOKE, m[0], m[1] + 5, m[2], 0, -.1, 0);
            if (m[1] < 3) c.burst(ParticleTypes.CLOUD, 4, m[0], .2, m[2], .4);
        }
    }
}
