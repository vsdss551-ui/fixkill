package pl.killeffect.client.fx;

import net.minecraft.block.Blocks;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import pl.killeffect.EffectType;

public final class MeteorFx extends FxEffect {
    static final float SX = 14, SY = 80, SZ = 60, TX = 2.6f, TY = 1.7f, TZ = 2.8f;
    static final float R = 2.4f;
    public MeteorFx() { super(EffectType.METEOR); }

    @Override protected String[] tiles() {
        return new String[]{"r:5A4A44", "l:FF6A10", "g:FF8A20:200", "g:FFE070:230", "s:2A1E1C", "g:777777:120", "s:1C1512", "g:FFB040:170"};
    }

    static float[] pos(float p) {
        float q = easeIn(c01(p / .5f));
        return new float[]{lerp(SX, TX, q), lerp(SY, TY, q), lerp(SZ, TZ, q)};
    }

    private void rock(Scene s, final float scale, int kind, int tile) {
        s.surf(kind, tile, 10, 14, (u, v, o) -> {
            float th = PI * u, ph = 2 * PI * v;
            float r = R * scale * (1 + .14f * sin(3 * ph + 2 * th) + .1f * sin(5 * th + ph * 2) + .07f * sin(7 * ph));
            o[0] = r * sin(th) * cos(ph); o[1] = r * cos(th); o[2] = r * sin(th) * sin(ph);
        }, 1, 0, 0, 0);
    }

    @Override public void render(Scene s) {
        final float p = s.p, t = s.t;
        float[] m = pos(p);
        boolean impact = p >= .5f;
        // krater
        float crater = impact ? (1 - sm(seg(p, .86f, 1))) : 0;
        if (crater > .01f) {
            s.push(); s.tr(TX, .03f, TZ); s.sc(sm(seg(p, .5f, .55f)) * crater);
            s.cyl(Scene.SOLID, 6, 3.6f, 3.6f, .02f, 20);
            s.alpha(.7f); s.ring(Scene.GLOW, 1, 3.0f, 3.9f, 0, 6.2831855f, 20); s.white();
            s.pop();
        }
        // ofiara
        if (p < .58f) {
            float k = p < .5f ? 1 : 1 - sm(seg(p, .5f, .58f));
            float fly = impact ? seg(p, .5f, .58f) * 5 : 0;
            victim(s, -fly * .5f, fly * .6f, -fly, impact ? 720 * seg(p, .5f, .58f) : 0, 0, k, k, k,
                    p < .5f ? -150 : -40, p < .5f ? -150 : 60, 0, 0);
        }
        // meteor
        float sink = impact ? sm(seg(p, .84f, 1)) : 0;
        s.push();
        if (!impact) {
            s.tr(m[0], m[1], m[2]);
            s.push(); s.look(TX - SX, TY - SY, TZ - SZ);
            float fl = 1 + .12f * sin(s.t * 1.3f);
            for (int i = 0; i < 3; i++) {
                s.push(); s.rx(-90); s.alpha(.38f - i * .08f); s.sc(1 - i * .22f, fl * (1 + i * .3f), 1 - i * .22f);
                s.cyl(Scene.GLOW, i == 2 ? 3 : 2, R * 1.05f, 0, 16, 14); s.pop();
            }
            s.white(); s.pop();
            s.ry(t * 4); s.rx(t * 3);
            rock(s, 1, Scene.SOLID, 0);
            s.alpha(.9f); rock(s, 1.04f, Scene.GLOW, 1); s.white();
        } else {
            s.tr(TX, TY - .9f - sink * 2.5f, TZ);
            s.sc(1 - sink * .6f);
            s.ry(30);
            rock(s, 1, Scene.SOLID, 0);
            s.alpha(.9f * (1 - sm(seg(p, .55f, .85f))) + .1f); rock(s, 1.04f, Scene.GLOW, 1); s.white();
        }
        s.pop();
        // fale uderzenia
        if (impact) {
            float w = seg(p, .5f, .7f);
            if (w < 1) {
                s.push(); s.tr(TX, .15f, TZ);
                s.alpha(.75f * (1 - w)); s.cyl(Scene.GLOW, 7, lerp(.5f, 12, easeOut(w)), lerp(.5f, 12, easeOut(w)), .3f, 28);
                float w2 = seg(p, .53f, .73f);
                s.alpha(.5f * (1 - w2)); s.cyl(Scene.GLOW, 2, lerp(.3f, 8, easeOut(w2)), lerp(.3f, 8, easeOut(w2)), .5f, 24);
                float f = seg(p, .5f, .6f);
                s.alpha(.8f * (1 - f)); s.tr(0, 1, 0); s.sph(Scene.GLOW, 3, lerp(1, 6, easeOut(f)), 12);
                s.white(); s.pop();
            }
        }
    }

    @Override public float flash(float p) { return p > .5f && p < .56f ? .55f * (1 - seg(p, .5f, .56f)) : 0; }

    @Override public void tick(FxCtx c) {
        float p = c.p;
        if (p < .5f) {
            float[] m = pos(p);
            for (int i = 0; i < 3; i++) {
                c.par(ParticleTypes.FLAME, m[0] + (c.r.nextFloat() - .5f) * 3, m[1] + (c.r.nextFloat() - .5f) * 3, m[2] + (c.r.nextFloat() - .5f) * 3 + 2, 0, .02, .05);
            }
            if (c.every(2)) c.par(ParticleTypes.LARGE_SMOKE, m[0], m[1], m[2] + 3, 0, .02, 0);
        }
        if (c.at(.02f)) c.snd(SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, TX, 20, TZ, 3f, .5f);
        if (p < .5f && c.every(8)) c.snd(SoundEvents.ENTITY_BLAZE_SHOOT, pos(p)[0], pos(p)[1], pos(p)[2], 4f, .5f);
        if (c.at(.5f)) {
            c.snd(SoundEvents.ENTITY_GENERIC_EXPLODE, TX, 1, TZ, 5f, .6f);
            c.snd(SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, TX, 1, TZ, 4f, .6f);
            c.par(ParticleTypes.EXPLOSION_EMITTER, TX, 1.5, TZ, 0, 0, 0);
            c.burst(ParticleTypes.FLAME, 50, TX, 1.5, TZ, .6);
            c.burst(ParticleTypes.LAVA, 20, TX, 1.2, TZ, .5);
            c.burst(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.STONE.getDefaultState()), 40, TX, 1, TZ, .5);
        }
        if (p > .5f && p < .8f && c.every(3)) {
            c.par(ParticleTypes.CAMPFIRE_COSY_SMOKE, TX + (c.r.nextFloat() - .5f) * 3, 1, TZ + (c.r.nextFloat() - .5f) * 3, 0, .06, 0);
            c.par(ParticleTypes.FLAME, TX + (c.r.nextFloat() - .5f) * 4, .3, TZ + (c.r.nextFloat() - .5f) * 4, 0, .03, 0);
        }
    }
}
