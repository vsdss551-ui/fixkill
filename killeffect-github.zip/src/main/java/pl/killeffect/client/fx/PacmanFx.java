package pl.killeffect.client.fx;

import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import pl.killeffect.EffectType;

public final class PacmanFx extends FxEffect {
    private static final float R = 1.7f;
    public PacmanFx() { super(EffectType.PACMAN); }

    @Override protected String[] tiles() {
        return new String[]{"s:FFD21A", "s:5A0A14", "s:0A0A0A", "g:FFF1B0", "g:FFD21A:60", "s:FF6A9A"};
    }

    static float zOf(float p) {
        if (p < .5f) return lerp(18, 2.2f, easeOut(p / .5f));
        if (p < .6f) return lerp(2.2f, -.2f, sm(seg(p, .5f, .6f)));
        return lerp(-.2f, -20, easeIn(seg(p, .6f, 1)));
    }

    @Override public void render(Scene s) {
        final float p = s.p, t = s.t, z = zOf(p);
        float mouth;
        if (p < .5f) mouth = .1f + .55f * abs(sin(t * .8f));
        else if (p < .56f) mouth = .95f;
        else if (p < .6f) mouth = lerp(.95f, .05f, seg(p, .56f, .6f));
        else mouth = .08f + .4f * abs(sin(t * .7f));
        float scale = p > .9f ? 1 - sm(seg(p, .9f, 1)) : 1;

        // kropki do zjedzenia
        for (int i = 0; i < 9; i++) {
            float dz = 4 + i * 1.9f;
            if (dz < z) {
                s.push(); s.tr(0, 1.85f, dz); s.alpha(.95f); s.sph(Scene.GLOW, 3, .22f + .04f * sin(t * .5f + i), 8); s.white(); s.pop();
            }
        }
        // ofiara
        if (p < .58f) {
            float shrink = 1 - sm(seg(p, .52f, .58f));
            float panic = p < .5f ? sin(t * .9f) * 25 : 0;
            victim(s, 0, 0, 0, 0, -20 * seg(p, .5f, .58f), shrink, shrink, shrink, -140 + panic, -140 - panic, panic, -panic);
        }
        // Pac-Man: kula z wyciętym klinem (ust)
        final float ph0 = mouth, ph1 = PI * 2 - mouth;
        s.push();
        s.tr(0, R + .15f + abs(sin(t * .4f)) * .18f * (p < .5f ? 1 : 0), z);
        s.ry(90); s.rz(sin(t * .8f) * 6); s.sc(scale);
        s.surf(Scene.SOLID, 0, 10, 14, (u, v, o) -> {
            float ph = ph0 + (ph1 - ph0) * u, th = PI * v;
            o[0] = R * sin(th) * cos(ph); o[1] = R * sin(th) * sin(ph); o[2] = R * cos(th);
        }, 1, 0, 0, 0);
        for (int side = 0; side < 2; side++) {
            final float phi = side == 0 ? ph0 : ph1;
            s.surf(Scene.SOLID, 1, 1, 10, (u, v, o) -> {
                float th = PI * v;
                o[0] = u * R * sin(th) * cos(phi); o[1] = u * R * sin(th) * sin(phi); o[2] = R * cos(th);
            }, 2, R * .6f, 0, 0);
        }
        for (int e = -1; e <= 1; e += 2) {
            s.push(); s.tr(.35f * R, .72f * R, e * .58f * R); s.sph(Scene.SOLID, 2, .2f * R, 8); s.pop();
        }
        s.alpha(.16f); s.sph(Scene.GLOW, 4, R * 1.35f, 12); s.white();
        s.pop();
    }

    @Override public void tick(FxCtx c) {
        float p = c.p, z = zOf(p);
        if (p < .95f && c.every(2)) c.par(new DustParticleEffect(0xFFD21A, 1.4f), 0, 1.85, z + R, 0, 0.02, 0.05);
        if (p < .5f && c.every(7)) c.snd(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0, 1.8, z, .6f, (c.age / 7) % 2 == 0 ? .7f : 1.05f);
        if (c.at(.54f)) { c.snd(SoundEvents.ENTITY_GENERIC_EAT, 0, 1.2, 0, 1.2f, .6f); c.snd(SoundEvents.ENTITY_GENERIC_EAT, 0, 1.2, 0, 1.2f, .9f); }
        if (c.at(.57f)) { c.burst(ParticleTypes.END_ROD, 34, 0, 1.5, 0, .35); c.snd(SoundEvents.ENTITY_PLAYER_LEVELUP, 0, 1.5, 0, 1f, 1.6f); }
        if (p > .6f && p < .9f && c.every(7)) c.snd(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0, 1.8, z, .5f, (c.age / 7) % 2 == 0 ? .6f : .9f);
        if (c.at(.9f)) {
            float zz = zOf(.9f);
            c.burst(ParticleTypes.FIREWORK, 40, 0, 1.9, zz, .5);
            c.burst(ParticleTypes.END_ROD, 30, 0, 1.9, zz, .6);
            c.snd(SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, 0, 1.9, zz, 1.5f, 1.1f);
        }
    }
}
