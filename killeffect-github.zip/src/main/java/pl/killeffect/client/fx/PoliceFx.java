package pl.killeffect.client.fx;

import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import pl.killeffect.EffectType;

public final class PoliceFx extends FxEffect {
    public PoliceFx() { super(EffectType.POLICE); }

    @Override protected String[] tiles() {
        return new String[]{"p:F2F4F7", "p:15181D", "s:7FB8E0:96", "g:FF2020:230", "g:2860FF:230", "f:101010", "m:AEB4BC", "g:FFF2B0:240",
                "p:1B2A5A", "f:E8B48A", "s:101A3A", "m:E6C040", "s:C01818", "s:1830C0", "g:FF2020:70", "g:2860FF:70"};
    }

    static float carZ(float p) {
        if (p < .28f) return lerp(26, 5, easeOut(p / .28f));
        if (p < .86f) return 5;
        return 5 + easeIn(seg(p, .86f, 1)) * 40;
    }

    @Override public void render(Scene s) {
        final float p = s.p, t = s.t, cz = carZ(p);
        float yaw = 180 * (1 - sm(seg(p, .78f, .86f)));
        boolean red = ((int) (t / 3)) % 2 == 0;

        // radiowóz
        s.push();
        s.tr(0, 0, cz); s.ry(yaw);
        if (p < .3f && p > .22f) s.rx(-3 * sin(seg(p, .22f, .3f) * PI));
        car(s, red, cz * 60);
        s.pop();

        // trasy policjanta i ofiary
        float cx, cyy; float cyaw; float walk = 0; boolean copVis = true; float vVis = 1;
        float x0 = 1.7f, z0 = 5.0f, x1 = .9f, z1 = 1.2f;
        float vx = 0, vz = 0, vyaw = 0;
        float armsV = -140;
        if (p < .34f) { copVis = false; cx = x0; cyy = z0; cyaw = 180; }
        else if (p < .5f) {
            float q = seg(p, .34f, .5f); cx = lerp(x0, x1, q); cyy = lerp(z0, z1, q);
            cyaw = deg((float) Math.atan2(x1 - x0, z1 - z0)); walk = 1;
        } else if (p < .56f) { cx = x1; cyy = z1; cyaw = deg((float) Math.atan2(-.9f, -.3f)); }
        else if (p < .76f) {
            float q = seg(p, .56f, .76f); cx = lerp(x1, x0, q); cyy = lerp(z1, 4.6f, q);
            cyaw = deg((float) Math.atan2(x0 - x1, 4.6f - z1)); walk = 1;
        } else { cx = x0; cyy = 4.6f; cyaw = 0; copVis = false; }
        float cop = copVis ? 1 - sm(seg(p, .76f, .8f)) : 0;
        if (p < .34f) cop = 0;
        float swing = walk * sin(t * .55f) * 38;
        if (cop > .01f) {
            s.push(); s.tr(cx, 0, cyy); s.ry(cyaw); s.sc(cop);
            float armA = p > .5f && p < .76f ? -50 : swing;
            s.fig(Scene.SOLID, 9, 10, 8, 8, 1, 9, 11, armA, -swing, -swing, swing, 0, 0);
            s.pop();
        }
        // ofiara
        if (p < .5f) {
            victim(s, 0, 0, 0, deg((float) Math.atan2(cx - 0, cyy - 0)) * .3f * seg(p, .4f, .5f), 0, 1, 1, 1,
                    sin(t * .8f) * 20 - 20, sin(t * .8f + 1) * 20 - 20, 0, 0);
        } else if (p < .78f) {
            float sx = p < .76f ? 1 : 1 - sm(seg(p, .76f, .78f));
            float px = cx, pz = cyy;
            if (p < .56f) { px = lerp(0, x1 - .8f, seg(p, .5f, .56f)); pz = lerp(0, z1 - .2f, seg(p, .5f, .56f)); }
            else { px = cx - .85f * cos(deg2rad(cyaw)); pz = cyy + .85f * sin(deg2rad(cyaw)); }
            float step = walk * sin(t * .55f) * 32;
            victim(s, px, 0, pz, cyaw, 0, sx, sx, sx, 35, 35, step, -step);
        }
    }

    private static float deg2rad(float d) { return (float) Math.toRadians(d); }

    private void wheel(Scene s, float x, float y, float z, float spin) {
        s.push(); s.tr(x, y, z); s.rz(90); s.tr(0, -.17f, 0);
        s.cyl(Scene.SOLID, 5, .44f, .44f, .34f, 14);
        s.push(); s.tr(0, .0f, 0); s.ry(spin); s.cyl(Scene.SOLID, 6, .27f, .27f, .36f, 10);
        s.box(1, 0, .18f, 0, .09f, .38f, .5f); s.box(1, 0, .18f, 0, .5f, .38f, .09f); s.pop();
        s.pop();
    }

    private void car(Scene s, boolean red, float spin) {
        s.box(0, 0, .8f, 0, 2.2f, .75f, 5f);
        s.box(1, 0, .42f, 0, 2.26f, .28f, 5.06f);
        s.box(0, 0, 1.2f, 1.45f, 2.12f, .1f, 1.7f);
        s.box(0, 0, 1.2f, -1.7f, 2.12f, .1f, 1.3f);
        s.box(0, 0, 1.62f, -.15f, 1.9f, .72f, 2.2f);
        // szyby
        s.push(); s.tr(0, 1.6f, 1.02f); s.rx(-24); s.box(Scene.TRANS, 2, 0, 0, 0, 1.78f, .68f, .06f); s.pop();
        s.push(); s.tr(0, 1.6f, -1.3f); s.rx(22); s.box(Scene.TRANS, 2, 0, 0, 0, 1.78f, .62f, .06f); s.pop();
        for (int sd = -1; sd <= 1; sd += 2) {
            s.box(Scene.TRANS, 2, sd * .97f, 1.62f, -.15f, .05f, .5f, 1.8f);
            s.box(8, sd * 1.12f, .85f, -.2f, .03f, .24f, 3.2f);
            s.box(1, sd * 1.12f, .75f, .0f, .04f, .5f, .04f);
            s.box(1, sd * 1.12f, .75f, -.9f, .04f, .5f, .04f);
        }
        // pasy i grill, zderzaki
        s.box(1, 0, .55f, 2.53f, 2.3f, .3f, .12f);
        s.box(1, 0, .55f, -2.53f, 2.3f, .3f, .12f);
        s.box(6, 0, .78f, 2.52f, 1.0f, .18f, .06f);
        s.gbox(7, .75f, .95f, 2.52f, .4f, .2f, .06f);
        s.gbox(7, -.75f, .95f, 2.52f, .4f, .2f, .06f);
        s.gbox(3, .75f, .95f, -2.52f, .4f, .2f, .06f);
        s.gbox(3, -.75f, .95f, -2.52f, .4f, .2f, .06f);
        // koła
        wheel(s, 1.1f, .44f, 1.55f, spin); wheel(s, -1.1f, .44f, 1.55f, spin);
        wheel(s, 1.1f, .44f, -1.55f, spin); wheel(s, -1.1f, .44f, -1.55f, spin);
        // belka świetlna
        s.box(1, 0, 2.03f, -.15f, 1.3f, .1f, .38f);
        s.box(12, .36f, 2.14f, -.15f, .55f, .16f, .32f);
        s.box(13, -.36f, 2.14f, -.15f, .55f, .16f, .32f);
        float a = red ? 1f : .1f, b = red ? .1f : 1f;
        s.alpha(a); s.gbox(3, .36f, 2.17f, -.15f, .6f, .2f, .36f);
        s.alpha(b); s.gbox(4, -.36f, 2.17f, -.15f, .6f, .2f, .36f);
        s.alpha(red ? .4f : 0); s.push(); s.tr(.36f, 2.2f, -.15f); s.sph(Scene.GLOW, 14, 1.6f, 10); s.pop();
        s.alpha(red ? 0 : .4f); s.push(); s.tr(-.36f, 2.2f, -.15f); s.sph(Scene.GLOW, 15, 1.6f, 10); s.pop();
        s.white();
    }

    @Override public void tick(FxCtx c) {
        float p = c.p, z = carZ(p);
        boolean red = ((int) (c.age / 3.0)) % 2 == 0;
        if (c.every(2) && p < .95f) {
            c.par(new DustParticleEffect(red ? 0xFF2020 : 0x2860FF, 1.2f), (c.r.nextFloat() - .5f) * 1.5f, 2.3, z - .15 + (c.r.nextFloat() - .5f), 0, .05, 0);
        }
        if (c.every(5) && p < .96f) c.snd(SoundEvents.BLOCK_NOTE_BLOCK_PLING, 0, 2, z, 1.2f, (c.age / 5) % 2 == 0 ? 1.5f : 1.1f);
        if (p > .2f && p < .3f && c.every(2)) c.par(ParticleTypes.CAMPFIRE_COSY_SMOKE, 1, .2, z + 1, 0, .03, .0);
        if (c.at(.34f)) c.snd(SoundEvents.BLOCK_IRON_DOOR_OPEN, 1.7, 1, 5, 1.2f, 1f);
        if (c.at(.52f)) c.snd(SoundEvents.BLOCK_IRON_TRAPDOOR_CLOSE, 1, 1, 1, 1f, .8f);
        if (c.at(.77f)) { c.snd(SoundEvents.BLOCK_IRON_DOOR_CLOSE, 1.2, 1, 4.5, 1.2f, 1f); c.burst(ParticleTypes.POOF, 8, 1.2, 1, 4.6, .1); }
        if (c.at(.86f)) c.snd(SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, 0, .5, 5, 1.2f, .6f);
        if (p > .86f && c.every(2)) c.par(ParticleTypes.LARGE_SMOKE, 0, .3, z - 2.5, 0, .02, 0);
    }
}
