package pl.killeffect.client.fx;

import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import pl.killeffect.EffectType;

public final class ReaperFx extends FxEffect {
    public ReaperFx() { super(EffectType.REAPER); }

    @Override protected String[] tiles() {
        return new String[]{"f:14121C", "f:08070C", "s:D8D2BC", "g:60FFD0:240", "w:4A3220", "m:A8B8C8", "g:A0F0FF:230", "g:7FFFE0:140", "g:101010:150"};
    }

    static float rz(float p) { return p < .22f ? 6 : p < .5f ? lerp(6, 1.9f, sm(seg(p, .22f, .5f))) : 1.9f; }
    static float grow(float p) { return sm(seg(p, 0, .22f)) * (1 - sm(seg(p, .86f, 1))); }

    @Override public void render(Scene s) {
        final float p = s.p, t = s.t, g = grow(p), z = rz(p);
        // ofiara: drży, dostaje cios, upada, dusza ucieka
        if (p < .8f) {
            float hit = seg(p, .66f, .76f);
            float fall = -90 * sm(hit);
            float k = 1 - sm(seg(p, .72f, .8f));
            float tremble = p < .66f ? sin(t * 1.6f) * 2f * seg(p, .2f, .6f) : 0;
            victim(s, tremble * .03f, hit * .35f, -hit * 1.2f, 0, fall, k, k, k, -150 * (1 - hit), -150 * (1 - hit), 0, 0);
        }
        // dusza
        float so = seg(p, .68f, .95f);
        if (so > 0 && so < 1) {
            s.push(); s.tr(sin(t * .2f) * .4f, 1f + so * 6, -.6f + so * 1.5f); s.ry(t * 3); s.alpha(.6f * (1 - so));
            s.skinHuman(Scene.GLOW, -30, -30, 0, 0, 0, 0);
            s.white(); s.pop();
        }
        if (g < .01f) return;
        // Żniwiarz
        s.push();
        s.tr(0, -(1 - g) * 1.5f, z); s.ry(180); s.sc(1, g, 1); s.tr(0, sin(t * .12f) * .1f + .5f, 0);
        // szata
        s.surf(Scene.SOLID, 0, 8, 18, (u, v, o) -> {
            float a = v * 6.2831855f;
            float y0 = .1f + .15f * sin(7 * a + t * .2f);
            float r = lerp(1.05f, .5f, (float) Math.pow(u, .7));
            o[0] = r * cos(a); o[1] = lerp(y0, 2.7f, u); o[2] = r * sin(a);
        }, 4, 0, 0, 0);
        // naramienniki i kaptur
        s.box(0, 0, 2.55f, 0, 1.4f, .35f, .65f);
        s.push(); s.tr(0, 3.05f, 0); s.sph(Scene.SOLID, 0, .55f, 12);
        s.push(); s.tr(0, -.02f, .2f); s.sph(Scene.SOLID, 1, .4f, 10); s.pop();
        s.box(2, 0, -.05f, .3f, .38f, .42f, .26f);
        s.box(1, -.1f, .0f, .43f, .1f, .12f, .05f); s.box(1, .1f, 0, .43f, .1f, .12f, .05f);
        s.gbox(3, -.1f, 0, .45f, .08f, .08f, .04f); s.gbox(3, .1f, 0, .45f, .08f, .08f, .04f);
        s.pop();
        // ręce i kosa
        float swing = p < .5f ? -78 : p < .62f ? lerp(-78, -105, sm(seg(p, .5f, .62f))) : p < .7f ? lerp(-105, 82, easeIn(seg(p, .62f, .7f))) : lerp(82, 60, sm(seg(p, .7f, .8f)));
        s.limb(Scene.SOLID, 0, -.7f, 2.5f, 0, -.9f, 1.7f, .35f, .3f);
        s.limb(Scene.SOLID, 0, .7f, 2.5f, 0, .95f, 1.7f, .3f, .3f);
        s.push(); s.tr(.95f, 1.9f, .4f); s.rx(swing);
        s.limb(Scene.SOLID, 4, 0, -1.6f, 0, 0, 3.4f, 0, .1f);
        s.box(2, 0, 0, 0, .22f, .22f, .22f);
        s.push(); s.tr(0, 3.4f, 0);
        int N = 10;
        float prevY = 0, prevZ = 0;
        for (int i = 1; i <= N; i++) {
            float a = (i / (float) N) * 1.75f;
            float yy = sin(a) * 1.2f, zz = (1 - cos(a)) * 1.2f * 1.0f + (a * .0f);
            float zf = 1.2f - 1.2f * cos(a);
            float yf = 1.2f * sin(a);
            s.limb(Scene.SOLID, 5, 0, prevY, prevZ, 0, yf, zf, .05f + .12f * (1 - i / (float) N));
            s.limb(Scene.GLOW, 6, 0, prevY - .03f, prevZ + .03f, 0, yf - .03f, zf + .03f, .035f);
            prevY = yf; prevZ = zf;
        }
        s.pop();
        // smuga cięcia
        if (p > .64f && p < .74f) {
            float k = seg(p, .64f, .74f);
            s.push(); s.tr(0, 3.4f, 0); s.alpha(.8f * (1 - k));
            s.ring(Scene.GLOW, 6, 1.2f, 2.0f, 0, 1.2f + 3 * k, 10);
            s.white(); s.pop();
        }
        s.pop();
        s.pop();
    }

    @Override public void tick(FxCtx c) {
        float p = c.p, z = rz(p);
        if (p < .9f && c.every(2)) c.par(ParticleTypes.SOUL, (c.r.nextFloat() - .5f) * 2, .1, z + (c.r.nextFloat() - .5f) * 2, 0, .04, 0);
        if (p < .3f && c.every(2)) c.par(ParticleTypes.SQUID_INK, (c.r.nextFloat() - .5f) * 2, .1, z, 0, .05, 0);
        if (c.at(.05f)) c.snd(SoundEvents.ENTITY_WITHER_AMBIENT, 0, 1, z, 1.6f, .5f);
        if (c.at(.5f)) c.snd(SoundEvents.ENTITY_PHANTOM_SWOOP, 0, 2, z, 1.5f, .5f);
        if (c.at(.66f)) {
            c.snd(SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 0, 1.4, 0, 2f, .5f);
            c.snd(SoundEvents.ENTITY_WITHER_HURT, 0, 1.4, 0, 1.5f, .6f);
            c.par(ParticleTypes.SWEEP_ATTACK, 0, 1.4, .2, 0, 0, 0);
            c.burst(ParticleTypes.SOUL_FIRE_FLAME, 30, 0, 1.2, 0, .3);
        }
        if (p > .7f && p < .93f && c.every(2)) c.par(ParticleTypes.SOUL_FIRE_FLAME, (c.r.nextFloat() - .5f) * .6f, 1 + (p - .7f) * 20, -.5, 0, .1, 0);
        if (c.at(.9f)) { c.snd(SoundEvents.PARTICLE_SOUL_ESCAPE, 0, 3, z, 2f, .7f); c.burst(ParticleTypes.LARGE_SMOKE, 25, 0, 1, z, .15); }
    }
}
