package pl.killeffect.client.fx;

import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/**
 * Kontekst rysowania sceny: prymitywy 3D (bryły, powierzchnie parametryczne, walce, kule, kończyny,
 * humanoidy). Ten sam kod rysuje efekt w świecie i w podglądzie GUI.
 * Konwencja układu: +Y góra, +Z "w stronę zabójcy" (skąd nadchodzą aktorzy), jednostka = blok.
 */
public final class Scene {
    public static final int SOLID = 0, TRANS = 1, GLOW = 2;
    public static final int FULL = 0xF000F0;
    private static final Identifier STEVE = Identifier.ofVanilla("textures/entity/player/wide/steve.png");

    /** Powierzchnia parametryczna: (u,v) in [0,1] -> punkt. */
    public interface P { void at(float u, float v, float[] o); }

    public final MatrixStack ms;
    public final VertexConsumerProvider vc;
    public final Identifier tex, skin;
    public final float p, t, dur;
    public float cr = 1, cg = 1, cb = 1, ca = 1;

    private final float[] UV = new float[24];
    private final float[] A = new float[3], B = new float[3], C = new float[3], D = new float[3];

    public Scene(MatrixStack ms, VertexConsumerProvider vc, Identifier tex, Identifier skin, float p, float t, float dur) {
        this.ms = ms; this.vc = vc; this.tex = tex; this.skin = skin; this.p = p; this.t = t; this.dur = dur;
    }

    // ---------- stan ----------
    public void col(float r, float g, float b, float a) { cr = r; cg = g; cb = b; ca = a; }
    public void alpha(float a) { ca = a; }
    public void white() { cr = cg = cb = ca = 1; }

    public void push() { ms.push(); }
    public void pop() { ms.pop(); }
    public void tr(float x, float y, float z) { ms.translate(x, y, z); }
    public void rx(float d) { ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(d)); }
    public void ry(float d) { ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(d)); }
    public void rz(float d) { ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(d)); }
    public void sc(float x, float y, float z) { ms.scale(x, y, z); }
    public void sc(float k) { ms.scale(k, k, k); }

    /** Obraca tak, aby lokalne +Z wskazywało kierunek (dx,dy,dz). */
    public void look(float dx, float dy, float dz) {
        float hz = (float) Math.sqrt(dx * dx + dz * dz);
        ry((float) Math.toDegrees(Math.atan2(dx, dz)));
        rx(-(float) Math.toDegrees(Math.atan2(dy, hz)));
    }

    private VertexConsumer buf(Identifier id, int kind) {
        RenderLayer l = switch (kind) {
            case TRANS -> RenderLayer.getEntityTranslucent(id);
            case GLOW -> RenderLayer.getEyes(id);
            default -> RenderLayer.getEntityCutoutNoCull(id);
        };
        return vc.getBuffer(l);
    }

    private void uvAll(int tile) {
        float u0 = (tile & 3) * .25f + .008f, v0 = (tile >> 2) * .25f + .008f, u1 = u0 + .234f, v1 = v0 + .234f;
        for (int i = 0; i < 6; i++) { UV[i * 4] = u0; UV[i * 4 + 1] = v0; UV[i * 4 + 2] = u1; UV[i * 4 + 3] = v1; }
    }

    private void v(VertexConsumer b, MatrixStack.Entry e, Matrix4f m, float x, float y, float z, float u, float vv,
                   float nx, float ny, float nz) {
        b.vertex(m, x, y, z).color((int) (cr * 255), (int) (cg * 255), (int) (cb * 255), (int) (ca * 255))
                .texture(u, vv).overlay(OverlayTexture.DEFAULT_UV).light(FULL).normal(e, nx, ny, nz);
    }

    private void face(VertexConsumer b, MatrixStack.Entry e, Matrix4f m, int f, float nx, float ny, float nz,
                      float a1, float a2, float a3, float b1, float b2, float b3,
                      float c1, float c2, float c3, float d1, float d2, float d3) {
        float u0 = UV[f * 4], v0 = UV[f * 4 + 1], u1 = UV[f * 4 + 2], v1 = UV[f * 4 + 3];
        v(b, e, m, a1, a2, a3, u0, v1, nx, ny, nz);
        v(b, e, m, b1, b2, b3, u1, v1, nx, ny, nz);
        v(b, e, m, c1, c2, c3, u1, v0, nx, ny, nz);
        v(b, e, m, d1, d2, d3, u0, v0, nx, ny, nz);
    }

    private void cuboid(VertexConsumer b, float cx, float cy, float cz, float w, float h, float d) {
        MatrixStack.Entry e = ms.peek();
        Matrix4f m = e.getPositionMatrix();
        float x0 = cx - w / 2, x1 = cx + w / 2, y0 = cy - h / 2, y1 = cy + h / 2, z0 = cz - d / 2, z1 = cz + d / 2;
        face(b, e, m, 0, 0, 0, 1, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1);
        face(b, e, m, 1, 0, 0, -1, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0);
        face(b, e, m, 2, -1, 0, 0, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0);
        face(b, e, m, 3, 1, 0, 0, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1);
        face(b, e, m, 4, 0, 1, 0, x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0);
        face(b, e, m, 5, 0, -1, 0, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1);
    }

    // ---------- bryły ----------
    public void box(int k, int tile, float cx, float cy, float cz, float w, float h, float d) {
        uvAll(tile);
        cuboid(buf(tex, k), cx, cy, cz, w, h, d);
    }
    public void box(int tile, float cx, float cy, float cz, float w, float h, float d) { box(SOLID, tile, cx, cy, cz, w, h, d); }
    public void gbox(int tile, float cx, float cy, float cz, float w, float h, float d) { box(GLOW, tile, cx, cy, cz, w, h, d); }

    /** Kończyna/belka między dwoma punktami. */
    public void limb(int k, int tile, float ax, float ay, float az, float bx, float by, float bz, float th) {
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-4f) return;
        ms.push();
        ms.translate((ax + bx) / 2, (ay + by) / 2, (az + bz) / 2);
        ms.multiply(new Quaternionf().rotationTo(0, 1, 0, dx / len, dy / len, dz / len));
        box(k, tile, 0, 0, 0, th, len, th);
        ms.pop();
    }

    /**
     * Powierzchnia parametryczna. mode: 0 bez korekty normalnej, 1 normalna od punktu ref, 2 do punktu ref,
     * 3/4/5 od osi Z/Y/X, 6 wymuszone +Y, 7 wymuszone -Y.
     */
    public void surf(int k, int tile, int nu, int nv, P f, int mode, float rx, float ry, float rz) {
        VertexConsumer b = buf(tex, k);
        MatrixStack.Entry e = ms.peek();
        Matrix4f m = e.getPositionMatrix();
        uvAll(tile);
        float u0 = UV[0], v0 = UV[1], u1 = UV[2], v1 = UV[3];
        for (int i = 0; i < nu; i++) {
            for (int j = 0; j < nv; j++) {
                f.at(i / (float) nu, j / (float) nv, A);
                f.at((i + 1) / (float) nu, j / (float) nv, B);
                f.at((i + 1) / (float) nu, (j + 1) / (float) nv, C);
                f.at(i / (float) nu, (j + 1) / (float) nv, D);
                float d1x = C[0] - A[0], d1y = C[1] - A[1], d1z = C[2] - A[2];
                float d2x = D[0] - B[0], d2y = D[1] - B[1], d2z = D[2] - B[2];
                float nx = d1y * d2z - d1z * d2y, ny = d1z * d2x - d1x * d2z, nz = d1x * d2y - d1y * d2x;
                float l = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
                if (l < 1e-9f) continue;
                nx /= l; ny /= l; nz /= l;
                float mx = (A[0] + B[0] + C[0] + D[0]) / 4, my = (A[1] + B[1] + C[1] + D[1]) / 4, mz = (A[2] + B[2] + C[2] + D[2]) / 4;
                float dot = 1;
                switch (mode) {
                    case 1 -> dot = nx * (mx - rx) + ny * (my - ry) + nz * (mz - rz);
                    case 2 -> dot = nx * (rx - mx) + ny * (ry - my) + nz * (rz - mz);
                    case 3 -> dot = nx * mx + ny * my;
                    case 4 -> dot = nx * mx + nz * mz;
                    case 5 -> dot = ny * my + nz * mz;
                    case 6 -> dot = ny;
                    case 7 -> dot = -ny;
                    default -> { }
                }
                if (dot < 0) {
                    nx = -nx; ny = -ny; nz = -nz;
                    v(b, e, m, D[0], D[1], D[2], u0, v0, nx, ny, nz);
                    v(b, e, m, C[0], C[1], C[2], u1, v0, nx, ny, nz);
                    v(b, e, m, B[0], B[1], B[2], u1, v1, nx, ny, nz);
                    v(b, e, m, A[0], A[1], A[2], u0, v1, nx, ny, nz);
                } else {
                    v(b, e, m, A[0], A[1], A[2], u0, v1, nx, ny, nz);
                    v(b, e, m, B[0], B[1], B[2], u1, v1, nx, ny, nz);
                    v(b, e, m, C[0], C[1], C[2], u1, v0, nx, ny, nz);
                    v(b, e, m, D[0], D[1], D[2], u0, v0, nx, ny, nz);
                }
            }
        }
    }

    /** Trójkąt dwustronny. */
    public void tri(int k, int tile, float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz) {
        surf(k, tile, 1, 1, (u, vv, o) -> {
            // bilinear z zapadniętym czwartym narożnikiem
            float x0 = ax + (bx - ax) * u, y0 = ay + (by - ay) * u, z0 = az + (bz - az) * u;
            o[0] = x0 + (cx - x0) * vv; o[1] = y0 + (cy - y0) * vv; o[2] = z0 + (cz - z0) * vv;
        }, 0, 0, 0, 0);
    }

    /** Walec/stożek ścięty wzdłuż +Y od y=0 do y=h. */
    public void cyl(int k, int tile, float r0, float r1, float h, int sides) {
        final float fr0 = r0, fr1 = r1, fh = h;
        surf(k, tile, 1, sides, (u, vv, o) -> {
            float a = vv * 6.2831855f, r = fr0 + (fr1 - fr0) * u;
            o[0] = r * (float) Math.cos(a); o[1] = u * fh; o[2] = r * (float) Math.sin(a);
        }, 4, 0, 0, 0);
        if (r1 > 0.001f) surf(k, tile, 1, sides, (u, vv, o) -> {
            float a = vv * 6.2831855f; o[0] = u * fr1 * (float) Math.cos(a); o[1] = fh; o[2] = u * fr1 * (float) Math.sin(a);
        }, 6, 0, 0, 0);
        if (r0 > 0.001f) surf(k, tile, 1, sides, (u, vv, o) -> {
            float a = vv * 6.2831855f; o[0] = u * fr0 * (float) Math.cos(a); o[1] = 0; o[2] = u * fr0 * (float) Math.sin(a);
        }, 7, 0, 0, 0);
    }

    public void sph(int k, int tile, float r, int seg) {
        final float fr = r;
        surf(k, tile, Math.max(4, seg / 2), seg, (u, vv, o) -> {
            float th = u * 3.1415927f, ph = vv * 6.2831855f;
            o[0] = fr * (float) (Math.sin(th) * Math.cos(ph)); o[1] = fr * (float) Math.cos(th); o[2] = fr * (float) (Math.sin(th) * Math.sin(ph));
        }, 1, 0, 0, 0);
    }

    /** Pierścień (annulus) w płaszczyźnie XZ, fragment kąta a0..a1 (radiany). */
    public void ring(int k, int tile, float r0, float r1, float a0, float a1, int seg) {
        final float fr0 = r0, fr1 = r1, fa0 = a0, fa1 = a1;
        surf(k, tile, 1, seg, (u, vv, o) -> {
            float a = fa0 + (fa1 - fa0) * vv, r = fr0 + (fr1 - fr0) * u;
            o[0] = r * (float) Math.cos(a); o[1] = 0; o[2] = r * (float) Math.sin(a);
        }, 0, 0, 0, 0);
    }

    /** Postrzępiona błyskawica z dwóch warstw (obwódka + rdzeń). */
    public void bolt(int seed, float sx, float sy, float sz, float ex, float ey, float ez, float th, int segs, float amp, int tOuter, int tCore) {
        java.util.Random r = new java.util.Random(seed);
        float px = sx, py = sy, pz = sz;
        for (int i = 1; i <= segs; i++) {
            float f = i / (float) segs;
            float kk = (i == segs) ? 0 : amp * (1 - f * .3f);
            float nx = sx + (ex - sx) * f + (r.nextFloat() - .5f) * 2 * kk;
            float ny = sy + (ey - sy) * f + (r.nextFloat() - .5f) * kk * .4f;
            float nz = sz + (ez - sz) * f + (r.nextFloat() - .5f) * 2 * kk;
            limb(GLOW, tOuter, px, py, pz, nx, ny, nz, th);
            limb(GLOW, tCore, px, py, pz, nx, ny, nz, th * .4f);
            px = nx; py = ny; pz = nz;
        }
    }

    // ---------- humanoidy ----------
    private void skinBox(VertexConsumer b, int tu, int tv, float w, float h, float d, float cx, float cy, float cz, float inf) {
        float j = tu, k = tu + d, l = tu + d + w, m2 = tu + d + w + w, n = tu + d + w + d, o = tu + d + w + d + w;
        float p0 = tv, q = tv + d, r = tv + d + h;
        setUv(0, k, q, l, r); setUv(1, n, q, o, r); setUv(2, j, q, k, r);
        setUv(3, l, q, n, r); setUv(4, k, p0, l, q); setUv(5, l, p0, m2, q);
        cuboid(b, cx, cy, cz, w + 2 * inf, h + 2 * inf, d + 2 * inf);
    }
    private void setUv(int f, float a, float b, float c, float d) {
        UV[f * 4] = a / 64f; UV[f * 4 + 1] = b / 64f; UV[f * 4 + 2] = c / 64f; UV[f * 4 + 3] = d / 64f;
    }

    /** Postać gracza z jego skórką. Kąty w stopniach wokół X: ujemne = do przodu (+Z). */
    public void skinHuman(int kind, float aR, float aL, float lR, float lL, float hx, float hy, float spread) {
        Identifier id = skin != null ? skin : STEVE;
        VertexConsumer b = buf(id, kind);
        ms.push();
        ms.scale(.0585f, .0585f, .0585f);
        ms.push(); ms.translate(-2, 12, 0); rx(lR); skinBox(b, 0, 16, 4, 12, 4, 0, -6, 0, 0); ms.pop();
        ms.push(); ms.translate(2, 12, 0); rx(lL); skinBox(b, 16, 48, 4, 12, 4, 0, -6, 0, 0); ms.pop();
        skinBox(b, 16, 16, 8, 12, 4, 0, 18, 0, 0);
        ms.push(); ms.translate(-6, 22, 0); rz(-spread); rx(aR); skinBox(b, 40, 16, 4, 12, 4, 0, -4, 0, 0); ms.pop();
        ms.push(); ms.translate(6, 22, 0); rz(spread); rx(aL); skinBox(b, 32, 48, 4, 12, 4, 0, -4, 0, 0); ms.pop();
        ms.push(); ms.translate(0, 24, 0); ry(hy); rx(hx);
        skinBox(b, 0, 0, 8, 8, 8, 0, 4, 0, 0);
        skinBox(b, 32, 0, 8, 8, 8, 0, 4, 0, .5f);
        ms.pop();
        ms.pop();
    }
    public void skinHuman(int kind, float aR, float aL, float lR, float lL, float hx, float hy) { skinHuman(kind, aR, aL, lR, lL, hx, hy, 0); }

    /** Humanoid z kafelków (policjant, bóg gromów...). hat<0 = bez czapki, badge<0 = bez odznaki. */
    public void fig(int kind, int head, int hat, int body, int arm, int leg, int hand, int badge,
                    float aR, float aL, float lR, float lL, float hx, float hy) {
        ms.push();
        ms.scale(.0585f, .0585f, .0585f);
        ms.push(); ms.translate(-2, 12, 0); rx(lR); box(kind, leg, 0, -6, 0, 4, 12, 4); ms.pop();
        ms.push(); ms.translate(2, 12, 0); rx(lL); box(kind, leg, 0, -6, 0, 4, 12, 4); ms.pop();
        box(kind, body, 0, 18, 0, 8, 12, 4);
        if (badge >= 0) box(kind, badge, 2.2f, 21, 2.1f, 1.6f, 1.6f, .4f);
        ms.push(); ms.translate(-6, 22, 0); rx(aR); box(kind, arm, 0, -2, 0, 4, 8, 4); box(kind, hand, 0, -8, 0, 4, 4, 4); ms.pop();
        ms.push(); ms.translate(6, 22, 0); rx(aL); box(kind, arm, 0, -2, 0, 4, 8, 4); box(kind, hand, 0, -8, 0, 4, 4, 4); ms.pop();
        ms.push(); ms.translate(0, 24, 0); ry(hy); rx(hx);
        box(kind, head, 0, 4, 0, 8, 8, 8);
        if (hat >= 0) { box(kind, hat, 0, 8.7f, 0, 9, 2, 9); box(kind, hat, 0, 7.6f, 5.2f, 8, .7f, 3); }
        ms.pop();
        ms.pop();
    }
}
