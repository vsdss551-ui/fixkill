package pl.killeffect.client.fx;

import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import pl.killeffect.EffectType;

public final class SharkFx extends FxEffect {
    public SharkFx() { super(EffectType.SHARK); }

    @Override protected String[] tiles() {
        return new String[]{"s:6F7F8F", "s:E8EEF2", "q:2A8CFF:B4", "s:F8F8F0", "s:8A1020", "s:050505", "s:56626E", "g:FFFFFF:C8", "s:3A4650"};
    }

    static float waterR(float p) { return 7f * sm(seg(p, 0, .12f)) * (1 - sm(seg(p, .9f, 1))); }

    /** Pozycja rekina: {x,y,z, kierunek x,y,z, rozwarcie szczęki, widoczny}. */
    static float[] shark(float p) {
        float[] o = new float[8];
        o[7] = 1;
        if (p < .42f) {
            float th = 2 * PI * (p - .42f) / .30f;
            float rr = 4.2f;
            o[0] = rr * sin(th); o[1] = -.55f; o[2] = rr * cos(th);
            o[3] = cos(th); o[4] = 0; o[5] = -sin(th);
            o[6] = 0;
            if (p < .1f) o[7] = 0;
        } else {
            float q = seg(p, .42f, .72f);
            o[0] = 0; o[2] = 4.2f - 8.4f * q;
            float y = q <= 1 ? -.8f + 2.7f * sin(PI * q) : -.8f - (q - 1) * 4;
            o[1] = y;
            float dy = 2.7f * PI * cos(PI * q) / 8.4f;
            o[3] = 0; o[4] = dy; o[5] = -1;
            float open = q < .2f ? 0 : q < .5f ? 38 * sm(seg(q, .2f, .48f)) : q < .6f ? lerp(38, 2, seg(q, .5f, .6f)) : 2;
            o[6] = open;
            if (q > 1.2f) o[7] = 0;
        }
        return o;
    }

    private void loft(Scene s, final float z0, final float z1, final float a0, final float a1, int tile) {
        s.surf(Scene.SOLID, tile, 10, 8, (u, v, o) -> {
            float z = lerp(z0, z1, u);
            float f = (z + 3.2f) / 6.4f;
            float rad = (float) (.82 * Math.pow(Math.sin(Math.min(1f, f * 1.12f) * PI * .95f + .12f), .7) + .08f);
            float a = lerp(a0, a1, v);
            o[0] = rad * .95f * cos(a); o[1] = rad * sin(a); o[2] = z;
        }, 3, 0, 0, 0);
    }

    private void sharkModel(Scene s, float open, float swim) {
        s.push();
        s.ry(sin(swim) * 5);
        loft(s, -3.2f, 1.2f, 0, PI, 0);
        loft(s, -3.2f, 1.2f, PI, 2 * PI, 1);
        loft(s, 1.2f, 3.0f, 0, PI, 0);
        // dolna szczęka na zawiasie
        s.push(); s.tr(0, -.12f, 1.2f); s.rx(open);
        s.surf(Scene.SOLID, 1, 6, 8, (u, v, o) -> {
            float z = lerp(0, 1.8f, u), a = PI + PI * v;
            float rad = .62f * (1 - u * .75f);
            o[0] = rad * cos(a); o[1] = rad * sin(a) * .8f; o[2] = z;
        }, 3, 0, 0, 0);
        s.box(4, 0, .06f, .9f, .6f, .08f, 1.7f);
        for (int i = 0; i < 6; i++) { float z = .25f + i * .27f; s.box(3, .32f, .12f, z, .07f, .2f, .07f); s.box(3, -.32f, .12f, z, .07f, .2f, .07f); }
        s.pop();
        for (int i = 0; i < 6; i++) { float z = 1.4f + i * .28f; s.box(3, .3f, -.12f, z, .07f, .2f, .07f); s.box(3, -.3f, -.12f, z, .07f, .2f, .07f); }
        // płetwy
        s.tri(Scene.SOLID, 6, 0, .75f, -.4f, 0, .75f, .9f, 0, 1.9f, -.55f);
        s.tri(Scene.SOLID, 6, .6f, -.35f, .3f, .8f, -.4f, -.2f, 1.9f, -1.2f, -.3f);
        s.tri(Scene.SOLID, 6, -.6f, -.35f, .3f, -.8f, -.4f, -.2f, -1.9f, -1.2f, -.3f);
        // ogon
        s.push(); s.tr(0, 0, -3.1f); s.ry(sin(swim) * 18);
        s.tri(Scene.SOLID, 6, 0, 0, 0, 0, 1.4f, -1.2f, 0, .25f, -.1f);
        s.tri(Scene.SOLID, 6, 0, 0, 0, 0, -1.0f, -1.0f, 0, -.2f, -.05f);
        s.pop();
        // oczy i skrzela
        s.box(5, .45f, .35f, 1.7f, .12f, .12f, .12f); s.box(5, -.45f, .35f, 1.7f, .12f, .12f, .12f);
        for (int i = 0; i < 3; i++) { s.box(8, .6f, .1f, .35f - i * .22f, .03f, .35f, .06f); s.box(8, -.6f, .1f, .35f - i * .22f, .03f, .35f, .06f); }
        s.pop();
    }

    @Override public void render(Scene s) {
        final float p = s.p, t = s.t, R = waterR(p);
        // woda
        if (R > .05f) {
            final float fR = R;
            s.push(); s.alpha(.78f);
            s.surf(Scene.TRANS, 2, 5, 24, (u, v, o) -> {
                float a = v * 6.2831855f, r = u * fR;
                o[0] = r * cos(a); o[1] = .06f + .06f * sin(r * 1.6f - t * .25f) * u; o[2] = r * sin(a);
            }, 6, 0, 0, 0);
            s.white();
            for (int i = 0; i < 3; i++) {
                float f = ((t * .025f + i / 3f) % 1f);
                s.push(); s.tr(0, .12f, 0); s.alpha(.6f * (1 - f)); s.ring(Scene.TRANS, 7, f * fR * .9f, f * fR * .9f + .25f, 0, 6.2831855f, 28); s.pop();
            }
            s.white(); s.pop();
        }
        // ofiara
        if (p < .58f) {
            float sink = -.25f * sm(seg(p, 0, .15f));
            float bob = sin(t * .3f) * .05f;
            float k = 1 - sm(seg(p, .55f, .58f));
            victim(s, 0, sink + bob, 0, 0, 0, k, k, k, -150 + sin(t * .7f) * 30, -150 + sin(t * .7f + 2) * 30, sin(t * .5f) * 20, -sin(t * .5f) * 20);
        }
        // rekin
        float[] sh = shark(p);
        if (sh[7] > .5f && R > .5f) {
            s.push();
            s.tr(sh[0], sh[1], sh[2]);
            s.look(sh[3], sh[4], sh[5]);
            sharkModel(s, sh[6], t * .35f);
            s.pop();
        }
    }

    @Override public void tick(FxCtx c) {
        float p = c.p; float[] sh = shark(p);
        if (c.at(.02f)) c.snd(SoundEvents.ENTITY_PLAYER_SPLASH, 0, 0, 0, 2f, .6f);
        if (p < .12f && c.every(2)) c.burst(ParticleTypes.SPLASH, 6, 0, .1, 0, .3);
        if (p > .1f && p < .42f && c.every(2)) { c.par(ParticleTypes.SPLASH, sh[0], 0.1, sh[2], 0, .1, 0); c.par(ParticleTypes.BUBBLE, sh[0], 0, sh[2], 0, .05, 0); }
        if (c.at(.43f)) c.snd(SoundEvents.ENTITY_DOLPHIN_JUMP, sh[0], 1, sh[2], 3f, .5f);
        if (c.at(.43f)) c.burst(ParticleTypes.SPLASH, 40, sh[0], .2, sh[2], .5);
        if (c.at(.57f)) {
            c.snd(SoundEvents.ENTITY_GENERIC_EAT, 0, 1, 0, 2f, .5f);
            c.snd(SoundEvents.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 0, 1, 0, 2f, .7f);
            c.burst(ParticleTypes.SPLASH, 60, 0, 1, 0, .6);
            c.burst(ParticleTypes.CRIT, 20, 0, 1, 0, .5);
        }
        if (c.at(.7f)) { c.burst(ParticleTypes.SPLASH, 60, sh[0], .2, sh[2], .6); c.snd(SoundEvents.ENTITY_PLAYER_SPLASH, sh[0], 0, sh[2], 3f, .5f); }
        if (p > .72f && p < .9f && c.every(4)) c.par(ParticleTypes.BUBBLE, (c.r.nextFloat() - .5f) * 6, .1, (c.r.nextFloat() - .5f) * 6, 0, .1, 0);
    }
}
