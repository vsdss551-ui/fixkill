package pl.killeffect.client.fx;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

/**
 * Proceduralny generator tekstur: atlas 64x64 = 16 kafelków 16x16.
 * Specyfikacja kafelka: "styl:RRGGBB[:AA]" (AA w hex).
 * Style: s=jednolity z szumem, m=metal szczotkowany, p=panele z nitami, w=drewno, g=poświata,
 * c=szachownica, k=pasy ostrzegawcze, f=struktura/futro, r=skała, l=żyły lawy (przezroczyste tło), q=woda.
 */
public final class Tex {
    private static final Map<String, Identifier> CACHE = new HashMap<>();

    public static Identifier get(String key, String[] tiles) {
        Identifier id = CACHE.get(key);
        if (id != null) return id;
        NativeImage img = new NativeImage(NativeImage.Format.RGBA, 64, 64, true);
        for (int i = 0; i < 16; i++) {
            String spec = i < tiles.length ? tiles[i] : "s:FF00FF";
            paint(img, (i & 3) * 16, (i >> 2) * 16, spec, key.hashCode() * 31 + i * 7919);
        }
        id = Identifier.of("killeffect", "dyn/" + key);
        MinecraftClient.getInstance().getTextureManager().registerTexture(id, new NativeImageBackedTexture(img));
        CACHE.put(key, id);
        return id;
    }

    /** Zwalnia wszystkie tekstury (rozłączenie / zamknięcie świata) – brak wycieków pamięci GPU. */
    public static void clear() {
        var tm = MinecraftClient.getInstance().getTextureManager();
        for (Identifier id : CACHE.values()) tm.destroyTexture(id);
        CACHE.clear();
    }

    private static float h(int x, int y, int seed) {
        int n = x * 374761393 + y * 668265263 + seed * 1274126177;
        n = (n ^ (n >>> 13)) * 1274126177;
        n ^= n >>> 16;
        return (n & 0xFFFF) / 65535f;
    }

    private static void paint(NativeImage img, int ox, int oy, String spec, int seed) {
        char st = spec.charAt(0);
        int rgb = Integer.parseInt(spec.substring(2, 8), 16);
        int a0 = spec.length() > 9 ? Integer.parseInt(spec.substring(9), 16) : 255;
        int cr = (rgb >> 16) & 255, cg = (rgb >> 8) & 255, cb = rgb & 255;
        for (int y = 0; y < 16; y++) {
            for (int x = 0; x < 16; x++) {
                float n = h(x, y, seed);
                float sh = 1f;
                int a = a0;
                float mix = 0f; // domieszka bieli
                boolean bevel = true;
                switch (st) {
                    case 's' -> sh = .92f + .16f * n;
                    case 'f' -> sh = .72f + .5f * (n * .6f + h(x / 2, y / 2, seed + 3) * .4f);
                    case 'm' -> sh = .86f + .1f * ((y % 3 == 0) ? 1 : 0) + .08f * n + .06f * (float) Math.sin(x * .4);
                    case 'p' -> {
                        sh = .95f + .08f * n;
                        if (x % 8 == 0 || y % 8 == 0) sh *= .68f;
                        if (x % 8 == 2 && y % 8 == 2) sh *= 1.35f;
                    }
                    case 'w' -> sh = .74f + .26f * (.5f + .5f * (float) Math.sin(y * 1.7 + n * 2.2 + Math.sin(x * .5) * 1.3));
                    case 'g' -> {
                        bevel = false;
                        float dx = x - 7.5f, dy = y - 7.5f;
                        float d = (float) Math.sqrt(dx * dx + dy * dy) / 10.6f;
                        mix = Math.max(0, .55f * (1 - d));
                        sh = .85f + .3f * n;
                    }
                    case 'c' -> sh = (((x >> 2) + (y >> 2)) & 1) == 0 ? 1f : .6f;
                    case 'k' -> sh = (((x + y) >> 2) & 1) == 0 ? 1f : .08f;
                    case 'r' -> {
                        sh = .55f + .5f * h(x / 3, y / 3, seed + 9) + .2f * n;
                        if (h(x, y, seed + 5) > .93f) sh *= .4f;
                    }
                    case 'l' -> {
                        bevel = false;
                        double v = Math.abs(Math.sin(x * .85 + Math.sin(y * .7 + seed) * 2.1) * Math.sin(y * .8 + Math.cos(x * .6) * 2.0));
                        if (v < .2) { sh = 1.15f; mix = .25f; a = a0; } else { sh = .3f; a = 0; }
                    }
                    case 'q' -> {
                        bevel = false;
                        sh = .85f + .2f * (float) Math.sin((x + y) * .8 + n);
                        mix = (n > .88f) ? .5f : 0f;
                    }
                    default -> { }
                }
                if (bevel) {
                    if (x == 0 || y == 0) sh *= 1.12f;
                    if (x == 15 || y == 15) sh *= .8f;
                }
                int r = clamp((int) ((cr * sh) + 255 * mix));
                int g = clamp((int) ((cg * sh) + 255 * mix));
                int b = clamp((int) ((cb * sh) + 255 * mix));
                img.setColorArgb(ox + x, oy + y, (a << 24) | (r << 16) | (g << 8) | b);
            }
        }
    }

    private static int clamp(int v) { return v < 0 ? 0 : Math.min(v, 255); }
}
