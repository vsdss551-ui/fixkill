package pl.killeffect.client.fx;

import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import pl.killeffect.EffectType;

public final class ThunderFx extends FxEffect {
    static final float GZ = 2.8f, K = 3.2f, CLY = 24;
    public ThunderFx() { super(EffectType.THUNDER); }

    @Override protected String[] tiles() {
        return new String[]{"f:23252E", "f:3A3F4C", "g:E8F4FF:F0", "g:FFFFFF:FF", "s:9FC8F0", "m:E8C050", "p:2850B8", "f:E8EEF8", "s:3040A0", "m:8890A0", "w:5A3A20", "g:70D0FF:DC", "g:FFFFFF:F0"};
    }

    private static boolean on(float p, float at, float len) { return p >= at && p < at + len; }

    @Override public float flash(float p) {
        float f = 0;
        if (on(p, .2f, .012f) || on(p, .3f, .012f)) f = .25f;
        if (on(p, .4f, .03f)) f = .7f;
        if (on(p, .66f, .05f)) f = 1f * (1 - seg(p, .66f, .71f));
        if (p > .9f && p < .98f) f = Math.max(f, 1 - seg(p, .92f, .98f));
        if (p > .88f && p <= .92f) f = Math.max(f, seg(p, .88f, .92f));
        return f;
    }

    private void god(Scene s, float t, float arm, float k, float roar) {
        s.push(); s.sc(K * k);
        s.fig(Scene.SOLID, 4, -1, 6, 4, 6, 5, 5, arm, -10, 4 * sin(t * .1f), -4 * sin(t * .1f), roar, 0);
        s.pop();
    }

    @Override public void render(Scene s) {
        final float p = s.p, t = s.t;
        float cloud = sm(seg(p, 0, .15f)) * (1 - sm(seg(p, .88f, 1)));
        // chmury
        if (cloud > .01f) {
            s.push(); s.tr(0, CLY, 0); s.sc(cloud);
            boolean fl = flash(p) > .2f;
            for (int i = 0; i < 16; i++) {
                float a = i * 2.399f, r = 3 + (i % 5) * 2.1f;
                float x = r * cos(a + t * .006f), z = r * sin(a + t * .006f), y = sin(i * 1.7f + t * .03f) * 1.1f;
                float rad = 3.2f + (i % 4) * .9f;
                s.push(); s.tr(x, y, z); s.sc(1, .55f, 1);
                s.sph(Scene.SOLID, fl ? 1 : (i % 3 == 0 ? 1 : 0), rad, 10);
                s.pop();
            }
            if (fl) { s.alpha(.5f); s.sc(1, .4f, 1); s.sph(Scene.GLOW, 2, 11, 12); s.white(); }
            s.pop();
        }
        // pioruny ostrzegawcze
        if (on(p, .2f, .02f)) bolt(s, 1, 5, 4, 0, 3);
        if (on(p, .3f, .02f)) bolt(s, 2, -5, 3, 0, 3);
        // główny piorun
        if (p >= .4f && p < .5f) {
            float k = 1 - seg(p, .4f, .5f);
            if ((int) (p * 200) % 2 == 0 || p < .43f) bolt(s, 3, 0, GZ, 0, 3.4f * (.5f + k));
            s.push(); s.tr(0, 0, GZ); s.alpha(.55f * k); s.cyl(Scene.GLOW, 2, 1.1f, 1.1f, CLY, 12); s.white(); s.pop();
        }
        // ofiara
        if (p < .7f) {
            float k = p < .66f ? 1 : 1 - seg(p, .66f, .7f);
            float tremble = sin(t * 1.5f) * 3 * seg(p, .3f, .66f);
            victim(s, tremble * .02f, 0, 0, 0, 0, k, k, k, -150, -150, 0, 0);
            if (p >= .66f && p < .7f) { s.push(); s.tr(0, 0, 0); s.alpha(.8f); s.skinHuman(Scene.GLOW, -150, -150, 0, 0, 0, 0); s.white(); s.pop(); }
        }
        // bóg
        float app = sm(seg(p, .4f, .48f)), gone = sm(seg(p, .82f, .92f));
        float kk = app * (1 - gone);
        if (kk > .01f) {
            float arm;
            if (p < .48f) arm = 0;
            else if (p < .6f) arm = lerp(0, -170, sm(seg(p, .48f, .6f)));
            else if (p < .67f) arm = lerp(-170, -35, easeIn(seg(p, .6f, .67f)));
            else if (p < .72f) arm = -35;
            else arm = lerp(-35, -150, sm(seg(p, .72f, .8f)));
            s.push();
            s.tr(0, 0, GZ - (gone * 0)); s.ry(180);
            s.sc(1 - gone * .6f, 1 + gone * 2.5f, 1 - gone * .6f);
            float k2 = kk;
            s.alpha(1);
            god(s, t, arm, 1, p > .72f && p < .8f ? -25 : 0);
            // peleryna
            s.push(); s.sc(K, K, K);
            s.surf(Scene.SOLID, 8, 6, 8, (u, v, o) -> {
                o[0] = lerp(-.4f, .4f, v); o[1] = lerp(1.95f, .25f, u);
                o[2] = -.32f - u * .18f + .1f * sin(v * 5 + t * .25f + u * 3) * u;
            }, 0, 0, 0, 0);
            s.pop();
            // młot w prawej ręce
            s.push(); s.sc(K, K, K); s.tr(-.38f, 1.4f, 0); s.rx(arm); s.tr(0, -.55f, 0.04f);
            s.rx(-90 + (arm < -100 ? 0 : 0));
            s.limb(Scene.SOLID, 10, 0, -.4f, 0, 0, .9f, 0, .07f);
            s.box(9, 0, 1.0f, 0, .22f, .34f, .7f);
            s.alpha(.6f + .4f * sin(t * .8f)); s.gbox(11, 0, 1.0f, .36f, .2f, .22f, .04f); s.gbox(11, 0, 1.0f, -.36f, .2f, .22f, .04f);
            s.white(); s.pop();
            // oczy i aura
            s.push(); s.sc(K, K, K); s.tr(0, 2.3f, .0f);
            s.gbox(12, -.1f, .05f, .24f, .1f, .06f, .03f); s.gbox(12, .1f, .05f, .24f, .1f, .06f, .03f);
            s.box(7, 0, -.22f, .2f, .4f, .34f, .1f);
            s.pop();
            s.alpha(.18f); s.push(); s.tr(0, 3.2f, 0); s.sph(Scene.GLOW, 11, 3.5f, 10); s.pop(); s.white();
            s.pop();
        }
        // uderzenie młota
        if (p >= .66f) {
            float w = seg(p, .66f, .8f);
            if (w < 1) {
                s.push(); s.tr(0, .15f, 0);
                float r = lerp(.5f, 12, easeOut(w));
                s.alpha(.8f * (1 - w)); s.cyl(Scene.GLOW, 2, r, r, .3f, 28);
                s.alpha(.9f * (1 - w)); s.sph(Scene.GLOW, 3, lerp(1, 5, easeOut(seg(w, 0, .5f))), 12);
                s.white(); s.pop();
                for (int i = 0; i < 6; i++) {
                    float a = i * 1.0472f + .4f;
                    if ((int) (s.t * .7f + i) % 2 == 0) s.bolt(40 + i + (int) (s.t * .7f), 0, .3f, 0, 7 * cos(a) * easeOut(w), .2f, 7 * sin(a) * easeOut(w), .09f, 8, .5f, 2, 3);
                }
            }
        }
        // końcowy rozbłysk
        if (p > .9f && p < 1) {
            float w = seg(p, .9f, 1);
            s.push(); s.tr(0, 6, GZ); s.alpha(.9f * (1 - w)); s.sph(Scene.GLOW, 3, lerp(1, 10, easeOut(w)), 12); s.white(); s.pop();
        }
    }

    private void bolt(Scene s, int seed, float x, float z, float ground, float th) {
        s.bolt(seed * 100 + (int) (s.t * .5f), x * .2f, CLY, z * .2f, x, ground, z, .16f * (th / 3), 11, 1.6f, 2, 3);
    }

    @Override public void tick(FxCtx c) {
        float p = c.p;
        if (p < .9f && c.every(5)) c.par(ParticleTypes.CLOUD, (c.r.nextFloat() - .5f) * 14, CLY - 1, (c.r.nextFloat() - .5f) * 14, 0, -.02, 0);
        if (c.at(.2f)) { c.snd(SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 5, 4, 3, 8f, 1f); c.burst(ParticleTypes.ELECTRIC_SPARK, 15, 5, .3, 3, .4); }
        if (c.at(.3f)) { c.snd(SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, -5, 4, 2, 8f, .9f); c.burst(ParticleTypes.ELECTRIC_SPARK, 15, -5, .3, 2, .4); }
        if (c.at(.4f)) {
            c.snd(SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, 0, 1, GZ, 8f, .8f);
            c.snd(SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 0, 1, GZ, 10f, .7f);
            c.burst(ParticleTypes.ELECTRIC_SPARK, 50, 0, 1, GZ, .6);
            c.burst(ParticleTypes.CLOUD, 20, 0, .3, GZ, .3);
        }
        if (c.at(.5f)) c.snd(SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 0, 5, GZ, 4f, .5f);
        if (c.at(.62f)) c.snd(SoundEvents.ENTITY_PHANTOM_SWOOP, 0, 4, GZ, 3f, .5f);
        if (c.at(.66f)) {
            c.snd(SoundEvents.ITEM_TRIDENT_THUNDER, 0, 1, 0, 10f, .7f);
            c.snd(SoundEvents.ENTITY_GENERIC_EXPLODE, 0, 1, 0, 6f, .6f);
            c.burst(ParticleTypes.ELECTRIC_SPARK, 80, 0, 1, 0, .9);
            c.burst(ParticleTypes.FLASH, 1, 0, 1.5, 0, 0);
            c.burst(ParticleTypes.END_ROD, 40, 0, 1, 0, .7);
        }
        if (p > .66f && p < .8f && c.every(2)) c.par(ParticleTypes.ELECTRIC_SPARK, (c.r.nextFloat() - .5f) * 10, .3, (c.r.nextFloat() - .5f) * 10, 0, .1, 0);
        if (c.at(.9f)) {
            c.snd(SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 0, 10, GZ, 10f, .6f);
            c.burst(ParticleTypes.END_ROD, 60, 0, 6, GZ, .9);
        }
    }
}
