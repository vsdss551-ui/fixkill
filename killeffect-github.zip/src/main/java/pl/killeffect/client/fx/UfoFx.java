package pl.killeffect.client.fx;

import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import pl.killeffect.EffectType;

public final class UfoFx extends FxEffect {
    public UfoFx() { super(EffectType.UFO); }

    @Override protected String[] tiles() {
        return new String[]{"m:A9B3C2", "p:3A404B", "s:6FE0FF:8C", "g:50FF70:230", "g:70FF90:70", "g:FFF0A0:230", "s:7A3CD0", "s:50D060", "s:050505"};
    }

    static float ufoY(float p, float t) {
        if (p < .2f) return lerp(44, 13, easeOut(p / .2f));
        if (p < .78f) return 13 + sin(t * .15f) * .35f;
        return 13 + easeIn(seg(p, .78f, 1)) * 70;
    }

    static float beamOn(float p) { return sm(seg(p, .2f, .26f)) * (1 - sm(seg(p, .72f, .78f))); }

    @Override public void render(Scene s) {
        final float p = s.p, t = s.t, y = ufoY(p, t), on = beamOn(p), H = y - .5f;
        final float q = seg(p, .3f, .72f);
        // wiązka
        if (on > .01f) {
            float pulse = .8f + .2f * sin(t * .6f);
            s.push(); s.alpha(.32f * on * pulse); s.cyl(Scene.GLOW, 4, 3.3f, 1.1f, H, 22); s.pop();
            s.push(); s.alpha(.4f * on); s.cyl(Scene.GLOW, 3, 1.7f, .5f, H, 16); s.pop();
            for (int i = 0; i < 5; i++) {
                float f = ((t * .02f + i * .2f) % 1f);
                float rr = lerp(3.2f, 1.0f, f);
                s.push(); s.tr(0, f * H, 0); s.alpha(.7f * on * (1 - f)); s.cyl(Scene.GLOW, 3, rr, rr, .08f, 24); s.pop();
            }
            s.white();
        }
        // ofiara unoszona
        if (q < 1f && p < .72f) {
            float vy = lerp(0, y - 3.1f, sm(q));
            float k = 1 - .75f * q * q * q;
            float fl = sin(t * .5f) * 25;
            victim(s, 0, vy, 0, q * q * 900, 0, k, k, k, -150 + fl * q, -150 - fl * q, 10 * q, -10 * q);
        }
        // spodek
        s.push();
        s.tr(0, y, 0);
        float stretch = p > .78f ? 1 + 1.6f * seg(p, .78f, 1) : 1;
        float squash = p > .78f ? 1 - .4f * seg(p, .78f, 1) : 1;
        s.sc(squash, stretch, squash);
        s.ry(t * 2.2f);
        s.rz(sin(t * .1f) * 3);
        s.push(); s.sc(1, .26f, 1); s.sph(Scene.SOLID, 0, 3.7f, 18); s.pop();
        s.push(); s.tr(0, -.16f, 0); s.cyl(Scene.SOLID, 1, 3.75f, 3.75f, .22f, 26); s.pop();
        s.push(); s.tr(0, -.9f, 0); s.cyl(Scene.SOLID, 1, 1.0f, 2.6f, .8f, 18); s.pop();
        s.push(); s.tr(0, -.95f, 0); s.alpha(.5f + .5f * on); s.cyl(Scene.GLOW, 3, 1.1f, 1.1f, .06f, 16); s.white(); s.pop();
        // lampki
        for (int i = 0; i < 14; i++) {
            float a = i * 6.2831855f / 14;
            boolean lit = (i + (int) (t / 2.5f)) % 3 == 0;
            s.push(); s.tr(3.5f * cos(a), -.05f, 3.5f * sin(a)); s.ry(-deg(a)); s.box(lit ? Scene.GLOW : Scene.SOLID, lit ? 5 : 1, 0, 0, 0, .34f, .3f, .34f);
            if (lit) { s.alpha(.4f); s.gbox(3, 0, 0, 0, .7f, .6f, .7f); s.white(); }
            s.pop();
        }
        // kopuła + kosmita
        s.push(); s.tr(0, .5f, 0); s.sc(1, .85f, 1); s.box(Scene.SOLID, 7, 0, .1f, 0, .62f, .8f, .62f);
        s.box(Scene.SOLID, 7, 0, .65f, .05f, .8f, .6f, .7f);
        s.box(Scene.SOLID, 8, -.2f, .72f, .42f, .22f, .3f, .05f); s.box(Scene.SOLID, 8, .2f, .72f, .42f, .22f, .3f, .05f);
        s.sph(Scene.TRANS, 2, 1.7f, 14); s.pop();
        // nogi
        for (int i = 0; i < 3; i++) {
            float a = i * 2.0943952f + .5f;
            s.limb(Scene.SOLID, 1, 1.5f * cos(a), -.8f, 1.5f * sin(a), 2.2f * cos(a), -1.7f, 2.2f * sin(a), .22f);
            s.box(1, 2.2f * cos(a), -1.78f, 2.2f * sin(a), .6f, .12f, .6f);
        }
        s.pop();
    }

    @Override public void tick(FxCtx c) {
        float p = c.p, t = c.age, y = ufoY(p, t), on = beamOn(p);
        if (on > .3f) {
            for (int i = 0; i < 3; i++) {
                float f = c.r.nextFloat(), a = c.r.nextFloat() * 6.2831855f, rr = lerp(3.0f, 1.0f, f) * c.r.nextFloat();
                c.par(ParticleTypes.HAPPY_VILLAGER, rr * cos(a), f * (y - .5f), rr * sin(a), 0, .12, 0);
            }
            if (c.every(3)) c.par(ParticleTypes.END_ROD, (c.r.nextFloat() - .5f) * 2, 0.1, (c.r.nextFloat() - .5f) * 2, 0, .25, 0);
        }
        if (c.at(.12f)) c.snd(SoundEvents.ENTITY_ENDERMAN_TELEPORT, 0, y, 0, 2f, .6f);
        if (c.at(.2f)) c.snd(SoundEvents.BLOCK_BEACON_ACTIVATE, 0, 1, 0, 2f, 1f);
        if (p > .2f && p < .76f && c.every(25)) c.snd(SoundEvents.BLOCK_BEACON_AMBIENT, 0, 1, 0, 1.5f, 1f);
        if (c.at(.72f)) { c.snd(SoundEvents.BLOCK_BEACON_DEACTIVATE, 0, y, 0, 2f, 1f); c.snd(SoundEvents.ENTITY_PLAYER_LEVELUP, 0, y, 0, 1f, .5f);
            c.burst(ParticleTypes.END_ROD, 30, 0, y - 1.5, 0, .4); }
        if (c.at(.8f)) c.snd(SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, 0, y, 0, 2f, .5f);
        if (p > .8f && c.every(2)) c.par(ParticleTypes.CLOUD, 0, y - 1, 0, 0, -.2, 0);
    }
}
