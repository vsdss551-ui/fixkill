# Kill Effects (Fabric 1.21.4)

Gdy zabijesz gracza, odpala sie animacja + dzwiek.

Animacje: Odlot w gore, Dusza, Szkielet, Piorun, Spirala.
Dzwieki: Level Up, Grzmot, Kosci, Dzwonki, Fajerwerk, Smok (lub brak).

GUI: przycisk "Kill Effects" w menu pauzy (Esc), komenda /killfx albo klawisz K.
W GUI: wybor animacji i dzwieku, ON/OFF, moby, glosnosc, przycisk Test.
Ustawienia zapisuja sie w .minecraft/config/killfx.json.

Wymaga: Fabric Loader + Fabric API dla 1.21.4.

Budowanie jara: wrzuc zawartosc folderu na GitHub (razem z .github), Actions -> build -> Run workflow,
pobierz artefakt killfx-jar.
