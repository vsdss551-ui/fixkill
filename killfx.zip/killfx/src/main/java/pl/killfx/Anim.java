package pl.killfx;

public enum Anim {
    FLY_AWAY("Odlot w górę"),
    SOUL("Dusza"),
    SKELETON("Szkielet"),
    LIGHTNING("Piorun"),
    SPIRAL("Spirala");

    public final String label;
    Anim(String label) { this.label = label; }
}
