package pl.killfx;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.*;

/** .minecraft/config/killfx.json */
public class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("killfx.json");

    public boolean enabled = true;
    public String animation = Anim.FLY_AWAY.name();
    public String sound = Snd.LEVELUP.name();
    public int volume = 100;
    public boolean mobs = false;

    public static Config I = new Config();

    public Anim anim() {
        try { return Anim.valueOf(animation); } catch (Exception e) { return Anim.FLY_AWAY; }
    }

    public Snd snd() {
        try { return Snd.valueOf(sound); } catch (Exception e) { return Snd.LEVELUP; }
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Config c = GSON.fromJson(Files.readString(FILE), Config.class);
                if (c != null) I = c;
            }
            save();
        } catch (Exception e) {
            KillFxMod.LOGGER.error("Config error", e);
        }
    }

    public static void save() {
        try { Files.writeString(FILE, GSON.toJson(I)); }
        catch (Exception e) { KillFxMod.LOGGER.error("Config save error", e); }
    }
}
