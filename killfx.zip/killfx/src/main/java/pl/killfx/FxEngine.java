package pl.killfx;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ItemStackParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FxEngine {
    private record Pending(ClientWorld world, Vec3d pos, Snd.Step step, long due) {}

    private static final List<Active> ACTIVE = new ArrayList<>();
    private static final List<Pending> PENDING = new ArrayList<>();
    private static long T = 0;

    public static void play(Subject s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld w = mc.world;
        Config c = Config.I;
        if (w == null || !c.enabled) return;
        try {
            Active a = new Active(c.anim(), s, w);
            a.start();
            ACTIVE.add(a);
        } catch (Throwable t) {
            KillFxMod.LOGGER.error("Animation failed", t);
        }
        for (Snd.Step st : c.snd().steps)
            PENDING.add(new Pending(w, s.pos(), st, T + st.delay()));
    }

    public static void tick() {
        T++;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld w = mc.world;

        Iterator<Pending> pi = PENDING.iterator();
        while (pi.hasNext()) {
            Pending p = pi.next();
            if (p.world != w) { pi.remove(); continue; }
            if (T >= p.due) {
                SoundEvent ev = SoundEvent.of(Identifier.of("minecraft", p.step.id()));
                float vol = Config.I.volume / 100f;
                w.playSound(p.pos.x, p.pos.y, p.pos.z, ev, SoundCategory.PLAYERS, vol, p.step.pitch(), false);
                pi.remove();
            }
        }

        Iterator<Active> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Active a = it.next();
            if (a.w != w) { it.remove(); continue; }
            boolean done;
            try { done = a.tick(); } catch (Throwable t) { KillFxMod.LOGGER.error("Anim tick", t); done = true; }
            if (done) { a.cleanup(); it.remove(); }
        }
    }

    public static void clear() {
        for (Active a : ACTIVE) a.cleanup();
        ACTIVE.clear();
        PENDING.clear();
    }

    private static class Active {
        final Anim anim;
        final Subject s;
        final ClientWorld w;
        int age = 0;
        double h = 0;
        float spin;
        Ghost ghost;
        Entity extra;

        Active(Anim anim, Subject s, ClientWorld w) {
            this.anim = anim; this.s = s; this.w = w; this.spin = s.yaw();
        }

        void start() {
            Vec3d p = s.pos();
            switch (anim) {
                case FLY_AWAY, SOUL -> {
                    if (s.skin() != null) {
                        ghost = new Ghost(w, s);
                        ghost.setGlowing(anim == Anim.SOUL);
                        w.addEntity(ghost);
                    }
                }
                case LIGHTNING -> {
                    LightningEntity l = new LightningEntity(EntityType.LIGHTNING_BOLT, w);
                    l.refreshPositionAndAngles(p.x, p.y, p.z, 0f, 0f);
                    l.setCosmetic(true);
                    w.addEntity(l);
                    extra = l;
                }
                default -> {}
            }
        }

        private double rnd() { return w.random.nextDouble() - 0.5; }

        private void burst(ParticleEffect e, Vec3d c, int n, double speed) {
            for (int i = 0; i < n; i++)
                w.addParticle(e, c.x, c.y, c.z, rnd() * speed, rnd() * speed + 0.05, rnd() * speed);
        }

        boolean tick() {
            age++;
            Vec3d p = s.pos();
            switch (anim) {
                case FLY_AWAY -> {
                    h += 0.1 + age * 0.02;
                    spin += 28f;
                    Vec3d c = new Vec3d(p.x, p.y + h, p.z);
                    if (ghost != null) {
                        ghost.setPosition(c.x, c.y, c.z);
                        ghost.setYaw(spin); ghost.setBodyYaw(spin); ghost.setHeadYaw(spin);
                    }
                    for (int i = 0; i < 3; i++)
                        w.addParticle(ParticleTypes.CLOUD, c.x + rnd() * 0.5, c.y + 0.5 + rnd(), c.z + rnd() * 0.5, 0, -0.05, 0);
                    if (age >= 28) {
                        burst(ParticleTypes.FIREWORK, c.add(0, 1, 0), 50, 0.6);
                        w.addParticle(ParticleTypes.EXPLOSION, c.x, c.y + 1, c.z, 0, 0, 0);
                        return true;
                    }
                }
                case SOUL -> {
                    h += 0.05;
                    double sx = Math.sin(age * 0.3) * 0.15;
                    Vec3d c = new Vec3d(p.x + sx, p.y + h, p.z);
                    if (ghost != null) ghost.setPosition(c.x, c.y, c.z);
                    w.addParticle(ParticleTypes.SOUL, c.x + rnd() * 0.6, c.y + w.random.nextDouble() * 1.8, c.z + rnd() * 0.6, 0, 0.03, 0);
                    if (age >= 55) {
                        burst(ParticleTypes.CLOUD, c.add(0, 1, 0), 25, 0.3);
                        burst(ParticleTypes.SOUL_FIRE_FLAME, c.add(0, 1, 0), 20, 0.3);
                        return true;
                    }
                }
                case SKELETON -> {
                    ParticleEffect bone = new ItemStackParticleEffect(ParticleTypes.ITEM, new ItemStack(Items.BONE));
                    if (age <= 24) {
                        Vec3d t = p.add(0, 0.9, 0);
                        for (int k = 0; k < 5; k++) {
                            double ang = w.random.nextDouble() * Math.PI * 2;
                            double r = 1.8 + w.random.nextDouble() * 0.6;
                            double px = p.x + Math.cos(ang) * r;
                            double py = p.y + w.random.nextDouble() * 2.2;
                            double pz = p.z + Math.sin(ang) * r;
                            w.addParticle(bone, px, py, pz, (t.x - px) * 0.09, (t.y - py) * 0.09, (t.z - pz) * 0.09);
                        }
                    }
                    if (age == 24) {
                        SkeletonEntity sk = new SkeletonEntity(EntityType.SKELETON, w);
                        sk.setAiDisabled(true);
                        sk.setNoGravity(true);
                        sk.refreshPositionAndAngles(p.x, p.y, p.z, s.yaw(), 0f);
                        sk.setHeadYaw(s.yaw());
                        sk.setBodyYaw(s.yaw());
                        w.addEntity(sk);
                        extra = sk;
                        burst(bone, p.add(0, 1, 0), 20, 0.3);
                    }
                    if (age >= 60) {
                        burst(bone, p.add(0, 1, 0), 40, 0.5);
                        burst(ParticleTypes.CLOUD, p.add(0, 1, 0), 15, 0.3);
                        return true;
                    }
                }
                case LIGHTNING -> {
                    for (int i = 0; i < 4; i++)
                        w.addParticle(ParticleTypes.ELECTRIC_SPARK, p.x + rnd(), p.y + w.random.nextDouble() * 2, p.z + rnd(), rnd() * 0.3, 0.1, rnd() * 0.3);
                    if (age >= 30) return true;
                }
                case SPIRAL -> {
                    for (int i = 0; i < 3; i++) {
                        double ang = age * 0.5 + i * 2.094;
                        double r = Math.max(0.2, 1.1 - age * 0.012);
                        double y = p.y + age * 0.06;
                        w.addParticle(ParticleTypes.END_ROD, p.x + Math.cos(ang) * r, y, p.z + Math.sin(ang) * r, 0, 0.02, 0);
                        w.addParticle(ParticleTypes.WITCH, p.x + Math.cos(ang + 3.14) * r, y, p.z + Math.sin(ang + 3.14) * r, 0, 0.02, 0);
                    }
                    if (age >= 45) {
                        burst(ParticleTypes.END_ROD, new Vec3d(p.x, p.y + 2.7, p.z), 40, 0.4);
                        return true;
                    }
                }
            }
            return false;
        }

        void cleanup() {
            if (ghost != null) { w.removeEntity(ghost.getId(), Entity.RemovalReason.DISCARDED); ghost = null; }
            if (extra != null) { w.removeEntity(extra.getId(), Entity.RemovalReason.DISCARDED); extra = null; }
        }
    }
}
