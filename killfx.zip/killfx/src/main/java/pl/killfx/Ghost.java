package pl.killfx;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.client.world.ClientWorld;

import java.util.UUID;

/** Kopia gracza (tylko po stronie klienta) ze skinem ofiary. */
public class Ghost extends OtherClientPlayerEntity {
    private final SkinTextures skin;

    public Ghost(ClientWorld world, Subject s) {
        super(world, new GameProfile(UUID.randomUUID(), s.name()));
        this.skin = s.skin();
        setNoGravity(true);
        refreshPositionAndAngles(s.pos().x, s.pos().y, s.pos().z, s.yaw(), 0f);
        setHeadYaw(s.yaw());
        setBodyYaw(s.yaw());
    }

    @Override
    public SkinTextures getSkinTextures() {
        return skin;
    }
}
