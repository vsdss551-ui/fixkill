package pl.killfx;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class KillFxMod implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("killfx");

    /** id encji -> tick swiata, w ktorym ostatnio ja uderzylismy */
    private static final Map<Integer, Long> HITS = new HashMap<>();
    private static ClientWorld lastWorld;
    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        Config.load();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.killfx.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, "category.killfx"));

        // Zapamietujemy kogo bijemy
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && entity instanceof LivingEntity && !(entity instanceof ArmorStandEntity))
                HITS.put(entity.getId(), world.getTime());
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(KillFxMod::onTick);

        // Przycisk w menu pauzy (wygodny na telefonie)
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Kill Effects"),
                        b -> client.setScreen(new KillFxScreen(screen)))
                        .dimensions(6, 6, 100, 20).build());
            }
        });

        // Komenda /killfx
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("killfx").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new KillFxScreen(null)));
                    return 1;
                })));
    }

    private static void onTick(MinecraftClient mc) {
        while (openKey.wasPressed()) mc.setScreen(new KillFxScreen(mc.currentScreen));

        ClientWorld w = mc.world;
        if (w != lastWorld) {
            FxEngine.clear();
            HITS.clear();
            lastWorld = w;
        }
        if (w == null) return;

        FxEngine.tick();

        long now = w.getTime();
        Iterator<Map.Entry<Integer, Long>> it = HITS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Long> en = it.next();
            Entity e = w.getEntityById(en.getKey());
            if (!(e instanceof LivingEntity le) || now - en.getValue() > 100) { it.remove(); continue; }
            if (le.isDead()) {
                it.remove();
                if (now - en.getValue() <= 60) onKill(le);
            }
        }
    }

    private static void onKill(LivingEntity victim) {
        boolean isPlayer = victim instanceof AbstractClientPlayerEntity;
        if (!isPlayer && !Config.I.mobs) return;
        Subject s = new Subject(victim.getPos(), victim.getYaw(),
                isPlayer ? ((AbstractClientPlayerEntity) victim).getSkinTextures() : null,
                victim.getName().getString());
        FxEngine.play(s);
    }
}
