package pl.killfx;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

public class KillFxScreen extends Screen {
    private final Screen parent;

    public KillFxScreen(Screen parent) {
        super(Text.literal("Kill Effects"));
        this.parent = parent;
    }

    private static Text label(String name, boolean selected) {
        return selected ? Text.literal("\u25BA " + name).formatted(Formatting.GREEN) : Text.literal(name);
    }

    @Override
    protected void init() {
        Config c = Config.I;
        int colW = 130, gap = 10;
        int leftX = width / 2 - colW - gap / 2;
        int rightX = width / 2 + gap / 2;
        int y0 = 36, step = 20;

        int i = 0;
        for (Anim a : Anim.values()) {
            addDrawableChild(ButtonWidget.builder(label(a.label, c.anim() == a), b -> {
                c.animation = a.name(); Config.save(); clearAndInit();
            }).dimensions(leftX, y0 + i++ * step, colW, 18).build());
        }
        i = 0;
        for (Snd s : Snd.values()) {
            addDrawableChild(ButtonWidget.builder(label(s.label, c.snd() == s), b -> {
                c.sound = s.name(); Config.save(); clearAndInit();
            }).dimensions(rightX, y0 + i++ * step, colW, 18).build());
        }

        int bw = 75, bg = 4;
        int bx = width / 2 - (4 * bw + 3 * bg) / 2;
        int by = height - 48;
        addDrawableChild(ButtonWidget.builder(Text.literal("Test"), b -> test())
                .dimensions(bx, by, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Efekty: " + (c.enabled ? "ON" : "OFF")), b -> {
            c.enabled = !c.enabled; Config.save(); clearAndInit();
        }).dimensions(bx + (bw + bg), by, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Moby: " + (c.mobs ? "ON" : "OFF")), b -> {
            c.mobs = !c.mobs; Config.save(); clearAndInit();
        }).dimensions(bx + 2 * (bw + bg), by, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Głośność: " + c.volume + "%"), b -> {
            c.volume = c.volume <= 25 ? 100 : c.volume - 25; Config.save(); clearAndInit();
        }).dimensions(bx + 3 * (bw + bg), by, bw, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Gotowe"), b -> close())
                .dimensions(width / 2 - 100, height - 24, 200, 20).build());
    }

    private void test() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        AbstractClientPlayerEntity p = mc.player;
        Vec3d look = Vec3d.fromPolar(0, p.getYaw()).normalize();
        Vec3d pos = p.getPos().add(look.multiply(3));
        Subject s = new Subject(pos, p.getYaw() + 180f, p.getSkinTextures(), p.getName().getString());
        mc.setScreen(null);
        FxEngine.play(s);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, "Kill Effects", width / 2, 10, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "Animacja", width / 2 - 70, 24, 0xFFAAAAAA);
        ctx.drawCenteredTextWithShadow(textRenderer, "Dźwięk", width / 2 + 70, 24, 0xFFAAAAAA);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
