package pl.killfx;

public enum Snd {
    NONE("Brak"),
    LEVELUP("Level Up", new Step("entity.player.levelup", 1.0f, 0)),
    THUNDER("Grzmot", new Step("entity.lightning_bolt.thunder", 1.0f, 0)),
    BONES("Kości",
            new Step("entity.skeleton.death", 1.0f, 0),
            new Step("block.bone_block.break", 0.8f, 3),
            new Step("block.bone_block.break", 1.2f, 6)),
    CHIME("Dzwonki",
            new Step("block.amethyst_block.chime", 1.0f, 0),
            new Step("block.amethyst_block.chime", 1.3f, 3),
            new Step("block.amethyst_block.chime", 1.6f, 6)),
    FIREWORK("Fajerwerk",
            new Step("entity.firework_rocket.large_blast", 1.0f, 0),
            new Step("entity.firework_rocket.twinkle", 1.0f, 5)),
    DRAGON("Smok", new Step("entity.ender_dragon.growl", 1.2f, 0));

    public record Step(String id, float pitch, int delay) {}

    public final String label;
    public final Step[] steps;
    Snd(String label, Step... steps) { this.label = label; this.steps = steps; }
}
