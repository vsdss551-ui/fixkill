package pl.killfx;

import net.minecraft.client.util.SkinTextures;
import net.minecraft.util.math.Vec3d;

/** Kto zginal: pozycja, obrot, skin (null dla mobow) i nick. */
public record Subject(Vec3d pos, float yaw, SkinTextures skin, String name) {}
