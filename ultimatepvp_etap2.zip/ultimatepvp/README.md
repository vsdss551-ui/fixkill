# Ultimate PvP Client – Etap 1 (MC 1.21.4, Fabric, Java 21)
Budowanie: zainstaluj Gradle 8.12+, uruchom `gradle wrapper` a potem `./gradlew build`. JAR: build/libs/.
Brak logowania/licencji. Domyślny klawisz GUI = Right Shift (zmienisz w GUI, Settings -> ClickGUI).
