package pl.ultimate;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.ultimate.config.ConfigManager;
import pl.ultimate.modules.ModuleManager;

public final class UltimateClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("ultimatepvp");

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ConfigManager.load();
        ClientTickEvents.END_CLIENT_TICK.register(ModuleManager::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> ConfigManager.saveNow());
    }
}
