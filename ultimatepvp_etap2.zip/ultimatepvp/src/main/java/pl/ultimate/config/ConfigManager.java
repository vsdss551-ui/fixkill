package pl.ultimate.config;

import com.google.gson.*;
import java.nio.file.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import net.fabricmc.loader.api.FabricLoader;
import pl.ultimate.UltimateClient;
import pl.ultimate.modules.*;

/** Jeden system konfiguracji. Zapis poza głównym wątkiem, z opóźnieniem (debounce) i atomowo. */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("ultimatepvp.json");
    private static final ScheduledExecutorService IO = Executors.newSingleThreadScheduledExecutor(r -> { Thread t = new Thread(r, "ultimatepvp-config"); t.setDaemon(true); return t; });
    private static final AtomicBoolean dirty = new AtomicBoolean();
    private static volatile ScheduledFuture<?> pending;
    private static volatile boolean loading;
    /** Dodatkowe sekcje (np. HUD) - inne systemy wpinają się tutaj. */
    public static final JsonObject EXTRA = new JsonObject();

    private ConfigManager() {}

    public static void markDirty() {
        if (loading) return;
        dirty.set(true);
        ScheduledFuture<?> p = pending;
        if (p != null) p.cancel(false);
        pending = IO.schedule(ConfigManager::flush, 500, TimeUnit.MILLISECONDS);
    }

    private static JsonObject snapshot() {
        JsonObject root = new JsonObject();
        root.addProperty("version", 1);
        JsonObject mods = new JsonObject();
        for (Module m : ModuleManager.all()) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.isEnabled());
            o.addProperty("bind", m.getBind());
            JsonObject s = new JsonObject();
            for (Setting<?> st : m.settings) s.add(st.name, st.save());
            o.add("settings", s);
            mods.add(m.name, o);
        }
        root.add("modules", mods);
        root.add("extra", EXTRA.deepCopy());
        return root;
    }

    private static void flush() {
        if (!dirty.getAndSet(false)) return;
        net.minecraft.client.MinecraftClient.getInstance().execute(() -> { JsonObject snap = snapshot(); IO.execute(() -> write(snap)); });
    }
    public static void saveNow() {
        ScheduledFuture<?> p = pending; if (p != null) p.cancel(false);
        dirty.set(false);
        write(snapshot());
    }
    private static synchronized void write(JsonObject root) {
        try {
            Files.createDirectories(FILE.getParent());
            Path tmp = FILE.resolveSibling("ultimatepvp.json.tmp");
            Files.writeString(tmp, GSON.toJson(root));
            try { Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception e) { UltimateClient.LOG.error("Config save failed", e); }
    }

    public static void load() {
        if (!Files.exists(FILE)) return;
        loading = true;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            JsonObject mods = root.has("modules") ? root.getAsJsonObject("modules") : null;
            if (mods != null) for (Module m : ModuleManager.all()) {
                JsonElement e = mods.get(m.name);
                if (e == null || !e.isJsonObject()) continue;
                JsonObject o = e.getAsJsonObject();
                try {
                    if (o.has("bind")) m.setBind(o.get("bind").getAsInt());
                    JsonObject s = o.has("settings") ? o.getAsJsonObject("settings") : new JsonObject();
                    for (Setting<?> st : m.settings) if (s.has(st.name)) try { st.load(s.get(st.name)); } catch (Exception ignored) {}
                    if (o.has("enabled") && o.get("enabled").getAsBoolean()) m.restoreEnabled(true);
                } catch (Exception ex) { UltimateClient.LOG.warn("Bad config for {}", m.name, ex); }
            }
            JsonObject extra = root.has("extra") ? root.getAsJsonObject("extra") : null;
            if (extra != null) for (String k : extra.keySet()) EXTRA.add(k, extra.get(k));
        } catch (Exception e) {
            UltimateClient.LOG.error("Config corrupt - backing up and using defaults", e);
            try { Files.move(FILE, FILE.resolveSibling("ultimatepvp.json.corrupt-" + System.currentTimeMillis()), StandardCopyOption.REPLACE_EXISTING); } catch (Exception ignored) {}
        } finally { loading = false; }
    }

    public static void resetAll() {
        for (Module m : ModuleManager.all()) { m.setEnabled(false); m.setBind(Module.NO_BIND); for (Setting<?> s : m.settings) s.reset(); }
        markDirty();
    }
}
