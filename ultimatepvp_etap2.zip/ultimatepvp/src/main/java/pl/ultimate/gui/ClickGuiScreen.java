package pl.ultimate.gui;

import java.util.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
import pl.ultimate.config.ConfigManager;
import pl.ultimate.modules.*;

/** Natywne GUI wzorowane na index.html (paleta, zaokrąglenia, dock z kategoriami, wyszukiwarka). Brak ekranu logowania. */
public final class ClickGuiScreen extends Screen {
    // paleta z :root w index.html
    private static final int ACCENT = 0xFF5BB8F5, ON_ACCENT = 0xFF0B0D10, PANEL = 0xF012151B, SURFACE = 0x09FFFFFF,
            HOVER = 0x12FFFFFF, BORDER = 0x14FFFFFF, TEXT = 0xFFEEF1F5, MUTED = 0xFF8E97A4, TRACK = 0x29FFFFFF;
    private static final int W = 520, H = 330, HDR = 36, DOCK = 28, ROW = 30, SROW = 20, PAD = 10;
    private static final int[] SWATCHES = {0xFF5BB8F5, 0xFFFF5555, 0xFFFFAA00, 0xFFFFFF55, 0xFF55FF55, 0xFF55FFFF, 0xFFAA55FF, 0xFFFF55FF, 0xFFFFFFFF, 0xFF000000};

    private record Hit(int x, int y, int w, int h, Runnable onClick) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }
    private final List<Hit> hits = new ArrayList<>();
    private final Map<Module, Float> toggleAnim = new IdentityHashMap<>();
    private final Set<Module> expanded = Collections.newSetFromMap(new IdentityHashMap<>());
    private Category cat = Category.COMBAT;
    private String search = "";
    private boolean searchFocus;
    private Module bindTarget;
    private Setting.Text textFocus;
    private Setting.Num dragNum; private int dragX, dragW;
    private float scroll, openAnim, tabX = -1;
    private int contentH;
    private String notice = ""; private long noticeUntil;

    public ClickGuiScreen() { super(Text.literal("Ultimate PvP")); }

    @Override public boolean shouldPause() { return false; }

    // ---------- render ----------
    @Override public void render(DrawContext c, int mx, int my, float dt) {
        openAnim = Math.min(1f, openAnim + dt * 0.12f);
        float e = 1f - (float) Math.pow(1f - openAnim, 3);
        c.fill(0, 0, width, height, ((int) (0x70 * e) << 24));
        int x0 = (width - W) / 2, y0 = (int) ((height - H) / 2 + (1f - e) * 14);
        hits.clear();
        round(c, x0 - 1, y0 - 1, W + 2, H + 2, 13, BORDER);
        round(c, x0, y0, W, H, 12, PANEL);

        // header
        c.drawText(textRenderer, "ULTIMATE", x0 + 14, y0 + 14, ACCENT, true);
        c.drawText(textRenderer, "PvP", x0 + 14 + textRenderer.getWidth("ULTIMATE ") , y0 + 14, TEXT, true);
        int sw = 150, sx = x0 + W - sw - 14, sy = y0 + 7;
        round(c, sx, sy, sw, 22, 8, searchFocus ? HOVER : SURFACE);
        String shown = search.isEmpty() && !searchFocus ? "Szukaj modułów..." : search + (searchFocus && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        c.drawText(textRenderer, shown, sx + 8, sy + 7, search.isEmpty() ? MUTED : TEXT, false);
        hits.add(new Hit(sx, sy, sw, 22, () -> { searchFocus = true; textFocus = null; }));

        // dock (kategorie)
        int dy = y0 + HDR;
        Category[] cats = Category.values();
        int tw = (W - 2 * PAD) / cats.length;
        float target = x0 + PAD + cat.ordinal() * tw;
        tabX = tabX < 0 ? target : tabX + (target - tabX) * Math.min(1f, dt * 0.35f);
        round(c, x0 + PAD, dy, W - 2 * PAD, DOCK - 4, 9, SURFACE);
        round(c, (int) tabX + 2, dy + 2, tw - 4, DOCK - 8, 7, 0x295BB8F5);
        for (Category k : cats) {
            int tx = x0 + PAD + k.ordinal() * tw;
            c.drawCenteredTextWithShadow(textRenderer, k.label, tx + tw / 2, dy + 7, k == cat && search.isEmpty() ? ACCENT : MUTED);
            hits.add(new Hit(tx, dy, tw, DOCK - 4, () -> { cat = k; scroll = 0; search = ""; }));
        }

        // lista
        int ly = y0 + HDR + DOCK + 4, lh = H - HDR - DOCK - 10, lx = x0 + PAD, lw = W - 2 * PAD;
        c.enableScissor(lx, ly, lx + lw, ly + lh);
        int y = ly - (int) scroll;
        for (Module m : visibleModules()) y = drawModule(c, m, lx, y, lw, mx, my, ly, ly + lh, dt);
        contentH = y + (int) scroll - ly;
        c.disableScissor();
        scroll = MathHelper.clamp(scroll, 0, Math.max(0, contentH - lh));

        if (System.currentTimeMillis() < noticeUntil) c.drawCenteredTextWithShadow(textRenderer, notice, x0 + W / 2, y0 + H + 6, 0xFFFFAA00);
    }

    private List<Module> visibleModules() {
        List<Module> out = new ArrayList<>();
        String q = search.toLowerCase();
        for (Module m : ModuleManager.all())
            if (q.isEmpty() ? m.category == cat : (m.name.toLowerCase().contains(q) || m.description.toLowerCase().contains(q))) out.add(m);
        return out;
    }

    private int drawModule(DrawContext c, Module m, int x, int y, int w, int mx, int my, int clipTop, int clipBot, float dt) {
        boolean isGui = m instanceof pl.ultimate.modules.impl.ClickGuiModule;
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + ROW - 2 && my >= clipTop && my < clipBot;
        round(c, x, y, w, ROW - 2, 9, hov ? HOVER : SURFACE);
        c.drawText(textRenderer, m.name, x + 10, y + 5, TEXT, true);
        var ms = c.getMatrices(); ms.push(); ms.scale(0.75f, 0.75f, 1f);
        c.drawText(textRenderer, m.description, (int) ((x + 10) / 0.75f), (int) ((y + 17) / 0.75f), MUTED, false);
        ms.pop();

        // przełącznik
        int tx = x + w - 38, ty = y + 8;
        if (!isGui) {
            float a = toggleAnim.merge(m, m.isEnabled() ? 1f : 0f, (o, n) -> o + (n - o) * Math.min(1f, dt * 0.4f));
            round(c, tx, ty, 26, 12, 6, lerpColor(TRACK, ACCENT, a));
            round(c, tx + 2 + (int) (14 * a), ty + 2, 8, 8, 4, 0xFFFFFFFF);
            hits.add(new Hit(tx, ty, 26, 12, m::toggle));
        }
        // bind
        String bt = bindTarget == m ? "..." : m.getBind() == Module.NO_BIND ? "None" : keyName(m.getBind());
        int bw = Math.max(34, textRenderer.getWidth(bt) + 12), bx = tx - bw - 8;
        round(c, bx, ty - 2, bw, 16, 6, bindTarget == m ? 0x405BB8F5 : SURFACE);
        c.drawCenteredTextWithShadow(textRenderer, bt, bx + bw / 2, ty + 2, bindTarget == m ? ACCENT : MUTED);
        hits.add(new Hit(bx, ty - 2, bw, 16, () -> { bindTarget = bindTarget == m ? null : m; textFocus = null; searchFocus = false; }));
        // rozwijanie ustawień
        if (!m.settings.isEmpty()) hits.add(new Hit(x, y, bx - x - 4, ROW - 2, () -> { if (!expanded.remove(m)) expanded.add(m); }));
        y += ROW;

        if (expanded.contains(m)) for (Setting<?> s : m.settings) y = drawSetting(c, s, x + 14, y, w - 14, mx, my);
        return y;
    }

    private int drawSetting(DrawContext c, Setting<?> s, int x, int y, int w, int mx, int my) {
        round(c, x, y, w, SROW - 2, 6, SURFACE);
        c.drawText(textRenderer, s.name, x + 8, y + 5, MUTED, false);
        int rx = x + w - 8;
        if (s instanceof Setting.Bool b) {
            round(c, rx - 22, y + 4, 22, 10, 5, b.get() ? ACCENT : TRACK);
            round(c, rx - 20 + (b.get() ? 12 : 0), y + 6, 6, 6, 3, 0xFFFFFFFF);
            hits.add(new Hit(rx - 22, y + 2, 22, 14, () -> b.set(!b.get())));
        } else if (s instanceof Setting.Num n) {
            int sw = 120, sx = rx - sw - 34;
            double f = (n.get() - n.min) / (n.max - n.min);
            round(c, sx, y + 8, sw, 3, 1, TRACK);
            round(c, sx, y + 8, Math.max(3, (int) (sw * f)), 3, 1, ACCENT);
            round(c, sx + (int) (sw * f) - 3, y + 6, 6, 7, 3, 0xFFFFFFFF);
            String v = n.step >= 1 ? String.valueOf(n.intValue()) : String.format("%.1f", n.get());
            c.drawText(textRenderer, v, rx - textRenderer.getWidth(v), y + 5, TEXT, false);
            hits.add(new Hit(sx - 4, y + 2, sw + 8, 14, () -> { dragNum = n; dragX = sx; dragW = sw; slide(mx); }));
        } else if (s instanceof Setting.Mode md) {
            String v = md.get();
            c.drawText(textRenderer, v, rx - textRenderer.getWidth(v), y + 5, ACCENT, false);
            hits.add(new Hit(rx - 80, y, 80, SROW - 2, md::next));
        } else if (s instanceof Setting.Color col) {
            for (int i = 0; i < SWATCHES.length; i++) {
                int sx = rx - (SWATCHES.length - i) * 14, sc = SWATCHES[i];
                round(c, sx, y + 4, 11, 11, 3, col.get() == sc ? 0xFFFFFFFF : BORDER);
                round(c, sx + 1, y + 5, 9, 9, 2, sc);
                hits.add(new Hit(sx, y + 4, 11, 11, () -> col.set(sc)));
            }
        } else if (s instanceof Setting.Text t) {
            int tw = 110, tx = rx - tw;
            round(c, tx, y + 2, tw, 14, 5, textFocus == t ? HOVER : 0x14FFFFFF);
            c.drawText(textRenderer, t.get() + (textFocus == t && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : ""), tx + 4, y + 5, TEXT, false);
            hits.add(new Hit(tx, y + 2, tw, 14, () -> { textFocus = t; searchFocus = false; bindTarget = null; }));
        }
        return y + SROW;
    }

    private void slide(double mx) {
        if (dragNum == null) return;
        double f = MathHelper.clamp((mx - dragX) / dragW, 0, 1);
        dragNum.setClamped(dragNum.min + f * (dragNum.max - dragNum.min));
    }

    // ---------- input ----------
    @Override public boolean mouseClicked(double mx, double my, int button) {
        int x0 = (width - W) / 2, y0 = (height - H) / 2;
        int ly = y0 + HDR + DOCK + 4, lb = ly + H - HDR - DOCK - 10;
        if (bindTarget != null && button > 1) { applyBind(bindTarget, 1000 + button); return true; }
        boolean wasSearch = searchFocus; searchFocus = false; textFocus = null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            boolean inList = my >= ly && my < lb;
            boolean header = h.y() < ly; // dock i wyszukiwarka
            if (h.in(mx, my) && (header || inList) && button == 0) { h.onClick().run(); return true; }
        }
        if (bindTarget != null) bindTarget = null;
        return super.mouseClicked(mx, my, button);
    }
    @Override public boolean mouseDragged(double mx, double my, int b, double dx, double dy) { if (dragNum != null) { slide(mx); return true; } return false; }
    @Override public boolean mouseReleased(double mx, double my, int b) { dragNum = null; return super.mouseReleased(mx, my, b); }
    @Override public boolean mouseScrolled(double mx, double my, double h, double v) { scroll -= (float) v * 22; return true; }

    @Override public boolean keyPressed(int key, int sc, int mod) {
        if (bindTarget != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE) bindTarget = null;
            else if (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) { bindTarget.setBind(Module.NO_BIND); bindTarget = null; }
            else applyBind(bindTarget, key);
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) { if (textFocus != null || searchFocus) { textFocus = null; searchFocus = false; return true; } close(); return true; }
        if (key == GLFW.GLFW_KEY_BACKSPACE) {
            if (textFocus != null && !textFocus.get().isEmpty()) textFocus.set(textFocus.get().substring(0, textFocus.get().length() - 1));
            else if (searchFocus && !search.isEmpty()) search = search.substring(0, search.length() - 1);
            return true;
        }
        if (key == GLFW.GLFW_KEY_ENTER) { textFocus = null; searchFocus = false; return true; }
        return super.keyPressed(key, sc, mod);
    }
    @Override public boolean charTyped(char ch, int mod) {
        if (ch < 32) return false;
        if (textFocus != null && textFocus.get().length() < 32) { textFocus.set(textFocus.get() + ch); return true; }
        if (searchFocus && search.length() < 24) { search += ch; scroll = 0; return true; }
        return false;
    }

    private void applyBind(Module m, int key) {
        Module other = ModuleManager.findBindConflict(key, m);
        if (other != null) { other.setBind(Module.NO_BIND); notice = "Bind " + keyName(key) + " zabrany modułowi " + other.name; noticeUntil = System.currentTimeMillis() + 3000; }
        m.setBind(key);
        bindTarget = null;
    }
    @Override public void removed() { ConfigManager.markDirty(); }

    // ---------- helpers ----------
    static String keyName(int key) {
        if (key >= 1000) return "Mouse" + (key - 1000 + 1);
        try { return InputUtil.fromKeyCode(key, 0).getLocalizedText().getString().toUpperCase(); } catch (Exception e) { return "KEY" + key; }
    }
    private static int lerpColor(int a, int b, float t) {
        int r = 0; for (int s = 24; s >= 0; s -= 8) r |= (int) (((a >> s) & 255) + ((((b >> s) & 255) - ((a >> s) & 255)) * t)) << s; return r;
    }
    /** Zaokrąglony prostokąt z linii poziomych (tanio dla małych promieni). */
    static void round(DrawContext c, int x, int y, int w, int h, int r, int col) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { c.fill(x, y, x + w, y + h, col); return; }
        c.fill(x, y + r, x + w, y + h - r, col);
        for (int i = 0; i < r; i++) {
            int in = r - (int) Math.floor(Math.sqrt((double) r * r - (double) (r - i - 0.5) * (r - i - 0.5)));
            c.fill(x + in, y + i, x + w - in, y + i + 1, col);
            c.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, col);
        }
    }
}
