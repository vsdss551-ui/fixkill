package pl.ultimate.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.ultimate.modules.impl.FreecamState;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setPos(double x, double y, double z);
    @Shadow protected abstract void setRotation(float yaw, float pitch);
    @Shadow private boolean thirdPerson;

    @Inject(method = "update", at = @At("TAIL"))
    private void ultimate$freecam(BlockView area, Entity focused, boolean third, boolean inverse, float tickDelta, CallbackInfo ci) {
        if (!FreecamState.active) return;
        setRotation(FreecamState.yaw, FreecamState.pitch);
        setPos(MathHelper.lerp(tickDelta, FreecamState.px, FreecamState.x),
               MathHelper.lerp(tickDelta, FreecamState.py, FreecamState.y),
               MathHelper.lerp(tickDelta, FreecamState.pz, FreecamState.z));
        thirdPerson = true;
    }
}
