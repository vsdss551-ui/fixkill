package pl.ultimate.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.ultimate.modules.impl.FreecamState;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void ultimate$freecamLook(double dx, double dy, CallbackInfo ci) {
        if (FreecamState.active && (Object) this == MinecraftClient.getInstance().player) {
            FreecamState.rotate(dx, dy);
            ci.cancel();
        }
    }
}
