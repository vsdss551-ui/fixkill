package pl.ultimate.mixin;

import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.util.PlayerInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.ultimate.modules.impl.FreecamState;

@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends Input {
    @Inject(method = "tick", at = @At("TAIL"))
    private void ultimate$freezePlayer(CallbackInfo ci) {
        if (!FreecamState.active) return;
        this.playerInput = new PlayerInput(false, false, false, false, false, false, false);
        this.movementForward = 0f;
        this.movementSideways = 0f;
    }
}
