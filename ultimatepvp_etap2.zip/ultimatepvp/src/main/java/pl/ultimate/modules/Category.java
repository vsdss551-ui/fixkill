package pl.ultimate.modules;

public enum Category {
    COMBAT("Combat"), PLAYER("Player"), VISUALS("Visuals"), RENDER("Render"), MISC("Misc"), SETTINGS("Settings");
    public final String label;
    Category(String l) { label = l; }
}
