package pl.ultimate.modules;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import pl.ultimate.config.ConfigManager;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();
    public static final int NO_BIND = -1;
    public final String name, description;
    public final Category category;
    private boolean enabled;
    private int bind = NO_BIND;
    public final List<Setting<?>> settings = new ArrayList<>();

    protected Module(String name, String description, Category category) { this.name = name; this.description = description; this.category = category; }

    protected <S extends Setting<?>> S add(S s) { settings.add(s); return s; }

    public boolean isEnabled() { return enabled; }
    public int getBind() { return bind; }
    public void setBind(int key) { if (bind != key) { bind = key; ConfigManager.markDirty(); } }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        try { if (on) onEnable(); else onDisable(); } catch (Throwable t) { pl.ultimate.UltimateClient.LOG.error("Module {} failed", name, t); }
        ConfigManager.markDirty();
    }
    public void toggle() { setEnabled(!enabled); }
    /** Wywoływane przy naciśnięciu przypisanego klawisza. */
    public void onBindPress() { toggle(); }
    public void restoreEnabled(boolean on) { if (on) setEnabled(true); }

    protected void onEnable() {}
    protected void onDisable() {}
    /** Wołane tylko gdy moduł jest włączony i gracz istnieje. */
    public void onTick() {}
}
