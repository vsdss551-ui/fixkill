package pl.ultimate.modules;

import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import pl.ultimate.modules.impl.*;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static final Map<Module, Boolean> down = new IdentityHashMap<>();

    private ModuleManager() {}

    public static void init() {
        register(new ClickGuiModule());
        register(new ErrorKiller());
        register(new AutoTotem());
        register(new AutoZupka());
        register(new FastPlace());
        register(new SzybkaWlotka());
        register(new AutoNielotka());
        register(new AutoObrazy());
        register(new FastLever());
        register(new TrapEscape());
        register(new FvckNielegal());
        register(new PearlChaser());
        register(new Freecam());
    }
    private static void register(Module m) { MODULES.add(m); }
    public static List<Module> all() { return Collections.unmodifiableList(MODULES); }

    /** Zwraca moduł już używający danego klawisza (poza 'except'), albo null. */
    public static Module findBindConflict(int key, Module except) {
        if (key == Module.NO_BIND) return null;
        for (Module m : MODULES) if (m != except && m.getBind() == key) return m;
        return null;
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        long h = mc.getWindow().getHandle();
        boolean canBind = mc.currentScreen == null;
        for (Module m : MODULES) {
            int k = m.getBind();
            if (k == Module.NO_BIND) { down.remove(m); continue; }
            boolean now = canBind && InputUtil.isKeyPressed(h, k);
            boolean was = down.getOrDefault(m, false);
            if (now && !was) m.onBindPress();
            down.put(m, now);
        }
        for (Module m : MODULES) if (m.isEnabled()) {
            try { m.onTick(); } catch (Throwable t) { pl.ultimate.UltimateClient.LOG.error("Tick error in {}", m.name, t); m.setEnabled(false); }
        }
    }
}
