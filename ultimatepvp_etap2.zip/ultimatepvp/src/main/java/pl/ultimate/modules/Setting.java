package pl.ultimate.modules;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.List;
import pl.ultimate.config.ConfigManager;

public abstract class Setting<T> {
    public final String name;
    protected T value;
    private final T def;
    protected Setting(String name, T def) { this.name = name; this.value = def; this.def = def; }
    public T get() { return value; }
    public void set(T v) { if (!java.util.Objects.equals(value, v)) { value = v; ConfigManager.markDirty(); } }
    public void reset() { set(def); }
    public abstract JsonElement save();
    public abstract void load(JsonElement e);

    public static final class Bool extends Setting<Boolean> {
        public Bool(String n, boolean d) { super(n, d); }
        public JsonElement save() { return new JsonPrimitive(value); }
        public void load(JsonElement e) { if (e.isJsonPrimitive() && e.getAsJsonPrimitive().isBoolean()) value = e.getAsBoolean(); }
    }
    public static final class Num extends Setting<Double> {
        public final double min, max, step;
        public Num(String n, double d, double min, double max, double step) { super(n, d); this.min = min; this.max = max; this.step = step; }
        public void setClamped(double v) {
            v = Math.max(min, Math.min(max, v));
            if (step > 0) v = Math.round(v / step) * step;
            set(v);
        }
        public int intValue() { return (int) Math.round(value); }
        public JsonElement save() { return new JsonPrimitive(value); }
        public void load(JsonElement e) { if (e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) value = Math.max(min, Math.min(max, e.getAsDouble())); }
    }
    public static final class Mode extends Setting<String> {
        public final List<String> modes;
        public Mode(String n, String d, String... modes) { super(n, d); this.modes = List.of(modes); }
        public void next() { set(modes.get((modes.indexOf(value) + 1) % modes.size())); }
        public JsonElement save() { return new JsonPrimitive(value); }
        public void load(JsonElement e) { if (e.isJsonPrimitive() && modes.contains(e.getAsString())) value = e.getAsString(); }
    }
    public static final class Color extends Setting<Integer> {
        public Color(String n, int argb) { super(n, argb); }
        public JsonElement save() { return new JsonPrimitive(value); }
        public void load(JsonElement e) { if (e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) value = e.getAsInt(); }
    }
    public static final class Text extends Setting<String> {
        public Text(String n, String d) { super(n, d); }
        public JsonElement save() { return new JsonPrimitive(value); }
        public void load(JsonElement e) { if (e.isJsonPrimitive()) value = e.getAsString(); }
    }
}
