package pl.ultimate.modules.impl;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import pl.ultimate.modules.*;
import pl.ultimate.utils.InvUtil;
import pl.ultimate.utils.PlayerScan;

public final class AutoNielotka extends Module {
    private final Setting.Num range = add(new Setting.Num("Zasięg (bloki)", 4.2, 1, 8, 0.1));
    private final Setting.Num reaction = add(new Setting.Num("Czas reakcji (ms)", 100, 0, 1000, 50));
    private final Setting.Num castCd = add(new Setting.Num("Przerwa między użyciami (ms)", 500, 100, 2000, 50));
    private final Setting.Num autoOff = add(new Setting.Num("Auto-wyłączenie (s)", 15, 5, 60, 1));
    private long endAt; private int prevSlot, react = -1, cd;
    private int lastShown = -1;

    public AutoNielotka() { super("AutoNielotka", "Wędka w drugiej ręce, reakcja na gracza w zasięgu.", Category.COMBAT); }

    @Override protected void onEnable() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        endAt = System.currentTimeMillis() + (long) (autoOff.get() * 1000); react = -1; cd = 0; lastShown = -1;
        prevSlot = p.getInventory().selectedSlot;
        InvUtil.select(p, 8); // slot 9
        if (!p.getOffHandStack().isOf(Items.FISHING_ROD)) {
            int idx = InvUtil.findInventory(p, s -> s.isOf(Items.FISHING_ROD));
            if (idx < 0) { mc.inGameHud.setOverlayMessage(Text.literal("AutoNielotka: brak wędki"), false); mc.execute(() -> setEnabled(false)); return; }
            InvUtil.swapToOffhand(mc, idx);
        }
    }
    @Override protected void onDisable() {
        if (mc.player != null) InvUtil.select(mc.player, prevSlot);
        if (mc.inGameHud != null) mc.inGameHud.setOverlayMessage(Text.empty(), false);
    }

    @Override public void onTick() {
        ClientPlayerEntity p = mc.player;
        long left = endAt - System.currentTimeMillis();
        if (left <= 0) { setEnabled(false); return; }
        int sec = (int) Math.ceil(left / 1000.0);
        if (sec != lastShown) { lastShown = sec; mc.inGameHud.setOverlayMessage(Text.literal("AutoNielotka: " + sec + "s"), false); }
        if (cd > 0) { cd--; return; }
        if (!p.getOffHandStack().isOf(Items.FISHING_ROD)) return;
        if (react < 0) {
            if (PlayerScan.anyNear(mc, range.get())) react = Math.min(InvUtil.ticks(reaction.get()), 20);
            return;
        }
        if (react-- > 0) return;
        react = -1;
        mc.interactionManager.interactItem(p, Hand.OFF_HAND);
        p.swingHand(Hand.OFF_HAND);
        cd = InvUtil.ticks(castCd.get());
    }
}
