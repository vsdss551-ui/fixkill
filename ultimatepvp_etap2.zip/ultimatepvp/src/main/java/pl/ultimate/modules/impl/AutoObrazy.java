package pl.ultimate.modules.impl;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import pl.ultimate.modules.*;
import pl.ultimate.utils.InvUtil;
import pl.ultimate.utils.PlayerScan;

public final class AutoObrazy extends Module {
    private final Setting.Num range = add(new Setting.Num("Zasięg graczy (bloki)", 3, 1, 8, 0.5));
    private final Setting.Num interval = add(new Setting.Num("Co ile (ms)", 300, 100, 1000, 50));
    private int cd = 0, prevSlot = -1;

    public AutoObrazy() { super("AutoObrazy", "Stawia obrazy, gdy gracz jest w pobliżu.", Category.COMBAT); }

    @Override protected void onDisable() { restore(); }
    private void restore() { if (prevSlot >= 0 && mc.player != null) InvUtil.select(mc.player, prevSlot); prevSlot = -1; }

    @Override public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (mc.interactionManager == null || mc.currentScreen != null) return;
        if (!PlayerScan.anyNear(mc, range.get())) { restore(); return; }   // wznowi się samo po wykryciu gracza
        if (cd > 0) { cd--; return; }
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        int slot = InvUtil.findHotbar(p, s -> s.isOf(Items.PAINTING));
        if (slot < 0) return;
        if (prevSlot < 0) prevSlot = p.getInventory().selectedSlot;
        InvUtil.select(p, slot);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
        p.swingHand(Hand.MAIN_HAND);
        cd = InvUtil.ticks(interval.get());
    }
}
