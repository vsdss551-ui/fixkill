package pl.ultimate.modules.impl;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import pl.ultimate.modules.*;
import pl.ultimate.utils.InvUtil;

public final class AutoTotem extends Module {
    private final Setting.Num delay = add(new Setting.Num("Opóźnienie (ms)", 50, 0, 500, 50));
    private final Setting.Num health = add(new Setting.Num("Tylko poniżej HP (0=zawsze)", 0, 0, 20, 0.5));
    private final Setting.Bool replaceOccupied = add(new Setting.Bool("Zamień zajętą rękę", false));
    private int wait;

    public AutoTotem() { super("AutoTotem", "Uzupełnia totem w drugiej ręce.", Category.COMBAT); }

    @Override public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (mc.interactionManager == null) return;
        if (mc.currentScreen != null && !(mc.currentScreen instanceof InventoryScreen)) return;
        if (wait > 0) { wait--; return; }
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (!p.getOffHandStack().isEmpty() && !replaceOccupied.get()) return;
        double hp = health.get();
        if (hp > 0 && p.getHealth() + p.getAbsorptionAmount() > hp) return;
        int idx = InvUtil.findInventory(p, s -> s.isOf(Items.TOTEM_OF_UNDYING));
        if (idx < 0) return;
        InvUtil.swapToOffhand(mc, idx);
        wait = InvUtil.ticks(delay.get());
    }
}
