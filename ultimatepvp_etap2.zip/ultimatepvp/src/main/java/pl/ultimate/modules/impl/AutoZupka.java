package pl.ultimate.modules.impl;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import pl.ultimate.modules.*;
import pl.ultimate.utils.InvUtil;

public final class AutoZupka extends Module {
    private final Setting.Num threshold = add(new Setting.Num("Próg zdrowia (HP)", 3.5, 0.5, 20, 0.5));
    private final Setting.Text itemName = add(new Setting.Text("Nazwa przedmiotu", "barszcz"));
    private final Setting.Num cooldown = add(new Setting.Num("Cooldown (ms)", 500, 0, 3000, 50));
    private int cd, prevSlot = -1, stage;

    public AutoZupka() { super("AutoZupka", "Je barszcz (slot 9) przy niskim HP.", Category.COMBAT); }

    private boolean matches(ItemStack s) {
        if (s.isEmpty()) return false;
        String n = itemName.get().toLowerCase();
        if (!n.isEmpty() && s.getName().getString().toLowerCase().contains(n)) return true;
        return s.isOf(Items.BEETROOT_SOUP) && (n.isEmpty() || n.contains("burak") || n.contains("barszcz"));
    }

    @Override protected void onDisable() { stage = 0; prevSlot = -1; }

    @Override public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (mc.interactionManager == null || mc.currentScreen != null) return;
        if (cd > 0) { cd--; return; }
        if (stage == 1) { // wróć na poprzedni slot po użyciu
            if (prevSlot >= 0) InvUtil.select(p, prevSlot);
            stage = 0; prevSlot = -1; return;
        }
        if (p.getHealth() > threshold.get()) return;
        int idx = InvUtil.findInventory(p, this::matches);
        if (idx < 0) return;
        prevSlot = p.getInventory().selectedSlot;
        if (idx != 8) { // slot 9 = indeks 8
            if (idx < 9) InvUtil.select(p, idx);
            else { InvUtil.swapToHotbar(mc, idx, 8); InvUtil.select(p, 8); }
            if (idx < 9) { mc.interactionManager.interactItem(p, Hand.MAIN_HAND); stage = 1; cd = InvUtil.ticks(cooldown.get()); return; }
        } else InvUtil.select(p, 8);
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        stage = 1;
        cd = InvUtil.ticks(cooldown.get());
    }
}
