package pl.ultimate.modules.impl;

import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import pl.ultimate.gui.ClickGuiScreen;
import pl.ultimate.modules.*;

/** Otwiera GUI. Domyślny klawisz to tylko wartość startowa - zmieniasz go w GUI jak każdy inny. */
public final class ClickGuiModule extends Module {
    public ClickGuiModule() {
        super("ClickGUI", "Otwiera menu klienta.", Category.SETTINGS);
        setBind(GLFW.GLFW_KEY_RIGHT_SHIFT);
    }
    @Override public void onBindPress() { mc.setScreen(new ClickGuiScreen()); }
    @Override public void setEnabled(boolean on) { /* bez stanu ON/OFF */ }
}
