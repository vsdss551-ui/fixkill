package pl.ultimate.modules.impl;

import net.minecraft.block.*;
import net.minecraft.block.enums.BlockFace;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import pl.ultimate.modules.*;
import pl.ultimate.utils.InvUtil;

/**
 * ErrorKiller: web w ręce (lub hotbarze) + wiadro wody w hotbarze + patrzysz na dźwignię:
 * woda (PPM) -> po X ms zabranie wody -> po Y ms web w miejscu dźwigni.
 */
public final class ErrorKiller extends Module {
    private final Setting.Num waterToPickup = add(new Setting.Num("Zabranie wody po (ms)", 100, 0, 500, 50));
    private final Setting.Num pickupToWeb = add(new Setting.Num("Web po zabraniu (ms)", 100, 0, 500, 50));
    private final Setting.Num cooldown = add(new Setting.Num("Cooldown (ms)", 500, 0, 3000, 50));
    private final Setting.Bool restoreSlot = add(new Setting.Bool("Przywróć slot", true));
    private final Setting.Bool needWebInHand = add(new Setting.Bool("Wymagaj weba w ręce", false));

    private enum Stage { IDLE, WATER, PICKED }
    private Stage stage = Stage.IDLE;
    private int wait, cd, prevSlot, bucketSlot, webSlot;
    private Hand webHand = Hand.MAIN_HAND;
    private BlockPos leverPos, support;
    private Direction side;

    public ErrorKiller() { super("ErrorKiller", "Dźwignia -> woda -> web w miejscu dźwigni.", Category.COMBAT); }

    @Override protected void onDisable() { reset(); }
    private void reset() { stage = Stage.IDLE; wait = 0; leverPos = null; support = null; side = null; }

    @Override public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) { reset(); return; }
        if (mc.currentScreen != null) { return; }
        if (wait > 0) { wait--; return; }

        switch (stage) {
            case IDLE -> idle(p);
            case WATER -> {
                // zabierz wodę (to samo wiadro, teraz puste)
                if (!p.getInventory().getStack(bucketSlot).isOf(Items.BUCKET)) { finish(p); return; }
                InvUtil.select(p, bucketSlot);
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                p.swingHand(Hand.MAIN_HAND);
                stage = Stage.PICKED;
                wait = InvUtil.ticks(pickupToWeb.get());
            }
            case PICKED -> {
                if (webHand == Hand.MAIN_HAND) InvUtil.select(p, webSlot);
                if (leverPos != null && mc.world.getBlockState(leverPos).isReplaceable()) {
                    Vec3d hit = Vec3d.ofCenter(support).add(Vec3d.of(side.getVector()).multiply(0.5));
                    mc.interactionManager.interactBlock(p, webHand, new BlockHitResult(hit, side, support, false));
                    p.swingHand(webHand);
                }
                finish(p);
            }
        }
    }

    private void idle(ClientPlayerEntity p) {
        if (cd > 0) { cd--; return; }
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        BlockPos pos = hit.getBlockPos();
        BlockState st = mc.world.getBlockState(pos);
        if (!st.isOf(Blocks.LEVER)) return;

        // web: druga ręka, główna ręka albo hotbar
        if (p.getOffHandStack().isOf(Items.COBWEB)) { webHand = Hand.OFF_HAND; webSlot = -1; }
        else if (p.getMainHandStack().isOf(Items.COBWEB)) { webHand = Hand.MAIN_HAND; webSlot = p.getInventory().selectedSlot; }
        else if (!needWebInHand.get() && (webSlot = InvUtil.findHotbar(p, s -> s.isOf(Items.COBWEB))) >= 0) { webHand = Hand.MAIN_HAND; }
        else return;

        bucketSlot = InvUtil.findHotbar(p, (ItemStack s) -> s.isOf(Items.WATER_BUCKET));
        if (bucketSlot < 0) return;

        BlockFace face = st.get(Properties.BLOCK_FACE);
        Direction facing = st.get(HorizontalFacingBlock.FACING);
        switch (face) {
            case FLOOR -> { side = Direction.UP; support = pos.down(); }
            case CEILING -> { side = Direction.DOWN; support = pos.up(); }
            default -> { side = facing; support = pos.offset(facing.getOpposite()); }
        }
        leverPos = pos;
        prevSlot = p.getInventory().selectedSlot;

        InvUtil.select(p, bucketSlot);
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.swingHand(Hand.MAIN_HAND);
        stage = Stage.WATER;
        wait = InvUtil.ticks(waterToPickup.get());
    }

    private void finish(ClientPlayerEntity p) {
        if (restoreSlot.get()) InvUtil.select(p, prevSlot);
        cd = InvUtil.ticks(cooldown.get());
        reset();
    }
}
