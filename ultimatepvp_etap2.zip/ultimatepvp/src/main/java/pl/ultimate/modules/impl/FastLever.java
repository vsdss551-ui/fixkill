package pl.ultimate.modules.impl;

import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import pl.ultimate.modules.*;
import pl.ultimate.utils.InvUtil;

/** Patrzysz na dźwignię; gdy obok niej pojawi się woda, po 0,3 s dźwignia jest przełączana. */
public final class FastLever extends Module {
    private final Setting.Num delay = add(new Setting.Num("Reakcja (ms)", 300, 0, 1000, 50));
    private final Setting.Num reach = add(new Setting.Num("Maks. dystans", 4.5, 2, 6, 0.5));
    private boolean wasWater; private int wait = -1; private BlockPos target;

    public FastLever() { super("FastLever", "Przełącza dźwignię po pojawieniu się wody obok niej.", Category.COMBAT); }
    @Override protected void onDisable() { wait = -1; wasWater = false; target = null; }

    @Override public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || mc.interactionManager == null) return;

        if (wait > 0) wait--;
        else if (wait == 0) { fire(p); wait = -1; }

        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK
                || !mc.world.getBlockState(hit.getBlockPos()).isOf(Blocks.LEVER)) { wasWater = false; return; }
        BlockPos pos = hit.getBlockPos();
        boolean water = false;
        for (Direction d : Direction.values())
            if (mc.world.getFluidState(pos.offset(d)).isIn(FluidTags.WATER)) { water = true; break; }
        if (water && !wasWater && wait < 0) { target = pos; wait = InvUtil.ticks(delay.get()); if (wait == 0) { fire(p); wait = -1; } }
        wasWater = water;
    }

    private void fire(ClientPlayerEntity p) {
        if (target == null || !mc.world.getBlockState(target).isOf(Blocks.LEVER)) return;
        if (p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(target)) > reach.get() * reach.get()) return;
        BlockHitResult hit = mc.crosshairTarget instanceof BlockHitResult h && h.getType() == HitResult.Type.BLOCK && h.getBlockPos().equals(target)
                ? h : new BlockHitResult(Vec3d.ofCenter(target), Direction.UP, target, false);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
        p.swingHand(Hand.MAIN_HAND);
    }
}
