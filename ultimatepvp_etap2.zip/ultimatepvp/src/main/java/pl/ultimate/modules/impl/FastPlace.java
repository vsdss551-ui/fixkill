package pl.ultimate.modules.impl;

import pl.ultimate.mixin.MinecraftClientAccessor;
import pl.ultimate.modules.*;

public final class FastPlace extends Module {
    private final Setting.Num delay = add(new Setting.Num("Opóźnienie (ticki)", 0, 0, 4, 1));
    public FastPlace() { super("FastPlace", "Szybsze stawianie i używanie przedmiotów.", Category.PLAYER); }

    @Override public void onTick() {
        MinecraftClientAccessor acc = (MinecraftClientAccessor) mc;
        int d = delay.intValue();
        if (acc.getItemUseCooldown() > d) acc.setItemUseCooldown(d);
    }
}
