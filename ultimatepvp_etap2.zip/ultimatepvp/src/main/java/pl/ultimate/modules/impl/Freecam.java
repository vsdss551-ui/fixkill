package pl.ultimate.modules.impl;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import pl.ultimate.modules.*;

public final class Freecam extends Module {
    private final Setting.Num speed = add(new Setting.Num("Prędkość", 1.0, 0.1, 5.0, 0.1));
    private final Setting.Num smooth = add(new Setting.Num("Płynność", 0.35, 0.05, 1.0, 0.05));
    private double vx, vy, vz;

    public Freecam() { super("Freecam", "Swobodna kamera.", Category.VISUALS); }

    @Override protected void onEnable() {
        if (mc.player == null) return;
        Vec3d c = mc.gameRenderer.getCamera().getPos();
        FreecamState.x = FreecamState.px = c.x; FreecamState.y = FreecamState.py = c.y; FreecamState.z = FreecamState.pz = c.z;
        FreecamState.yaw = mc.player.getYaw(); FreecamState.pitch = mc.player.getPitch();
        vx = vy = vz = 0;
        FreecamState.active = true;
    }
    @Override protected void onDisable() { FreecamState.active = false; }

    @Override public void onTick() {
        if (!FreecamState.active) return;
        double fwd = 0, side = 0, up = 0;
        if (mc.currentScreen == null) {
            if (mc.options.forwardKey.isPressed()) fwd += 1;
            if (mc.options.backKey.isPressed()) fwd -= 1;
            if (mc.options.leftKey.isPressed()) side += 1;
            if (mc.options.rightKey.isPressed()) side -= 1;
            if (mc.options.jumpKey.isPressed()) up += 1;
            if (mc.options.sneakKey.isPressed()) up -= 1;
        }
        double yawR = Math.toRadians(FreecamState.yaw), pitR = Math.toRadians(FreecamState.pitch);
        double fx = -Math.sin(yawR) * Math.cos(pitR), fy = -Math.sin(pitR), fz = Math.cos(yawR) * Math.cos(pitR);
        double sx = Math.cos(yawR), sz = Math.sin(yawR);
        double s = speed.get() * 0.5, k = smooth.get();
        double tx = (fx * fwd + sx * side) * s, ty = (fy * fwd + up) * s, tz = (fz * fwd + sz * side) * s;
        vx += (tx - vx) * k; vy += (ty - vy) * k; vz += (tz - vz) * k;
        FreecamState.px = FreecamState.x; FreecamState.py = FreecamState.y; FreecamState.pz = FreecamState.z;
        FreecamState.x += vx; FreecamState.y += vy; FreecamState.z += vz;
    }
}
