package pl.ultimate.modules.impl;

import net.minecraft.util.math.MathHelper;

/** Wspólny stan kamery dla modułu i mixinów. */
public final class FreecamState {
    public static volatile boolean active;
    public static double x, y, z, px, py, pz;
    public static float yaw, pitch;
    private FreecamState() {}
    public static void rotate(double dx, double dy) {
        yaw += (float) dx * 0.15f;
        pitch = MathHelper.clamp(pitch + (float) dy * 0.15f, -90f, 90f);
    }
}
