package pl.ultimate.modules.impl;

import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import pl.ultimate.modules.*;

/** Ukrywa wybrane kategorie encji (nigdy graczy). Kategoria liczona raz na typ encji i cache'owana. */
public final class FvckNielegal extends Module {
    private static final int STAND = 1, CART = 2, ANIMAL = 4, MOB = 8, NONE = 0;
    private static FvckNielegal instance;
    private final Setting.Bool stands = add(new Setting.Bool("ArmorStand", true));
    private final Setting.Bool carts = add(new Setting.Bool("Wagoniki", true));
    private final Setting.Bool animals = add(new Setting.Bool("Zwierzęta", false));
    private final Setting.Bool mobs = add(new Setting.Bool("Moby", false));
    private static final Map<EntityType<?>, Integer> CATEGORY = new IdentityHashMap<>();
    private static volatile int mask;

    public FvckNielegal() { super("FvckNielegal", "Ukrywa wybrane encje (bez graczy).", Category.RENDER); instance = this; }

    @Override protected void onDisable() { mask = 0; }
    @Override public void onTick() {
        mask = (stands.get() ? STAND : 0) | (carts.get() ? CART : 0) | (animals.get() ? ANIMAL : 0) | (mobs.get() ? MOB : 0);
    }

    /** Wołane z mixina renderera encji. */
    public static boolean hide(Entity e) {
        int m = mask;
        if (m == 0 || instance == null || !instance.isEnabled() || e instanceof PlayerEntity) return false;
        int cat = CATEGORY.computeIfAbsent(e.getType(), t ->
                e instanceof ArmorStandEntity ? STAND : e instanceof AbstractMinecartEntity ? CART
                        : e instanceof AnimalEntity ? ANIMAL : e instanceof MobEntity ? MOB : NONE);
        return (cat & m) != 0;
    }
}
