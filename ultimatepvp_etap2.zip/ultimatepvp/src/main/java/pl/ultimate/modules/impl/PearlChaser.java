package pl.ultimate.modules.impl;

import java.util.*;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import pl.ultimate.modules.*;
import pl.ultimate.utils.InvUtil;
import pl.ultimate.utils.RotUtil;

/** Wykrywa rzucone perły; po delayu rzuca własną perłę w jej kierunku. Każda perła przetwarzana raz. */
public final class PearlChaser extends Module {
    private final Setting.Num delay = add(new Setting.Num("Delay (ms)", 300, 0, 1000, 50));
    private final Setting.Num range = add(new Setting.Num("Zasięg wykrywania", 48, 8, 128, 4));
    private final Setting.Bool ignoreOwn = add(new Setting.Bool("Ignoruj własne perły", true));
    private final Set<Integer> seen = new HashSet<>();
    private final Map<Integer, Integer> pending = new HashMap<>();

    public PearlChaser() { super("PearlChaser", "Reaguje na rzucone perły Endu.", Category.COMBAT); }
    @Override protected void onDisable() { seen.clear(); pending.clear(); }

    @Override public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (mc.interactionManager == null) return;
        double r = range.get();
        List<EnderPearlEntity> pearls = mc.world.getEntitiesByClass(EnderPearlEntity.class, p.getBoundingBox().expand(r), e -> !e.isRemoved());
        Set<Integer> alive = new HashSet<>();
        for (EnderPearlEntity e : pearls) {
            alive.add(e.getId());
            if (ignoreOwn.get() && e.getOwner() == p) { seen.add(e.getId()); continue; }
            if (seen.add(e.getId())) pending.put(e.getId(), InvUtil.ticks(delay.get()));
        }
        seen.retainAll(alive); // brak wycieku pamięci

        Iterator<Map.Entry<Integer, Integer>> it = pending.entrySet().iterator();
        while (it.hasNext()) {
            var en = it.next();
            Entity e = mc.world.getEntityById(en.getKey());
            if (e == null || e.isRemoved()) { it.remove(); continue; }
            if (en.getValue() > 0) { en.setValue(en.getValue() - 1); continue; }
            it.remove();
            throwAt(p, e);
        }
    }

    private void throwAt(ClientPlayerEntity p, Entity target) {
        int slot = InvUtil.findHotbar(p, s -> s.isOf(Items.ENDER_PEARL));
        if (slot < 0) return;
        int prev = p.getInventory().selectedSlot; float yaw = p.getYaw(), pitch = p.getPitch();
        InvUtil.select(p, slot);
        RotUtil.lookAt(p, target.getPos());
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.swingHand(Hand.MAIN_HAND);
        InvUtil.select(p, prev);
        p.setYaw(yaw); p.setPitch(pitch);
    }
}
