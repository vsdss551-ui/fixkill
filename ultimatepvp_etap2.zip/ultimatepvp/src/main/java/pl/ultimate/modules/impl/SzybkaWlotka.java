package pl.ultimate.modules.impl;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import pl.ultimate.modules.*;
import pl.ultimate.utils.InvUtil;
import pl.ultimate.utils.RotUtil;

/**
 * Sekwencja (założenie: PRI = prawy przycisk myszy):
 * slot 2 PPM -> slot 7 widok prosto + PPM -> slot 8 widok w dół + PPM -> slot 5 przytrzymaj -> zwolnij.
 * Całość ~0,7 s (3 ticki + przytrzymanie). Ponowne naciśnięcie bindu przerywa sekwencję.
 */
public final class SzybkaWlotka extends Module {
    private final Setting.Num hold = add(new Setting.Num("Przytrzymanie slotu 5 (ms)", 500, 100, 800, 50));
    private int t = -1, prevSlot;
    private float prevYaw, prevPitch;

    public SzybkaWlotka() { super("SzybkaWlotka", "Sekwencja: sloty 2, 7, 8, 5 w ~0,7 s.", Category.COMBAT); }

    @Override protected void onEnable() {
        ClientPlayerEntity p = mc.player;
        if (p == null) { t = -1; return; }
        t = 0; prevSlot = p.getInventory().selectedSlot; prevYaw = p.getYaw(); prevPitch = p.getPitch();
    }
    @Override protected void onDisable() { finishSilently(); }

    private void finishSilently() {
        mc.options.useKey.setPressed(false);
        ClientPlayerEntity p = mc.player;
        if (p != null && t >= 0) { InvUtil.select(p, prevSlot); RotUtil.look(p, prevYaw, prevPitch); }
        t = -1;
    }

    @Override public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || t < 0) { setEnabled(false); return; }
        int holdTicks = InvUtil.ticks(hold.get());
        if (t == 0) { InvUtil.select(p, 1); use(p); }
        else if (t == 1) { InvUtil.select(p, 6); RotUtil.look(p, p.getYaw(), 0f); use(p); }
        else if (t == 2) { InvUtil.select(p, 7); RotUtil.look(p, p.getYaw(), 90f); use(p); }
        else if (t == 3) { InvUtil.select(p, 4); mc.options.useKey.setPressed(true); }
        else if (t >= 3 + holdTicks) { setEnabled(false); return; }
        t++;
    }
    private void use(ClientPlayerEntity p) { mc.interactionManager.interactItem(p, Hand.MAIN_HAND); p.swingHand(Hand.MAIN_HAND); }
}
