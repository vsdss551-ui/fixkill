package pl.ultimate.modules.impl;

import net.minecraft.block.AbstractSignBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.FenceBlock;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.painting.PaintingEntity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import pl.ultimate.modules.*;
import pl.ultimate.utils.InvUtil;

/** Wychodzenie z pułapki: niszczy wagoniki, obrazy, tabliczki i płotki (jedna akcja na delay). */
public final class TrapEscape extends Module {
    private final Setting.Bool minecarts = add(new Setting.Bool("Wagoniki", true));
    private final Setting.Bool paintings = add(new Setting.Bool("Obrazy", true));
    private final Setting.Bool signs = add(new Setting.Bool("Tabliczki", true));
    private final Setting.Bool fences = add(new Setting.Bool("Płotki", true));
    private final Setting.Num delay = add(new Setting.Num("Delay (ms)", 200, 50, 1000, 50));
    private final Setting.Num range = add(new Setting.Num("Zasięg", 3.5, 1, 5, 0.5));
    private final Setting.Bool onlyStuck = add(new Setting.Bool("Tylko gdy stoisz w miejscu", true));
    private int cd;

    public TrapEscape() { super("TrapEscape", "Czyści wagoniki/obrazy/tabliczki/płotki wokół Ciebie.", Category.COMBAT); }

    @Override public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (mc.interactionManager == null || mc.currentScreen != null || p.isUsingItem()) return;
        if (cd > 0) { cd--; return; }
        if (onlyStuck.get() && (Math.abs(p.getX() - p.prevX) > 0.02 || Math.abs(p.getZ() - p.prevZ) > 0.02)) return;

        double r = range.get();
        Entity best = null; double bd = r * r;
        if (minecarts.get() || paintings.get()) {
            for (Entity e : mc.world.getOtherEntities(p, p.getBoundingBox().expand(r), x ->
                    (minecarts.get() && x instanceof AbstractMinecartEntity) || (paintings.get() && x instanceof PaintingEntity))) {
                double d = e.squaredDistanceTo(p);
                if (d < bd) { bd = d; best = e; }
            }
        }
        if (best != null) {
            mc.interactionManager.attackEntity(p, best);
            p.swingHand(Hand.MAIN_HAND);
            cd = InvUtil.ticks(delay.get());
            return;
        }
        if (mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
            BlockPos pos = hit.getBlockPos();
            BlockState st = mc.world.getBlockState(pos);
            if ((signs.get() && st.getBlock() instanceof AbstractSignBlock) || (fences.get() && st.getBlock() instanceof FenceBlock)) {
                mc.interactionManager.updateBlockBreakingProgress(pos, hit.getSide());
                p.swingHand(Hand.MAIN_HAND);
                cd = InvUtil.ticks(delay.get());
            }
        }
    }
}
