package pl.ultimate.utils;

import java.util.function.Predicate;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

public final class InvUtil {
    private InvUtil() {}

    /** Zwraca indeks hotbara (0-8) lub -1. */
    public static int findHotbar(ClientPlayerEntity p, Predicate<ItemStack> f) {
        for (int i = 0; i < 9; i++) if (f.test(p.getInventory().getStack(i))) return i;
        return -1;
    }
    /** Zwraca indeks ekwipunku (0-35) lub -1. 0-8 hotbar, 9-35 główny. */
    public static int findInventory(ClientPlayerEntity p, Predicate<ItemStack> f) {
        for (int i = 0; i < 36; i++) if (f.test(p.getInventory().getStack(i))) return i;
        return -1;
    }
    /** Indeks ekwipunku -> numer slotu w PlayerScreenHandler (syncId 0). */
    public static int toScreenSlot(int invIndex) { return invIndex < 9 ? 36 + invIndex : invIndex; }

    /** Zamienia slot ekwipunku z hotbarem (0-8) przez SWAP. */
    public static void swapToHotbar(MinecraftClient mc, int invIndex, int hotbar) {
        mc.interactionManager.clickSlot(0, toScreenSlot(invIndex), hotbar, SlotActionType.SWAP, mc.player);
    }
    /** Zamienia slot ekwipunku z drugą ręką. */
    public static void swapToOffhand(MinecraftClient mc, int invIndex) {
        mc.interactionManager.clickSlot(0, toScreenSlot(invIndex), 40, SlotActionType.SWAP, mc.player);
    }
    public static void select(ClientPlayerEntity p, int hotbar) {
        if (hotbar >= 0 && hotbar < 9) p.getInventory().selectedSlot = hotbar;
    }
    public static int ticks(double ms) { return Math.max(0, (int) Math.ceil(ms / 50.0)); }
}
