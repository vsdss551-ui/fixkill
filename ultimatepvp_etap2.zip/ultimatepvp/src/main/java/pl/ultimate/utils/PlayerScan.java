package pl.ultimate.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;

public final class PlayerScan {
    private PlayerScan() {}
    /** Czy w zasięgu jest jakikolwiek inny gracz (bez siebie i spectatorów). Zero alokacji. */
    public static boolean anyNear(MinecraftClient mc, double range) {
        ClientPlayerEntity me = mc.player;
        if (me == null || mc.world == null) return false;
        double r2 = range * range;
        for (AbstractClientPlayerEntity o : mc.world.getPlayers()) {
            if (o == me || o.isSpectator() || o.isRemoved()) continue;
            if (o.squaredDistanceTo(me) <= r2) return true;
        }
        return false;
    }
}
