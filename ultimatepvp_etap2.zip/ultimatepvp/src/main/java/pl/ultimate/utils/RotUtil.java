package pl.ultimate.utils;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class RotUtil {
    private RotUtil() {}

    /** Ustawia rotację gracza i od razu wysyła ją na serwer. */
    public static void look(ClientPlayerEntity p, float yaw, float pitch) {
        p.setYaw(yaw);
        p.setPitch(MathHelper.clamp(pitch, -90f, 90f));
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(p.getYaw(), p.getPitch(), p.isOnGround(), p.horizontalCollision));
    }
    public static float yawTo(Vec3d from, Vec3d to) {
        return (float) (MathHelper.atan2(to.z - from.z, to.x - from.x) * 180.0 / Math.PI) - 90f;
    }
    public static float pitchTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dz = to.z - from.z;
        return (float) -(MathHelper.atan2(to.y - from.y, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);
    }
    public static void lookAt(ClientPlayerEntity p, Vec3d target) {
        Vec3d eye = p.getEyePos();
        look(p, yawTo(eye, target), pitchTo(eye, target));
    }
}
